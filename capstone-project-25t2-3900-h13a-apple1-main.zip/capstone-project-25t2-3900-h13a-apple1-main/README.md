[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=19734346&assignment_repo_type=AssignmentRepo)

# AI Apply: One-Click Job Application Engine
### Project Overview
Job seekers spend countless hours manually filling out repetitive job application forms on platforms like Seek, LinkedIn, and Indeed. JobGen.AI aims to revolutionize this process by providing a true one-click job application experience.

Our platform currently offers tailored resumes and cover letters based on a user's profile and a specific job description. The existing JobGen.AI Chrome Extension can already detect jobs and send relevant data to our backend.

The missing piece is full automation of the application process itself.

<b>Our mission is to extend the Chrome Extension to fully automate the job application workflow, from form detection to submission.</b>

## The Workflow
When a user clicks "Apply," the following steps will be executed to provide a seamless, one-click experience:

1. <b>Job Data Transmission:</b> The extension sends key job data to the JobGen.AI backend.

2. <b>Backend Processing:</b> The backend returns tailored documents (resume, cover letter) and pre-filled answers to the most common application questions.

3. <b>Client-Side Automation:</b> The extension takes control to:
Auto-fill the entire job application form.

    * Upload the user's resume and cover letter.

    * Fill in tricky, non-standard fields (e.g., salary, years of experience, availability).

    * Answer common pre-filled questions.

    * Handle psychometric and scenario-based questions.

    * Display a user-friendly preview screen for final review.

    * Simulate form submission.

4. Application Tracking: The application is logged for user tracking purposes.

## Scope of Work: Chrome Extension Responsibilities
The Chrome Extension will be responsible for the entire client-side automation process, including:

#### Form Detection & Auto-fill
* <b>Platform Support:</b> Detect and handle application forms on major job sites, including LinkedIn, Indeed, Naukri.com, Glassdoor, and Seek.

* <b>Field Classification:</b> Implement a robust engine to classify and match dynamic form fields to the correct data points.

* <b>Personal Information:</b> Auto-fill common fields like Name, Email, Phone, and Address.

* <b>Professional Details:</b> Fill in Employment History, Education, and specific experience questions.
