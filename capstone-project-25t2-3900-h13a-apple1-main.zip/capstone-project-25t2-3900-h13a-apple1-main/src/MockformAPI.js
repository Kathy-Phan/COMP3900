/* ────────────────────────────────────────────────────────────────
   JobGen.AI Smart‑Apply Helper  – 2025‑07‑29
   Works with the *new* (header‑only JWT, SUCCESS / FAILURE) API
   ───────────────────────────────────────────────────────────────*/
(async function boot () {

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    0.  Shared helpers
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  const isSuccess = x => ["SUCCESS","PASS"].includes(`${x}`.toUpperCase());

  const norm = s =>
    s?.toLowerCase().trim().replace(/[^a-z0-9]/g, "") || "";

  /** remove accidental double‑JSON‑stringifying */
  const dequoteMaybeJSON = blob => {
    let x = blob;
    for (let i = 0; i < 3; i++) {
      if (typeof x !== "string") break;
      const t = x.trim();
      if (!(t.startsWith("{") || t.startsWith("["))) break;
      try { x = JSON.parse(t); } catch { break; }
    }
    return x;
  };

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    1.  Get JWT
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  const email = "samuellim2000@gmail.com";

  async function fetchJwt (email) {
    const r   = await fetch(
      "https://www.jobgen.ai/version-test/api/1.1/wf/jobgen_generate_token",
      {
        method : "POST",
        headers: { "Content-Type": "application/json" },
        body   : JSON.stringify({ email })
      }
    );
    const j = await r.json();
    console.log("🔁 generate_token raw:", j);

    if (!isSuccess(j.status) || !isSuccess(j.response?.outcome)) {
      throw new Error(
        `generate_token failed: ${j.status}/${j.response?.outcome}`
      );
    }
    const token = j.response.jwt_token;
    console.log("🔑 JWT:", token);
    return token;
  }

  let jwt;
  try {
    jwt = await fetchJwt(email);
  } catch (e) {
    return console.error("❌ boot(): couldn't obtain JWT – aborting", e);
  }

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    2.  Static fallback data (used if API‑FAQ returns nothing)
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  const dataMap = {
    "street address line 1": "123 King St",
    "street address line 2": "Unit 5",
    suburb : "Kensington",
    postcode: "2033",
    state  : "NSW",
    yes    : true,
    "australian citizen": true,
    monday : true,
    tuesday: true
  };

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    3.  Re‑usable request helper
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  async function api (url, bodyObj = null) {
    const opt = {
      method : "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${jwt}`
      }
    };
    if (bodyObj) opt.body = JSON.stringify(bodyObj);

    const r   = await fetch(url, opt);
    const txt = await r.text();

    if (!r.ok) {
      throw new Error(`HTTP ${r.status} → ${txt.slice(0,200)}`);
    }
    const j = dequoteMaybeJSON(txt);
    if (!isSuccess(j.status ?? j.outcome ?? j.response?.outcome)) {
      throw new Error(`API fail → ${txt.slice(0,200)}`);
    }
    return j;
  }

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    4.  Job context for *this* tab
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  const job_url     = location.href;
  const job_portal  = location.hostname;
  const job_url_id  =
    (job_url.match(/(?:\/view\/|\/job\/|job_id=)([a-z0-9_-]+)/i) ?? [])[1] ||
    job_url;

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    5.  API‑1 · job_apply   (fires immediately so resume links are ready)
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  async function callJobApply ({ cover_letter_required = false } = {}) {

    /* scrape minimal details from the page – fall back if not found */
    const title = (
      document.querySelector("h1")?.innerText ||
      "Unknown title"
    ).trim();

    const company = (
      document.querySelector(".company, [data-company]")?.innerText ||
      "Unknown company"
    ).trim();

    const description = (
      document.querySelector("article")?.innerText ||
      document.body.innerText
    ).trim().slice(0, 2500);

    const payload = {
      job_url,
      description,
      cover_letter: cover_letter_required ? "yes" : "no",
      company,
      job_title   : title,
      job_url_id,
      job_portal
    };

    console.log("🚀 API‑1 payload:", payload);

    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply",
      payload
    );

    const { resume, cover_letter, job_id } = j.response ?? {};
    console.log("✅ API‑1 result:", { resume, cover_letter, job_id });
    window._jobgen_job_id = job_id || null;
    return { resume, cover_letter, job_id };
  }

  /* fire it, but don't block the rest of boot */
  callJobApply().catch(e => console.error("❌ API‑1", e));

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    6.  API‑2 · job_apply_faq → bulk answers & full address
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  try {
    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_faq"
    );
    const faq = dequoteMaybeJSON(j.response);
    if (faq && typeof faq === "object") {
      Object.assign(dataMap, faq);
      console.log("🗺 FAQ merged:", faq);
    }
  } catch (e) {
    console.error("❌ API‑2", e);
  }



  /* ------------- API‑2 helper ------------- */
async function runApi2_andPrint () {
  if (!window._jobgen_jwt) {
    console.warn("JWT not found – make sure fetchJwt() finished first");
    return;
  }

  const r = await fetch(
    "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_faq",
    {
      method : "POST",
      headers: {
        "Content-Type" : "application/json",
        "Authorization": `Bearer ${window._jobgen_jwt}`
      },
      body   : "{}"     // docs show an empty JSON object
    }
  );

  const txt = await r.text();
  console.log("📦 raw API‑2 text:", txt);

  if (!r.ok) {
    console.error(`HTTP ${r.status}`, txt); return;
  }

  const j = JSON.parse(txt);
  console.log("✅ parsed JSON:", j);

  /* merge into your dataMap if you like */
  if (j && typeof j === "object") {
    window.dataMap = window.dataMap || {};
    Object.assign(window.dataMap, j);
    console.log("🗺 merged into dataMap – keys now:", Object.keys(window.dataMap));
  }
}

/* store the JWT globally once you have it so the helper can access it */
window._jobgen_jwt = jwt;

/* call it */
runApi2_andPrint().catch(e => console.error("API‑2 error", e));

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    7.  API‑3 · job_apply_question  (for every input ending …api3_question)
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  for (const qEl of document.querySelectorAll("[name$='api3_question']")) {
    const question =
      qEl.value || qEl.placeholder || qEl.getAttribute("aria-label") || "";

    try {
      const j = await api(
        "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_question",
        { question }
      );

      const answer =
        j.response?.answer ??
        j.response?.data ??
        j.response?.outcome ??
        "";

      if (answer) {
        const ansName = qEl.name.replace(/question$/, "answer");
        const ansEl   = document.querySelector(`[name='${ansName}']`) || qEl;
        ansEl.value   = answer;
        ansEl.dispatchEvent(new Event("input", { bubbles: true }));
        dataMap[ansName] = answer;
        console.log(`🤖 Filled ${ansName} with GPT:`, answer);
      }

    } catch (e) {
      console.error("❌ API‑3 question error", e);
    }
  }

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    8.  API‑4 · job_apply_preference  → user prefs
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  try {
    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_preference"
    );
    Object.assign(dataMap, j.response || {});
    console.log("🗺 Preferences merged:", j.response);
  } catch (e) {
    console.error("❌ API‑PREF", e);
  }

  /* ================================================================
   8 ▸ API‑4 · job_apply_preference   (merge saved prefs)
   ============================================================== */
async function callJobApplyPreference () {
  try {
    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_preference"
    );
    const prefs = j.response ?? {};
    Object.assign(dataMap, prefs);
    console.log("🗺 Preferences merged:", prefs);
  } catch (e) {
    console.error("❌ API‑PREF error:", e);
  }
}

/* ================================================================
   9 ▸ API‑5a · job_apply_outcome      (record Applied / Failed …)
   ============================================================== */
async function callJobApplyOutcome ({
  status    = "Applied",        // "Applied" | "Failed" | "Needs Review" | "Withdrawn"
  errorCode = "",               // supply only when status ≠ Applied
  platform  = job_portal        // "LinkedIn", "Seek", …
} = {}) {
  if (!window._jobgen_job_id) {
    console.warn("callJobApplyOutcome: job_id missing, was job_apply run?");
    return;
  }

  try {
    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_outcome",
      {
        application_status : status,
        job_id             : window._jobgen_job_id,
        error_code         : errorCode,
        platform
      }
    );
    console.log("✅ Outcome recorded:", j);
  } catch (e) {
    console.error("❌ API‑OUTCOME error:", e);
  }
}

/* ================================================================
   10 ▸ API‑5b · job_save               (bookmark the job)
   ============================================================== */
async function callJobSave ({
  excitement  = 5,
  description = "Saved via JobGen.AI",
  title       = document.querySelector("h1")?.innerText.trim() || "Unknown title",
  company     = (
    document.querySelector(".company, [data-company]")?.innerText || "Unknown company"
  ).trim()
} = {}) {
  try {
    const payload = {
      description,
      excitement,
      title,
      company,
      job_url,
      job_url_id,
      job_portal
    };
    const j = await api(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_save",
      payload
    );
    console.log("✅ Job saved:", j);
  } catch (e) {
    console.error("❌ API‑SAVE error:", e);
  }
}

/* ================================================================
   11 ▸ Orchestrate the calls in sequence
   ============================================================== */

/* 1️⃣  API‑1 (job_apply) already fired earlier – wait for it        */
let applyResult;
try { applyResult = await callJobApply(); } catch {}

/* 2️⃣  Regardless of API‑1 outcome, fetch preferences              */
await callJobApplyPreference();

/* 3️⃣  If job_apply succeeded → save job & record outcome          */
if (applyResult?.job_id) {
  // store for outcome call
  window._jobgen_job_id = applyResult.job_id;

  /* save() first so it’s listed in user dashboard immediately      */
  await callJobSave();

  /* finally record “Applied”                                       */
  await callJobApplyOutcome({ status: "Applied" });
} else {
  /* job_apply failed – still log an outcome for analytics          */
  await callJobApplyOutcome({
    status    : "Failed",
    errorCode : "ERR_UNKNOWN"
  });
}

  /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    9.  Generic one‑shot form autofill
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━*/
  function getLabel (el) {
    if (el.id) {
      const l = document.querySelector(`label[for='${el.id}']`);
      if (l) return l.innerText;
    }
    if (el.parentElement?.tagName === "LABEL") return el.parentElement.innerText;
    if (el.hasAttribute("aria-labelledby")) {
      const n = document.getElementById(el.getAttribute("aria-labelledby"));
      if (n) return n.innerText;
    }
    return el.placeholder || "";
  }

  function setField (el, val) {
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
      if (!el.value) {
        el.value = val;
        el.dispatchEvent(new Event("input", { bubbles: true }));
      }
      return;
    }
    if (el.tagName === "SELECT") {
      const opt = [...el.options]
        .find(o => norm(o.text) === norm(val) || norm(o.value) === norm(val));
      if (opt) {
        el.value = opt.value;
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return;
    }
    if (["checkbox","radio"].includes(el.type)) {
      if (!el.checked) el.click();
      return;
    }
  }

  function fillOnce () {
    document
      .querySelectorAll("input, textarea, select")
      .forEach(el => {
        const key = norm(
          [
            getLabel(el),
            el.name,
            el.id,
            el.placeholder,
            el.getAttribute("aria-label")
          ].join(" ")
        );
        for (const [want, val] of Object.entries(dataMap)) {
          if (key.includes(norm(want))) {
            setField(el, val);
            break;
          }
        }
      });

    console.log("✔️ Autofill complete");
  }

  if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", fillOnce);
  } else {
    fillOnce();
  }

})();