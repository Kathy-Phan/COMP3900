

/** helper: fetch remote PDF & drop it into a <input type="file"> */
async function uploadFileFromUrl(url, fileInput, filename = 'resume.pdf') {
  const res  = await fetch(url);
  const blob = await res.blob();
  const file = new File([blob], filename, { type: blob.type || 'application/pdf' });

  const dt = new DataTransfer();
  dt.items.add(file);
  fileInput.files = dt.files;

  fileInput.dispatchEvent(new Event('change', { bubbles:true }));
  console.log('📄 résumé uploaded →', fileInput);
}

/** main entry called from form-filler3.js */
export async function handleFileUploads({ jwt }) {
  /* 1️⃣ call job_apply to get ONE résumé URL */
  const payload = {
    job_url     : location.href,
    job_title   : document.title.slice(0,140),
    company     : location.hostname,
    description : document.body.innerText.slice(0,1000),
    cover_letter: 'no'                      // tell backend we only need resume
  };

  const res = await fetch(
    'https://www.jobgen.ai/version-test/api/1.1/wf/job_apply',
    {
      method : 'POST',
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': `Bearer ${jwt}`
      },
      body: JSON.stringify(payload)
    }
  ).then(r=>r.json()).catch(() => ({}));

  const resumeUrl = res?.response?.resume;
  if (!resumeUrl) {
    console.warn('[JobGen] API-1 returned no resume URL — skipping upload');
    return;
  }
  console.log('[JobGen] résumé URL →', resumeUrl);

 /* -------- choose the right <input type=file> for the résumé -------- */
const fileInputsMeta = [...document.querySelectorAll('input[type="file"]')]
  .filter(el => !el.disabled && el.offsetParent)
  .map(el => {
    const labelEl = document.querySelector(`label[for="${el.id}"]`);
    const text = [
      el.id || '',
      el.name || '',
      el.getAttribute('aria-label') || '',
      labelEl?.innerText || '',
      el.placeholder || ''
    ].join(' ').toLowerCase();
    return { el, text };
  });

let resumeInput =
  fileInputsMeta.find(m => /resume|cv|attachment/.test(m.text))?.el;

// common pattern: [ Cover Letter, Resume ]
if (!resumeInput && fileInputsMeta.length === 2) {
  resumeInput = fileInputsMeta[1].el;   // pick second
}

// fallback: do nothing if we still can’t find a target
if (!resumeInput) {
  console.warn('[JobGen] no résumé field detected – skipping upload');
  return;
}

await uploadFileFromUrl(resumeUrl, resumeInput);
console.log('📄 résumé uploaded to:', resumeInput);


  /* 3️⃣ optional: auto-click Next/Submit once file is attached */
  const btn = [...document.querySelectorAll('button')]
      .find(b => /next|continue|submit|apply/i.test(b.innerText) && !b.disabled);
  if (btn) btn.click();
}