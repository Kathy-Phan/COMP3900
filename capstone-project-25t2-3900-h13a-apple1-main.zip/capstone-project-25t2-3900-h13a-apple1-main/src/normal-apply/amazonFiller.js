import { DOMUtils } from '../linkedin-easy-apply/dom-utils.js';
import { FormFiller } from '../linkedin-easy-apply/form-filler.js';
import { APIClient } from '../linkedin-easy-apply/api-caller.js';

export class AmazonFiller {
    static async startFilling() {
        const formElements = document.querySelectorAll('input, select, textarea');
        for (const el of formElements) {
            if (el.closest('#jobContainer')) {
                continue;
            }
            await this.fillElement(el)
        }
    }


    static async fillElement(element) {
        const elementType = element.type || element.tagName.toLowerCase();
        // Try to get the question context for all element types
        let questionContext = '';
        try {
            questionContext = DOMUtils.getElementLabel(element) || '';
            // Try to get description if available
            const descEl = element.closest('.question')?.querySelector('.question-description');
            if (descEl && descEl.textContent) {
                questionContext += ' ' + descEl.textContent;
            }
        } catch { }
        element._questionContext = questionContext.trim();

        switch (elementType) {
            case 'text':
            case 'number':
            case 'email':
            case 'tel':
                await this.fillTextElement(element);
                break;

            case 'radio':
                this.fillRadioElement(element);
                break;

            case 'checkbox':
                this.fillCheckboxElement(element);
                break;
            case 'select-one':
            case 'select':
                this.fillSelectElement(element);
                break;

            default:
                console.log(`Skipped unsupported element type: ${elementType}`);
        }
    }

    static async fillTextElement(element) {
        let fieldLabel = await DOMUtils.getElementLabel(element);
        if (fieldLabel === 'no-label-found' || fieldLabel.trim() === '') {
            fieldLabel = element.getAttribute('aria-label')
            console.log('FIELD' + fieldLabel)
            if (fieldLabel === null) {
                return;

            }
        }
        if (element.value && element.value.trim() !== '' && !fieldLabel.toLowerCase().includes('phone')) {
            console.log(`Skipping pre-filled element:`, element.type, element.value);
            return;
        }
        console.log('im in text element: ' + fieldLabel)
        // Skip if we can't find a meaningful label



        // FIRST PRIORITY: Check FAQ data for non-question fields
        try {
            const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
            const res = await FAQHelper.getFAQData()
            if (fieldLabel.toLowerCase().includes('phone')) {
                FormFiller.fillWithValue(element, '+61' + res.phone);
                return
            }
            if (fieldLabel.toLowerCase().includes('middle')) {
                FormFiller.fillWithValue(element, '');
                return
            }
            const faqValue = await FAQHelper.getFAQValueForTextField(fieldLabel);
            console.log(faqValue)
            if (faqValue) {
                FormFiller.fillWithValue(element, faqValue);
                // console.log(`Filled with FAQ data: ${faqValue}`);
                return;
            }
        } catch {
            console.log("FAQ helper not available, continuing with other logic");
        }

        // SECOND PRIORITY: Check if this looks like a question that needs AI response
        if (FormFiller.isQuestionField(fieldLabel)) {
            // console.log(`Detected question field: ${fieldLabel}`);

            // Special case: years of experience (fallback if FAQ didn't handle it)
            const lowerLabel = fieldLabel.toLowerCase();
            if (lowerLabel.includes('years') && lowerLabel.includes('experience')) {
                FormFiller.fillWithValue(element, '4');
                // console.log(`Filled years of experience question with fallback "4"`);
            } else {
                // Use AI for other questions
                try {
                    const aiResponse = await APIClient.getAnswerForQuestion(fieldLabel);
                    if (aiResponse && aiResponse.trim() !== '') {
                        FormFiller.fillWithValue(element, aiResponse);
                        // console.log(`Filled with AI response: ${aiResponse.substring(0, 50)}...`);
                    } else {
                        FormFiller.fillWithFallback(element, '5');
                        // console.log(`AI response was empty, used fallback "5"`);
                    }
                } catch (error) {
                    console.error('Error getting AI response:', error);
                    FormFiller.fillWithFallback(element, '5');
                    // console.log(`Error occurred, used fallback "5"`);
                }
            }
        } else {
            // THIRD PRIORITY: For non-question fields, use the simple "5" fallback
            FormFiller.fillWithFallback(element, '5');
        }
    }

    static fillRadioElement(element) {
        const radioName = element.name;
        if (!radioName) return;
        const radioGroup = document.querySelectorAll(`input[name="${radioName}"]`);
        // Get the question context for this radio group
        let questionContext = '';
        try {
            questionContext = FormFiller.getRadioGroupContext(radioGroup) || '';
            // Try to get description if available
            const descEl = element.closest('.question')?.querySelector('.question-description');
            if (descEl && descEl.textContent) {
                questionContext += ' ' + descEl.textContent;
            }
        } catch { }
        const lowerContext = questionContext.toLowerCase();

        let targetOption = null;

        // Heuristics for common question types
        if (lowerContext.includes('visa') || lowerContext.includes('sponsorship')) {
            // Prefer "No" for visa/sponsorship
            radioGroup.forEach(radio => {
                const label = DOMUtils.getElementLabel(radio).toLowerCase();
                if (label.includes('no')) targetOption = radio;
            });
        } else if (lowerContext.includes('gender')) {
            // Prefer "Prefer not to say" or "Other"
            radioGroup.forEach(radio => {
                const label = DOMUtils.getElementLabel(radio).toLowerCase();
                if (label.includes('prefer not') || label.includes('other')) targetOption = radio;
            });
        } else if (lowerContext.match(/(year|date|graduat|experience)/)) {
            // Pick the most recent or highest value
            let maxValue = -Infinity;
            radioGroup.forEach(radio => {
                const label = DOMUtils.getElementLabel(radio);
                // Try to extract a number from the label
                const num = parseFloat(label.replace(/[^0-9.]/g, ''));
                if (!isNaN(num) && num > maxValue) {
                    maxValue = num;
                    targetOption = radio;
                }
            });
            // If no number found, pick the first option
            if (!targetOption) targetOption = radioGroup[0];
        } else if (lowerContext.match(/(yes|no|eligible|authorized|work|legal)/)) {
            // Prefer "Yes" for eligibility/authorization
            radioGroup.forEach(radio => {
                const label = DOMUtils.getElementLabel(radio).toLowerCase();
                if (label.includes('yes')) targetOption = radio;
            });
        }

        // Fallback: pick the first unchecked option
        if (!targetOption) {
            targetOption = Array.from(radioGroup).find(radio => !radio.checked) || radioGroup[0];
        }

        if (targetOption && !targetOption.checked) {
            targetOption.checked = true;
            targetOption.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
    static fillCheckboxElement(element) {
        console.log('im here nowwww')
        console.log(element.value)
        element.checked = true

    }

    static async fillSelectElement(element) {
        const options = element.options;
        if (options && options.length > 1) {
            // Check if this is a country code dropdown
            const elementLabel = DOMUtils.getElementLabel(element);

            // Try to import FAQ helper
            try {
                const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
                const faqData = await FAQHelper.getFAQData();

                if (FAQHelper.isCountryCodeField(elementLabel) && faqData) {
                    const matchingOption = FAQHelper.findCountryCodeOption(element, faqData);
                    if (matchingOption) {
                        element.selectedIndex = matchingOption.index;
                        element.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Selected FAQ country code: ${matchingOption.text}`);
                        return;
                    }
                }
                if (FAQHelper.isStateField(elementLabel) && faqData) {
                    const matchingOption = FAQHelper.findStateOption(element, faqData);
                    if (matchingOption) {
                        element.selectedIndex = matchingOption.index;
                        element.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`Selected FAQ STATE: ${matchingOption.text}`);
                        return;
                    }
                }
            } catch {
            }

            // Fallback to original logic
            console.log('ORIGINIAL LOGIC')
            element.selectedIndex = 2;
            element.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
}