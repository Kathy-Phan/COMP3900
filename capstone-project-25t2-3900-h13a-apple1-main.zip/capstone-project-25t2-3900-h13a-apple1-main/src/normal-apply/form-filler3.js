
import { AuthManager }  from '../auth-manager.js';
import { FAQCaching }   from '../faq-caching.js';
import { askGPT, buildPrompt, buildSelectPrompt } from './gpt-answerer.js';

// fn so we dont spam api
function pLimit(concurrency = 3) {
  const q = []; let active = 0;
  const next = () => {
    if (active >= concurrency || !q.length) return;
    const { fn, res, rej } = q.shift();
    active++;
    Promise.resolve(fn()).then(res, rej).finally(() => { active--; next(); });
  };
  return fn => new Promise((res,rej) => { q.push({fn,res,rej}); next(); });
}

//main function that runs autofill
export async function runNormalApply() {
  const jwt = await AuthManager.getStoredToken();
  if (!jwt) { console.error('[JobGen] No JWT — abort'); return; }

  const faq = (await FAQCaching.initialize(jwt)) || {};


  const controls = [...document.querySelectorAll('input,textarea')]
        .filter(el => !el.disabled && el.offsetParent);

  const fields = controls.map(el => ({
    el,
    label    : resolveLabel(el),
    nameType : getNameFieldType(resolveLabel(el))
  }));

  await fillViaFAQ(fields, faq);         
  await fillOpenEnded(fields, jwt, faq); 
  await fillDropdowns(jwt, faq);         


  try {
    const { handleFileUploads } = await import(
      chrome.runtime.getURL('normal-apply/file-upload.js')
    );
    await handleFileUploads({ jwt });
  } catch (e) {
    console.error('[JobGen] file-upload import/run failed', e);
  }

  try {
    tickConsent();          // auto-tick “I agree” box
    clickNextButton();      // optional auto-advance
  } finally {
    /* ALWAYS clear overflow */
    document.documentElement.style.overflow = '';
    document.body.style.overflow           = '';
  }

  /* keep scroll unlocked for a short period */
  forceUnlockScroll();
}

//faq info to pass into gpt api
async function fillViaFAQ(fields, faq) {
  let fullName = null;
  for (const f of fields) {
    if (f.el.value.trim()) continue;
    let ans = faq[normalize(f.label)] ?? null;
    if (!ans && f.nameType === 'full_name') {
      ans = [faq.first_name, faq.middle_name, faq.last_name]
            .filter(Boolean).join(' ');
    }
    if (ans) {
      if (f.nameType === 'full_name') fullName = ans;
      applyAnswer(f.el, ans);
    }
  }
  if (fullName) {
    const [first, middle, ...rest] = fullName.split(/\s+/);
    fillIfEmpty(fields,'first_name',first);
    fillIfEmpty(fields,'middle_name',middle);
    fillIfEmpty(fields,'last_name',rest.join(' '));
  }
}

function fillIfEmpty(fields, type, val) {
  if (!val) return;
  const t = fields.find(f => f.nameType === type && !f.el.value.trim());
  if (t) applyAnswer(t.el,val);
}

//gpt stuff
async function fillOpenEnded(fields, jwt, faq) {
  const limit = pLimit(3);
  for (const f of fields) {
    if (f.el.value.trim()) continue;
    if (['checkbox','radio','file'].includes(f.el.type)) continue;
    const prompt = buildPrompt(f.label);
    const ans    = await limit(() => askGPT(prompt, jwt, faq));
    if (ans) applyAnswer(f.el, ans);
  }
}

//drop down functionality
async function fillDropdowns(jwt, faq) {
  const selects = [...document.querySelectorAll('select')]
    .filter(s => !s.disabled && s.offsetParent && !s.value);

  for (const sel of selects) {
    const label = document.querySelector(`label[for='${sel.id}']`)
                  ?.innerText || sel.getAttribute('aria-label')
                  || sel.name || 'this field';

    const opts  = [...sel.options].map(o => o.textContent.trim());
    const base  = buildSelectPrompt(label, opts);
    const prompt= /job\s*board/i.test(label) ? base + ' ALWAYS answer: Seek' : base;

    let answer  = (await askGPT(prompt, jwt, faq))?.trim();

    if (!answer || /^(select|choose|--|please)/i.test(answer)) {
      if (/job\s*board/i.test(label)) answer = 'Seek';
    }
    if (!answer) continue;

    // 1 exact
    let matched = [...sel.options].find(
      o => o.textContent.trim().toLowerCase() === answer.toLowerCase()
    );
    // 2 yes/no
    if (!matched) {
      const Y=/^(yes|true|agree)$/i,N=/^(no|false|decline)$/i;
      matched=[...sel.options].find(o=>{
        const t=o.textContent.trim();
        return (Y.test(answer)&&Y.test(t))||(N.test(answer)&&N.test(t));
      });
    }
    // 3 substring
    if (!matched) {
      const norm = answer.toLowerCase();
      matched = [...sel.options].find(o => o.textContent.toLowerCase().includes(norm));
    }
    // 4 fallback 
    if (!matched && sel.options.length>1) matched = sel.options[1];

    if (matched) {
      const matchedIdx = [...sel.options].indexOf(matched);
      if (matchedIdx === 0) {                        // landed on placeholder
        matched = [...sel.options].find(o => /seek/i.test(o.textContent))
              || (sel.options.length>1 ? sel.options[1] : matched);
      }
      sel.value = matched.value;
      sel.dispatchEvent(new Event('input',{bubbles:true}));
      sel.dispatchEvent(new Event('change',{bubbles:true}));
    }
  }
}

//mainhelper
const NAME_LABEL_MAP = {
  first_name:[/^first\s*name$/i,/^given\s*name/i],
  middle_name:[/^middle\s*name$/i],
  last_name:[/^last\s*name$/i,/^family\s*name$/i,/^surname$/i],
  full_name:[/^full\s*name$/i,/^your\s*name$/i,/^applicant\s*name$/i]
};

function resolveLabel(el){
  const id=el.getAttribute('id');
  const lbl=id&&document.querySelector(`label[for="${id}"]`);
  return (lbl?.innerText||el.getAttribute('aria-label')||
          el.placeholder||el.name||'').trim();
}
function getNameFieldType(lbl=''){
  const n=lbl.toLowerCase().trim();
  for(const [t,r] of Object.entries(NAME_LABEL_MAP)) if(r.some(rx=>rx.test(n))) return t;
  return null;
}
const normalize=s=>s.toLowerCase().replace(/\s+/g,' ').trim();

function applyAnswer(el,ans){
  if(ans&&typeof ans==='object'&&'answer'in ans) ans=ans.answer;
  if(!ans) return;
  if(el.type==='checkbox'||el.type==='radio')
       el.checked=/^(yes|true|on|1)$/i.test(String(ans));
  else el.value=String(ans);
  el.dispatchEvent(new Event('input',{bubbles:true}));
  el.dispatchEvent(new Event('change',{bubbles:true}));
}

function clickNextButton(){
  const b=[...document.querySelectorAll('button')]
    .find(x=>/next|continue|submit|finish/i.test(x.innerText)&&!x.disabled);
  if(b) b.click();
}

//consent check funcitonality 
function tickConsent(){
  const native=[...document.querySelectorAll('input[type="checkbox"]')]
    .filter(cb=>!cb.checked&&!cb.disabled&&cb.offsetParent);
  const byAttr=native.find(cb=>/(terms|privacy)/i.test(cb.name+cb.id+cb.value));
  if(byAttr){byAttr.checked=true;byAttr.dispatchEvent(new Event('input',{bubbles:true}));
    byAttr.dispatchEvent(new Event('change',{bubbles:true}));return;}
  for(const cb of native){
    const txt=(document.querySelector(`label[for='${cb.id}']`)?.innerText||
              cb.closest('label')?.innerText||'').toLowerCase();
    if(/terms|privacy|policy/.test(txt)){cb.checked=true;
      cb.dispatchEvent(new Event('input',{bubbles:true}));
      cb.dispatchEvent(new Event('change',{bubbles:true}));return;}
  }
  const box=[...document.querySelectorAll('div,span')]
    .find(el=>el.offsetParent&&/(i\s+agree|terms.*conditions|privacy.*policy)/i.test(el.innerText));
  if(box) box.click();
}

//unlcok scroll bug in seek
function forceUnlockScroll(){
  const fix=()=>{
    document.documentElement.style.setProperty('overflow','auto','important');
    document.body.style.setProperty('overflow','auto','important');
    const app=document.getElementById('app');
    if(app&&app.getAttribute('aria-hidden')==='true') app.removeAttribute('aria-hidden');
  };
  fix();
  const t0=Date.now();
  const id=setInterval(()=>{fix();if(Date.now()-t0>800) clearInterval(id);},100);
}

//another unlock scroll function for seek
(function keepScrollAlive(){
  const opts={capture:true,passive:false};
  const unblock=e=>{
    if(e.defaultPrevented){e.stopImmediatePropagation();}
  };
  window.addEventListener('wheel',unblock,opts);
  window.addEventListener('touchmove',unblock,opts);
})();