//plimitr so no spam api-
function pLimit(concurrency = 3) {
  const queue = [];
  let active = 0;
  const next = () => {
    if (active >= concurrency || queue.length === 0) return;
    active++;
    const { fn, resolve, reject } = queue.shift();
    Promise.resolve(fn())
      .then(resolve, reject)
      .finally(() => {
        active--;
        next();
      });
  };
  return fn =>
    new Promise((resolve, reject) => {
      queue.push({ fn, resolve, reject });
      next();
    });
}

const limit = pLimit(3);
const cache = {};                 


function unwrapAnswer(raw) {
  let val = raw;
  for (let i = 0; i < 3; i++) {
    if (typeof val === 'string' && /^[[{]/.test(val.trim())) {
      try { val = JSON.parse(val); continue; } catch { /* not JSON */ }
    }
    break;
  }
  if (val && typeof val === 'object' && 'answer' in val) val = val.answer;
  return typeof val === 'string' ? val.trim() : String(val ?? '');
}

// helper: turn FAQ object into a short “k:v;” string
function compactProfile(obj) {
  return Object.entries(obj)
    .filter(([, v]) => v != null && v !== '')
    .map(([k, v]) => `${k}:${v}`)
    .join('; ');
}

//main logic
export async function askGPT(prompt, jwt, faq = null) {
  if (cache[prompt]) return cache[prompt];

 
  if (!faq) {
    const { faq_response } = await chrome.storage.local.get('faq_response');
    faq = faq_response || {};
  }

  const profile = compactProfile(faq);
  const body    = { question: `Applicant: ${profile}\n\n${prompt}` };

  const res = await limit(() =>
    fetch('https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_gpt_access', {
      method : 'POST',
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': `Bearer ${jwt}`,
      },
      body: JSON.stringify(body),
    }).then(r => r.json()).catch(() => ({}))
  );

  const cleaned = unwrapAnswer(res?.response?.answer ?? '');
  cache[prompt] = cleaned;
  return cleaned;
}


export function buildSelectPrompt(label, options) {
  return [
    `Choose ONE option for the field "${label}".`,
    `Return *exactly* the option text, no extra words.`,
    `Options: ${options.join(' | ')}`
  ].join(' ');
}
export function buildPrompt(label) {
  return `Fill the field "${label}" for this applicant. ` +
         `Return ONLY the value, with no extra words.`;
}