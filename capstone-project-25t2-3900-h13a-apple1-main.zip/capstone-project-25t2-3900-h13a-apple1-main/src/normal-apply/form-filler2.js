export class TestForm {
    static async startFilling() {
        console.log('SUCCESS')
        const formContainer = document.querySelector('#applicationFormWrapper');
        const formElements = formContainer.querySelectorAll('input, select, textarea');
        console.log(formElements)
        const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
        const res = await FAQHelper.getFAQData()
        console.log(res)
    }
}