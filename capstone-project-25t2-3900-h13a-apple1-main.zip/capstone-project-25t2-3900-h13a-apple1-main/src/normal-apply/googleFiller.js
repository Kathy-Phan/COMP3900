import { DOMUtils } from '../linkedin-easy-apply/dom-utils.js';
import { FormFiller } from '../linkedin-easy-apply/form-filler.js';
import { APIClient } from '../linkedin-easy-apply/api-caller.js';

export class GoogleFiller {
    static async startFilling() {
        const formElements = document.querySelectorAll('input, select, textarea');
        console.log(formElements)
        for (const el of formElements) {
            if (el.closest('#jobContainer')) {
                continue;
            }
            await this.fillElement(el)

        }
    }


    static async fillElement(element) {
        const elementType = element.type || element.tagName.toLowerCase();
        switch (elementType) {
            case 'text':
            case 'number':
            case 'email':
                await this.fillTextElement(element);
                break;
            case 'select-one':
            case 'select':
                await this.fillSelectElement(element);
                break;
            case 'radio':
                this.fillRadioElement(element);
                break;
            case 'checkbox':
                this.fillCheckboxElement(element);
                break;
            default:
                console.log(`Skipped unsupported element type: ${elementType}`);
        }
    }

    static async fillTextElement(element) {
        let fieldLabel = await DOMUtils.getElementLabel(element);
        console.log('im in text element: ' + fieldLabel)
        // Skip if we can't find a meaningful label
        if (fieldLabel === 'no-label-found' || fieldLabel.trim() === '') {
            fieldLabel = element.getAttribute('aria-label') || '';
            console.log('FIELD' + fieldLabel)
            // return;
        }
        const lowerLabel = fieldLabel.toLowerCase();
        // --- HIGHER EDUCATION DUMMY FILLERS ---
        if (lowerLabel.includes('school name')) {
            FormFiller.fillWithValue(element, 'University of New South Wales');
            return;
        }
        if (lowerLabel.includes('degree status')) {
            FormFiller.fillWithValue(element, 'Graduated');
            return;
        }
        if (lowerLabel.includes('degree')) {
            FormFiller.fillWithValue(element, 'Bachelor of Science');
            return;
        }
        if (lowerLabel.includes('major')) {
            FormFiller.fillWithValue(element, 'Computer Science');
            return;
        }
        // --- EMPLOYMENT DUMMY FILLERS ---
        if (lowerLabel.includes('employer name')) {
            FormFiller.fillWithValue(element, 'Google');
            return;
        }
        if (lowerLabel.includes('job title')) {
            FormFiller.fillWithValue(element, 'Software Engineer');
            return;
        }
        if (lowerLabel.includes('year')) {
            FormFiller.fillWithValue(element, '2018');
            return;
        }
        // --- LOCATION PREFERENCE DUMMY FILLER ---
        if (lowerLabel.includes('location') && lowerLabel.includes('prefer')) {
            FormFiller.fillWithValue(element, 'Sydney, Australia');
            return;
        }
        // --- COVER LETTER DYNAMIC FILLER ---
        if (lowerLabel.includes('cover letter')) {
            try {
                const coverLetter = await APIClient.getAnswerForQuestion('cover letter for google');
                if (coverLetter && coverLetter.trim() !== '') {
                    FormFiller.fillWithValue(element, coverLetter);
                } else {
                    FormFiller.fillWithValue(element, 'I am excited to apply to Google.');
                }
            } catch {
                FormFiller.fillWithValue(element, 'I am excited to apply to Google.');
            }
            return;
        }

        // FIRST PRIORITY: Check FAQ data for non-question fields
        try {
            const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
            const res = await FAQHelper.getFAQData()
            if (lowerLabel.includes('phone')) {
                FormFiller.fillWithValue(element, '+61' + res.phone);
                return
            }
            if (lowerLabel.includes('middle')) {
                FormFiller.fillWithValue(element, '');
                return
            }
            const faqValue = await FAQHelper.getFAQValueForTextField(fieldLabel);
            console.log(faqValue)
            if (faqValue) {
                FormFiller.fillWithValue(element, faqValue);
                // console.log(`Filled with FAQ data: ${faqValue}`);
                return;
            }
        } catch {
            console.log("FAQ helper not available, continuing with other logic");
        }

        // SECOND PRIORITY: Check if this looks like a question that needs AI response
        if (FormFiller.isQuestionField(fieldLabel)) {
            // console.log(`Detected question field: ${fieldLabel}`);

            // Special case: years of experience (fallback if FAQ didn't handle it)
            const lowerLabel = fieldLabel.toLowerCase();
            if (lowerLabel.includes('years') && lowerLabel.includes('experience')) {
                FormFiller.fillWithValue(element, '4');
                // console.log(`Filled years of experience question with fallback "4"`);
            } else {
                // Use AI for other questions
                try {
                    const aiResponse = await APIClient.getAnswerForQuestion(fieldLabel);
                    if (aiResponse && aiResponse.trim() !== '') {
                        FormFiller.fillWithValue(element, aiResponse);
                        // console.log(`Filled with AI response: ${aiResponse.substring(0, 50)}...`);
                    } else {
                        FormFiller.fillWithFallback(element, '5');
                        // console.log(`AI response was empty, used fallback "5"`);
                    }
                } catch (error) {
                    console.error('Error getting AI response:', error);
                    FormFiller.fillWithFallback(element, '5');
                    // console.log(`Error occurred, used fallback "5"`);
                }
            }
        } else {
            // THIRD PRIORITY: For non-question fields, use the simple "5" fallback
            FormFiller.fillWithFallback(element, '5');
        }
    }

    static async fillSelectElement(element) {
        let fieldLabel = await DOMUtils.getElementLabel(element);
        if (fieldLabel === 'no-label-found' || !fieldLabel.trim()) {
            fieldLabel = element.getAttribute('aria-label') || '';
        }
        const lowerLabel = fieldLabel.toLowerCase();
        // --- DEGREE SELECT DUMMY FILLER ---
        if (lowerLabel.includes('degree')) {
            // Try to select 'Bachelor of Science' or closest match
            let found = false;
            for (let i = 0; i < element.options.length; i++) {
                const opt = element.options[i];
                if (opt.text && opt.text.toLowerCase().includes('bachelor of science')) {
                    element.selectedIndex = i;
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                    found = true;
                    break;
                }
            }
            if (!found) {
                // fallback: select the first non-placeholder option
                for (let i = 0; i < element.options.length; i++) {
                    const opt = element.options[i];
                    if (opt.text && !opt.text.toLowerCase().includes('select')) {
                        element.selectedIndex = i;
                        element.dispatchEvent(new Event('change', { bubbles: true }));
                        break;
                    }
                }
            }
            return;
        }
        // fallback: select the first non-placeholder option
        for (let i = 0; i < element.options.length; i++) {
            const opt = element.options[i];
            if (opt.text && !opt.text.toLowerCase().includes('select')) {
                element.selectedIndex = i;
                element.dispatchEvent(new Event('change', { bubbles: true }));
                break;
            }
        }
    }

    static fillRadioElement(element) {
        // Find the parent radiogroup if this is a radio input
        let radioGroup = element;
        if (element.type === 'radio') {
            radioGroup = element.closest('[role="radiogroup"]');
        }

        if (!radioGroup) {
            console.log('No radiogroup found for radio element');
            return;
        }

        // Get the question from aria-label
        const question = radioGroup.getAttribute('aria-label');
        if (!question) {
            console.log('No aria-label found for radiogroup');
            return;
        }

        console.log('Processing radio question:', question);
        const lowerQuestion = question.toLowerCase();

        // Find all radio inputs in this group
        const radioInputs = radioGroup.querySelectorAll('input[type="radio"]');
        if (radioInputs.length === 0) {
            console.log('No radio inputs found in radiogroup');
            return;
        }

        let targetRadio = null;

        // Enhanced heuristics for common question types (adapted from Amazon filler)
        if (lowerQuestion.includes('visa') || lowerQuestion.includes('sponsorship')) {
            // Prefer "No" for visa/sponsorship questions
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && label.textContent.toLowerCase().includes('no')) {
                    targetRadio = radio;
                }
            });
        } else if (lowerQuestion.includes('gender')) {
            // Prefer "Prefer not to say" or "Other"
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && (label.textContent.toLowerCase().includes('prefer not') ||
                    label.textContent.toLowerCase().includes('other'))) {
                    targetRadio = radio;
                }
            });
        } else if (lowerQuestion.match(/(year|date|graduat|experience)/)) {
            // Pick the most recent or highest value
            let maxValue = -Infinity;
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label) {
                    // Try to extract a number from the label
                    const num = parseFloat(label.textContent.replace(/[^0-9.]/g, ''));
                    if (!isNaN(num) && num > maxValue) {
                        maxValue = num;
                        targetRadio = radio;
                    }
                }
            });
            // If no number found, pick the first option
            if (!targetRadio) targetRadio = radioInputs[0];
        } else if (lowerQuestion.match(/(yes|no|eligible|authorized|work|legal|right to work)/)) {
            // Prefer "Yes" for eligibility/authorization/work rights
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && label.textContent.toLowerCase().includes('yes')) {
                    targetRadio = radio;
                }
            });
        } else if (lowerQuestion.includes('disability') || lowerQuestion.includes('veteran')) {
            // Prefer "No" for disability/veteran status (unless specifically asking about veteran benefits)
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && label.textContent.toLowerCase().includes('no')) {
                    targetRadio = radio;
                }
            });
        } else if (lowerQuestion.includes('remote') || lowerQuestion.includes('work from home')) {
            // Prefer "Yes" for remote work questions
            radioInputs.forEach(radio => {
                const label = radio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && label.textContent.toLowerCase().includes('yes')) {
                    targetRadio = radio;
                }
            });
        }

        // Fallback: pick the first unchecked option
        if (!targetRadio) {
            targetRadio = Array.from(radioInputs).find(radio => !radio.checked) || radioInputs[0];
        }

        // Select the target radio
        if (targetRadio && !targetRadio.checked) {
            // First, try clicking the radio button container (Google's preferred method)
            const radioContainer = targetRadio.closest('.VfPpkd-I9GLp-yrriRe');
            if (radioContainer) {
                // Simulate a real click on the container
                radioContainer.click();

                // Also dispatch click event on the radio input itself
                targetRadio.click();

                // Set checked state
                targetRadio.checked = true;

                // Dispatch multiple events to ensure Google's Material Design registers it
                targetRadio.dispatchEvent(new Event('change', { bubbles: true }));
                targetRadio.dispatchEvent(new Event('input', { bubbles: true }));
                targetRadio.dispatchEvent(new Event('click', { bubbles: true }));

                // Also dispatch on the container
                radioContainer.dispatchEvent(new Event('click', { bubbles: true }));
            } else {
                // Fallback to direct radio manipulation
                targetRadio.checked = true;
                targetRadio.click();
                targetRadio.dispatchEvent(new Event('change', { bubbles: true }));
                targetRadio.dispatchEvent(new Event('input', { bubbles: true }));
            }

            const label = targetRadio.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
            console.log(`Selected radio option "${label?.textContent || 'unknown'}" for: "${question}"`);
        }
    }
    static fillCheckboxElement(element) {
        // Find the parent checkbox group if this is a checkbox input
        let checkboxGroup = element;
        if (element.type === 'checkbox') {
            checkboxGroup = element.closest('[role="checkbox"]') || element.closest('.woOqWc');
        }

        if (!checkboxGroup) {
            console.log('No checkbox group found for checkbox element');
            return;
        }

        // Get the question from the first checkbox's aria-label
        const firstCheckbox = checkboxGroup.querySelector('input[type="checkbox"]');
        if (!firstCheckbox) {
            console.log('No checkbox inputs found in group');
            return;
        }

        const ariaLabel = firstCheckbox.getAttribute('aria-label');
        if (!ariaLabel) {
            console.log('No aria-label found for checkbox group');
            return;
        }

        // Extract the question from aria-label (format: "Option for question: Question text")
        const questionMatch = ariaLabel.match(/for question: (.+?):/);
        const question = questionMatch ? questionMatch[1] : ariaLabel;

        console.log('Processing checkbox question:', question);
        const lowerQuestion = question.toLowerCase();

        // Find all checkbox inputs in this group
        const checkboxInputs = checkboxGroup.querySelectorAll('input[type="checkbox"]');
        if (checkboxInputs.length === 0) {
            console.log('No checkbox inputs found in group');
            return;
        }

        let targetCheckbox = null;

        // Logic for different question types
        if (lowerQuestion.includes('race') || lowerQuestion.includes('ethnic') || lowerQuestion.includes('ethnicity')) {
            // Select "I choose not to disclose" for race/ethnicity questions
            checkboxInputs.forEach(checkbox => {
                const label = checkbox.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
                if (label && label.textContent.toLowerCase().includes('choose not to disclose')) {
                    targetCheckbox = checkbox;
                }
            });
        } else {
            // For other questions, select the first checkbox
            targetCheckbox = checkboxInputs[0];
        }

        // Select the target checkbox
        if (targetCheckbox && !targetCheckbox.checked) {
            // Click the checkbox container (Google's preferred method)
            const checkboxContainer = targetCheckbox.closest('.VfPpkd-I9GLp-yrriRe');
            if (checkboxContainer) {
                // Simulate a real click on the container
                checkboxContainer.click();

                // Also dispatch click event on the checkbox input itself
                targetCheckbox.click();

                // Set checked state
                targetCheckbox.checked = true;

                // Dispatch multiple events to ensure Google's Material Design registers it
                targetCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
                targetCheckbox.dispatchEvent(new Event('input', { bubbles: true }));
                targetCheckbox.dispatchEvent(new Event('click', { bubbles: true }));

                // Also dispatch on the container
                checkboxContainer.dispatchEvent(new Event('click', { bubbles: true }));
            } else {
                // Fallback to direct checkbox manipulation
                targetCheckbox.checked = true;
                targetCheckbox.click();
                targetCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
                targetCheckbox.dispatchEvent(new Event('input', { bubbles: true }));
            }

            const label = targetCheckbox.closest('.VfPpkd-I9GLp-yrriRe')?.querySelector('label');
            console.log(`Selected checkbox option "${label?.textContent || 'unknown'}" for: "${question}"`);
        }
    }
}