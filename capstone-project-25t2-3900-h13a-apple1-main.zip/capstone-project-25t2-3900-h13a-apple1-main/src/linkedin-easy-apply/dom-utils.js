// DOM utility functions
export class DOMUtils {

    // Helper function to get label text for form elements
    static getElementLabel(element) {
        // Method 1: Check for associated label
        if (element.id) {

            const label = document.querySelector(`label[for="${element.id}"]`);
            if (label) return label.textContent.trim();
        }

        // Method 2: Check parent label
        const parentLabel = element.closest('label');
        if (parentLabel) return parentLabel.textContent.trim();

        // Method 3: Look for nearby text (previous sibling)
        let sibling = element.previousElementSibling;
        while (sibling) {

            if (sibling.textContent && sibling.textContent.trim().length > 0) {
                return sibling.textContent.trim();
            }
            sibling = sibling.previousElementSibling;
        }

        // Method 4: Check container for label - NEW METHOD
        // Find closest parent container and check for label within it
        // Go up to 3 levels to find a container
        let parentContainer = element.parentElement;
        // Go up to 3 levels to find a container
        for (let i = 0; i < 3 && parentContainer; i++) {
            const labelInParent = element.querySelector('label');
            if (labelInParent) {
                // Extract just the text without any required asterisks
                const labelText = labelInParent.textContent.trim().replace(/\s*\*\s*$/, '');
                return labelText;
            }
            // parentContainer = parentContainer.parentElement;
        }

        // Method 5: Check aria-label
        if (element.getAttribute('aria-label')) {
            return element.getAttribute('aria-label');
        }

        // Method 6: Check placeholder
        if (element.getAttribute('placeholder')) {
            return element.getAttribute('placeholder');
        }

        return 'no-label-found';
    }

    // Wait for DOM changes in a specific container
    static waitForDomChange(container, timeout = 4000) {
        return new Promise((resolve) => {
            const observer = new MutationObserver((mutations) => {
                // Check if there were actual meaningful changes
                const hasChanges = mutations.some(mutation =>
                    mutation.addedNodes.length > 0 ||
                    mutation.removedNodes.length > 0
                );

                if (hasChanges) {
                    observer.disconnect();
                    resolve();
                }
            });

            observer.observe(container, { childList: true, subtree: true });

            setTimeout(() => {
                observer.disconnect();
                resolve();
            }, timeout);
        });
    }

    // Check if current page is resume upload page
    static async checkIfResumeUploadPage(modal) {
        console.log('IN checkIfResumeUploadPage')
        const resumeKeywords = [
            // 'resume',
            'cv',
            'upload',
            'attach',
            'document',
            'file'
        ];

        // Look for file input elements
        const fileInputs = modal.querySelectorAll('input[type="file"]');
        console.log("File inputs found:", fileInputs.length);
        if (fileInputs.length > 0) {
            console.log("File input detected - likely resume upload page");
            return true;
        }

        // Look for resume-related keywords in headings or labels
        const headings = modal.querySelectorAll('h1, h2, h3, h4, h5, h6, label, .jobs-easy-apply-modal__title');
        for (const heading of headings) {
            const headingText = heading.textContent.toLowerCase();
            if (resumeKeywords.some(keyword => headingText.includes(keyword))) {
                console.log("Resume-related heading detected:", heading.textContent);
                return true;
            }
        }

        return false;
    }

    // Detect the current form section based on page content
    static detectCurrentFormSection(modal) {
        // Look for headings, titles, and labels to determine what section we're on
        const selectors = [
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
            '.jobs-easy-apply-modal__title',
            '.jobs-easy-apply-form-section__title',
            'legend',
            '[role="heading"]'
        ];

        const contentElements = modal.querySelectorAll(selectors.join(', '));
        const allText = Array.from(contentElements)
            .map(el => el.textContent.trim().toLowerCase())
            .join(' ');

        // Also check form labels and input placeholders for context
        const labels = Array.from(modal.querySelectorAll('label'))
            .map(label => label.textContent.trim().toLowerCase())
            .join(' ');
            
        const inputs = Array.from(modal.querySelectorAll('input[placeholder], textarea[placeholder]'))
            .map(input => input.getAttribute('placeholder').toLowerCase())
            .join(' ');

        const combinedText = allText + ' ' + labels + ' ' + inputs;

        // Define section patterns in order of priority (most specific first)
        const sections = [
            {
                name: "Resume Upload",
                keywords: ['resume', 'cv', 'upload', 'attach', 'document', 'file'],
                weight: 3 // Higher weight for file uploads as they're very specific
            },
            {
                name: "Review Application",
                keywords: ['review', 'submit', 'final', 'confirm', 'application summary'],
                weight: 3 // High weight for review pages
            },
            {
                name: "Contact Information",
                keywords: ['contact', 'phone', 'email', 'address', 'mobile', 'telephone'],
                weight: 2
            },
            {
                name: "Personal Information", 
                keywords: ['personal', 'first name', 'last name', 'profile', 'linkedin'],
                weight: 2
            },
            {
                name: "Work Experience",
                keywords: ['experience', 'work', 'employment', 'years', 'previous', 'current', 'job title'],
                weight: 2
            },
            {
                name: "Education",
                keywords: ['education', 'university', 'degree', 'school', 'college', 'graduation'],
                weight: 2
            },
            {
                name: "Additional Questions",
                keywords: ['additional', 'questions', 'eligibility', 'authorized', 'visa', 'location', 'willing', 'relocate', 'cover letter'],
                weight: 1
            }
        ];

        // Find the best matching section with weighted scoring
        let bestMatch = null;
        let bestScore = 0;

        for (const section of sections) {
            const matches = section.keywords.filter(keyword => 
                combinedText.includes(keyword)
            ).length;
            
            const score = matches * section.weight;
            
            if (score > bestScore) {
                bestScore = score;
                bestMatch = section;
            }
        }

        if (bestMatch) {
            console.log(`Detected form section: ${bestMatch.name} (score: ${bestScore})`);
            return bestMatch.name;
        }

        // Fallback: check if we can see form fields to make a guess
        const formInputs = modal.querySelectorAll('input, select, textarea');
        if (formInputs.length > 0) {
            // Analyze the types of inputs to make a better guess
            const inputTypes = Array.from(formInputs).map(input => {
                const label = DOMUtils.getElementLabel(input).toLowerCase();
                if (label.includes('email')) return 'contact';
                if (label.includes('phone')) return 'contact';
                if (label.includes('name')) return 'personal';
                if (label.includes('experience')) return 'experience';
                return 'general';
            });

            if (inputTypes.includes('contact')) return "Contact Information";
            if (inputTypes.includes('personal')) return "Personal Information";
            if (inputTypes.includes('experience')) return "Work Experience";
            
            return "Application Form";
        }

        return "Processing Application";
    }

    // Find and click next/continue buttons
    static async findAndClickNextButton(modal, IsAutoSubmit) {
        console.log('IN FINDANDCLICKNEXTBUTTON')
        
        // Debug: Log all buttons in the modal
        const allButtons = modal.querySelectorAll('button');
        console.log(`Found ${allButtons.length} buttons in modal:`, Array.from(allButtons).map(btn => ({
            text: btn.textContent.trim(),
            ariaLabel: btn.getAttribute('aria-label'),
            disabled: btn.disabled,
            classes: btn.className
        })));
        
        // Find and click the next button (including "Review" button)
        const nextButtonSelectors = [
            '[data-easy-apply-next-button]',
            '[aria-label*="next"]',
            '[aria-label*="Next"]',
            '[aria-label*="Continue"]',
            '[aria-label*="Review"]',
            '.artdeco-button--primary'
        ];

        let nextButton = null;

        // Try each selector
        for (const selector of nextButtonSelectors) {
            const buttons = modal.querySelectorAll(selector);
            console.log(`Selector "${selector}" found ${buttons.length} buttons`);
            for (const btn of buttons) {
                console.log(`Checking button: "${btn.textContent.trim()}" (disabled: ${btn.disabled})`);
                console.log(`Button aria-label: "${btn.getAttribute('aria-label')}"`);
                
                const buttonText = btn.textContent.toLowerCase().trim();
                const ariaLabel = btn.getAttribute('aria-label')?.toLowerCase() || '';
                
                // More flexible matching - check if button contains relevant text or aria-label
                const isNextButton = buttonText.includes('next') || ariaLabel.includes('next');
                const isContinueButton = buttonText.includes('continue') || ariaLabel.includes('continue');
                const isReviewButton = buttonText.includes('review') || ariaLabel.includes('review');
                
                console.log(`Button matches - Next: ${isNextButton}, Continue: ${isContinueButton}, Review: ${isReviewButton}`);
                
                if (isNextButton || isContinueButton || isReviewButton) {
                    nextButton = btn;
                    console.log(`✓ SELECTED matching button: "${btn.textContent.trim()}" with aria-label: "${btn.getAttribute('aria-label')}"`);
                    break;
                }
            }
            if (nextButton) {
                console.log(`✓ Found nextButton with selector: ${selector}`);
                break;
            }
        }

        // Also check for buttons with "Next" or "Review" text content
        if (!nextButton) {
            console.log('No button found with selectors, checking all buttons by text...');
            for (const btn of allButtons) {
                console.log(`Checking button text: "${btn.textContent.toLowerCase()}" (disabled: ${btn.disabled})`);
                if (btn.textContent.toLowerCase().includes('next') ||
                    btn.textContent.toLowerCase().includes('review')) {
                    nextButton = btn;
                    console.log(`Found matching button by text: "${btn.textContent.trim()}"`);
                    break;
                }
            }
        }

        // apply -> autoSubmit is true and next button is true -> make autoSubmit true for the next button
        console.log(`Button check: nextButton=${!!nextButton}, disabled=${nextButton?.disabled}`);
        
        if (nextButton && !nextButton.disabled) {
            console.log("✓ PROCEEDING TO CLICK button:", nextButton.textContent.trim());
            
            // Dispatch navigation event with button text
            const buttonText = nextButton.textContent.trim();
            document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: `Clicking "${buttonText}" Button` }
            }));
            
            // Add safety check to prevent clicking the same button multiple times
            const clickingTimestamp = nextButton.dataset.clickingTimestamp;
            const now = Date.now();
            
            if (nextButton.dataset.clicking && clickingTimestamp && (now - parseInt(clickingTimestamp)) < 2000) {
                console.log("Button recently clicked, skipping (within 2 seconds)");
                return false;
            }
            
            console.log("✓ CLICKING BUTTON NOW:", nextButton.textContent.trim());
            nextButton.dataset.clicking = 'true';
            nextButton.dataset.clickingTimestamp = now.toString();
            
            await new Promise(resolve => setTimeout(resolve, 300));
            nextButton.click();
            
            // Clear the flag after a delay
            setTimeout(() => {
                delete nextButton.dataset.clicking;
                delete nextButton.dataset.clickingTimestamp;
            }, 3000);
            
            return true;
        } else {
            console.log('No next button found or button is disabled.');
            if (nextButton) {
                console.log(`Found button "${nextButton.textContent.trim()}" but it's disabled: ${nextButton.disabled}`);
            } else {
                console.log('No next/review button found at all');
            }
            
            if (IsAutoSubmit) {
                console.log("CLICKED SUBMIT")
                
                const submitButton = [...modal.querySelectorAll('button, [role="button"]')].find(btn =>
                    btn.textContent.toLowerCase().includes('submit') ||
                    btn.getAttribute('aria-label')?.toLowerCase().includes('submit')
                );
                if (submitButton) {
                    console.log('SIMULATE SUBMIT CLICK')
                    
                    // Dispatch submitting event
                    document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                        detail: { section: 'Submitting Application' }
                    }));
                    
                    submitButton.click();
                    
                    // Dispatch submit completed event
                    document.dispatchEvent(new CustomEvent('jobgen-submit-clicked', {
                        detail: { success: true }
                    }));
                    
                    return false;
                } else {
                    // No submit button found - process complete
                    document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                        detail: { section: 'Application Complete' }
                    }));
                }
                
            } else {
                // Review mode - process complete
                document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                    detail: { section: 'Review Complete - Ready for Manual Submission' }
                }));
            }
            
            console.log("No next/review button found or button is disabled");
            // Dispatch process completion
            document.dispatchEvent(new CustomEvent('jobgen-form-complete'));
            return false;
        }
    }
}
