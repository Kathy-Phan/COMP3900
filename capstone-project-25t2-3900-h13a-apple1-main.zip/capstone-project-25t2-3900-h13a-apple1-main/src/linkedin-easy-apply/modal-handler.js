// Modal handling and navigation logic
import { FormFiller } from './form-filler.js';
import { DOMUtils } from './dom-utils.js';

export class ModalHandler {
    constructor(modal) {
        this.modal = modal;
        this.nextButtonSelectors = [
            '[data-easy-apply-next-button]',
            '[aria-label*="next"]',
            '[aria-label*="Next"]',
            '[aria-label*="Continue"]',
            'button:contains("Next")',
            '.artdeco-button--primary'
        ];
    }

    // Static method to check for modal existence
    static checkForModal(modalIdentifier = '.jobs-easy-apply-modal', timeout = 5000) {
        return new Promise((resolve) => {
            const exists = document.querySelector(modalIdentifier);
            if (exists) {
                // Dispatch modal opened event and detect initial section
                document.dispatchEvent(new CustomEvent('jobgen-modal-opened'));
                
                // Detect and report the initial form section
                const currentSection = DOMUtils.detectCurrentFormSection(exists);
                document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                    detail: { section: currentSection }
                }));
                
                return resolve(exists);
            }

            const observer = new MutationObserver(() => {
                const modal = document.querySelector(modalIdentifier);
                if (modal) {
                    console.log('Modal found:', modal);
                    // Dispatch modal opened event and detect initial section
                    document.dispatchEvent(new CustomEvent('jobgen-modal-opened'));
                    
                    // Wait a moment for modal content to load, then detect section
                    setTimeout(() => {
                        const currentSection = DOMUtils.detectCurrentFormSection(modal);
                        document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                            detail: { section: currentSection }
                        }));
                    }, 500);
                    
                    observer.disconnect();
                    resolve(modal);
                }
            });

            observer.observe(document.body, { childList: true, subtree: true });

            setTimeout(() => {
                observer.disconnect();
                resolve(null);
            }, timeout);
        });
    }

    // Start the automation process
    async startAutomation(autoSubmit) {
        this.autoSubmit = autoSubmit;
        
        // Add a small delay to let the initial section detection settle
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Dispatch that we're starting the form filling process
        document.dispatchEvent(new CustomEvent('jobgen-current-section', {
            detail: { section: 'Analyzing Form Structure' }
        }));
        
        // Auto-fill and auto-click next on the initial page
        await FormFiller.autoFillForms(this.modal, autoSubmit);
        
        // Start listening for next button clicks
        this.listenForNextButton();
    }

    // Listen for next button clicks and handle page transitions
    listenForNextButton() {
        console.log('in listenfor next button')
        return new Promise((resolve) => {
            let isProcessing = false;
            const attachListeners = () => {
                if (isProcessing) return; // Prevent concurrent execution
                isProcessing = true;

                this.nextButtonSelectors.forEach(selector => {
                    // Handle text-based selectors
                    if (selector.includes(':contains')) {
                        const buttons = this.modal.querySelectorAll('button');
                        buttons.forEach(btn => {
                            if (btn.textContent.toLowerCase().includes('next') &&
                                !btn.hasAttribute('data-next-listener')) {
                                btn.setAttribute('data-next-listener', 'true');
                            }
                        });
                    } else {
                        const buttons = this.modal.querySelectorAll(selector);
                        buttons.forEach(btn => {
                            if (!btn.hasAttribute('data-next-listener')) {
                                btn.setAttribute('data-next-listener', 'true');
                            }
                        });
                    }
                });
                setTimeout(() => { isProcessing = false; }, 100); // Throttle
            };
 
            // Initial attachment
            attachListeners();

            // Throttled observer
            let observerTimeout;
            const observer = new MutationObserver(() => {
                clearTimeout(observerTimeout);
                observerTimeout = setTimeout(attachListeners, 200); // Debounce
            });
            observer.observe(this.modal, { childList: true, subtree: true });

            // Resolve after initial setup
            resolve();
        });
    }

    // Handle next button click events
    async handleNextClick() {
        console.log("in handle next click");
        // Dispatch next clicked event
        document.dispatchEvent(new CustomEvent('jobgen-next-clicked'));
        DOMUtils.waitForDomChange(this.modal).then(async () => {
            await FormFiller.autoFillForms(this.modal, this.autoSubmit);
        });
    }
}