// API client for external service calls
export class APIClient {
    static API_URL = "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_question";

    static async getAnswerForQuestion(question) {
        try {
            console.log(`Making API call for question: ${question}`);

            // Get token from storage
            const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
            const token = await AuthManager.getStoredToken();

            if (!token) {
                throw new Error('No authentication token available');
            }

            const response = await fetch(APIClient.API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    question: question
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const responseData = await response.json();

            if (responseData.status === "success" && responseData.response.answer) {
                const parsedAnswer = JSON.parse(responseData.response.answer);
                const actualAnswer = parsedAnswer.answer;
                return actualAnswer;
            } else {
                throw new Error('No answer received from API');
            }

        } catch (error) {
            console.error('Error in API call:', error);
            throw error; // Re-throw to allow caller to handle
        }
    }
    // Optional: Add method to test API connectivity
    static async testConnection() {
        try {
            console.log("API connection test successful");
            return true;
        } catch (error) {
            console.error("API connection test failed:", error);
            return false;
        }
    }
}