// Form filling logic
import { DOMUtils } from './dom-utils.js';
import { APIClient } from './api-caller.js';

export class FormFiller {
    static async autoFillForms(modal, autoSubmit) {
        console.log("=== STARTING AUTO-FORM FILLING ===");

        let continueProcessing = true;
        let stepCount = 0;
        const maxSteps = 10; // prevent infinite loops

        while (continueProcessing && stepCount < maxSteps) {
            stepCount++;
            console.log(`--- Processing Form Step ${stepCount} ---`);

            // Small delay to let DOM settle
            await new Promise(resolve => setTimeout(resolve, 300));
            await DOMUtils.waitForDomChange(modal, 1000);
            await FormFiller.fillRegularForms(modal);
            const isResumeUploadPage = await DOMUtils.checkIfResumeUploadPage(modal);
            if (isResumeUploadPage) {
                console.log("📄 Resume upload page detected - handling resume upload");
                document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                    detail: { section: 'Uploading Resume' }
                }));
                await FormFiller.handleResumeUpload(modal, autoSubmit);
            } else {
                // fillRegularForms will detect and report what it's filling
                await FormFiller.fillRegularForms(modal);
            }

            // After filling, check if we need to move to the next step
            document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: 'Looking for Next Button' }
            }));

            const clickedNextOrSubmit = await DOMUtils.findAndClickNextButton(modal, autoSubmit);

            if (!clickedNextOrSubmit) {
                console.log("No more 'Next' or 'Review' buttons found, or a 'Submit' button was clicked.");
                // Dispatch form completion event
                document.dispatchEvent(new CustomEvent('jobgen-form-filled'));
                continueProcessing = false; // stop the loop
            } else {
                console.log("Moving to next step...");
                // Small delay before next iteration
                await new Promise(r => setTimeout(r, 800));
            }
        }

        if (stepCount >= maxSteps) {
            console.warn("Max steps reached. Force autofill end");
            document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: 'Max Steps Reached - Process Complete' }
            }));
        }
        console.log("=== END AUTO-FORM FILLING ===");
    }


    // Fill a single form element
    static async fillElement(element, modal) {
        const elementType = element.type || element.tagName.toLowerCase();

        // Handle select elements
        if (elementType === 'select' || elementType === 'select-one') {
            FormFiller.fillSelectElement(element);
            return;
        }

        switch (elementType) {
            case 'text':
            case 'textarea':
            case 'email':
            case 'tel':
            case 'number':
                await FormFiller.fillTextElement(element);
                break;

            case 'radio':
                FormFiller.fillRadioElement(element, modal);
                break;

            case 'checkbox':
                FormFiller.fillCheckboxElement(element);
                break;

            default:
                console.log(`Skipped unsupported element type: ${elementType}`);
        }
    }

    // Fill select/dropdown elements
    static async fillSelectElement(element) {
        const options = element.options;
        if (options && options.length > 1) {
            // Check if this is a country code dropdown
            const elementLabel = DOMUtils.getElementLabel(element);

            // Try to import FAQ helper
            try {
                const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
                const faqData = await FAQHelper.getFAQData();

                if (FAQHelper.isCountryCodeField(elementLabel) && faqData) {
                    const matchingOption = FAQHelper.findCountryCodeOption(element, faqData);
                    if (matchingOption) {
                        element.selectedIndex = matchingOption.index;
                        element.dispatchEvent(new Event('change', { bubbles: true }));
                        return;
                    }
                }
            } catch {
            }

            // Fallback to original logic
            const hasRealSelection = element.selectedIndex > 0 ||
                (element.selectedIndex === 0 && !options[0].textContent.toLowerCase().includes('select'));

            if (!hasRealSelection) {
                element.selectedIndex = options.length - 2;
                element.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    }

    // Fill text-based elements with AI or fallback values
    // Fill text-based elements with FAQ, AI or fallback values
    static async fillTextElement(element) {
        const fieldLabel = await DOMUtils.getElementLabel(element);
        console.log('im in text element: ' + fieldLabel)

        // Skip if we can't find a meaningful label
        if (fieldLabel === 'no-label-found' || fieldLabel.trim() === '') {
            FormFiller.fillWithFallback(element, '5');
            return;
        }

        // FIRST PRIORITY: Check FAQ data for non-question fields
        try {
            const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));
            // update here
            const faqValue = await FAQHelper.getFAQValueForTextField(fieldLabel);
            console.log(faqValue)
            if (faqValue) {
                FormFiller.fillWithValue(element, faqValue);
                if (element.id.toLowerCase().includes('typeahead')) {
                    element.blur()
                }
                return;
            }
        } catch {
            console.log("FAQ helper not available, continuing with other logic");
        }

        // SECOND PRIORITY: Check if this looks like a question that needs AI response
        if (FormFiller.isQuestionField(fieldLabel)) {
            // Special case: years of experience (fallback if FAQ didn't handle it)
            const lowerLabel = fieldLabel.toLowerCase();
            if (lowerLabel.includes('years') && lowerLabel.includes('experience')) {
                FormFiller.fillWithValue(element, '4');
            } else {
                // Use AI for other questions
                try {
                    const aiResponse = await APIClient.getAnswerForQuestion(fieldLabel);
                    if (aiResponse && aiResponse.trim() !== '') {
                        FormFiller.fillWithValue(element, aiResponse);
                    } else {
                        FormFiller.fillWithFallback(element, '5');
                    }
                } catch (error) {
                    console.error('Error getting AI response:', error);
                    FormFiller.fillWithFallback(element, '5');
                }
            }
        } else {
            // THIRD PRIORITY: For non-question fields, use the simple "5" fallback
            FormFiller.fillWithFallback(element, '5');
        }
    }

    // Fill radio button elements
    static fillRadioElement(element, modal) {
        const radioName = element.name;
        if (radioName) {
            const radioGroup = modal.querySelectorAll(`input[name="${radioName}"]`);

            // Get the question context for this radio group
            const questionContext = FormFiller.getRadioGroupContext(radioGroup, modal);
            const lowerContext = questionContext.toLowerCase();

            let targetOption = null;

            // Check if question is about sponsorship or visa
            if ((lowerContext.includes('sponsorship') || lowerContext.includes('visa')) &&
                !lowerContext.includes('have') && !lowerContext.includes('possess')) {
                // Answer "No" for sponsorship/visa questions
                radioGroup.forEach(radio => {
                    const label = DOMUtils.getElementLabel(radio);
                    if (label.toLowerCase().includes('no')) {
                        targetOption = radio;
                    }
                });
                console.log(`Detected sponsorship/visa question - selecting "No"`);
            } else {
                // Answer "Yes" for all other questions
                radioGroup.forEach(radio => {
                    const label = DOMUtils.getElementLabel(radio);
                    if (label.toLowerCase().includes('yes')) {
                        targetOption = radio;
                    }
                });
            }

            // If target option not found, fall back to first option
            if (!targetOption) {
                targetOption = radioGroup[0];
            }

            if (targetOption && !targetOption.checked) {
                targetOption.checked = true;
                targetOption.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    }

    // Fill checkbox elements
    static fillCheckboxElement(element) {
        const checkboxLabel = DOMUtils.getElementLabel(element);
        if (checkboxLabel.toLowerCase().includes('yes') && !element.checked) {
            element.checked = true;
            element.dispatchEvent(new Event('change', { bubbles: true }));
            console.log(`Checked checkbox:`, checkboxLabel);
        }
    }

    // Handle fieldsets (radio button groups)
    static handleFieldsets(modal) {
        const fieldsets = modal.querySelectorAll('fieldset');
        fieldsets.forEach((fieldset) => {
            const radios = fieldset.querySelectorAll('input[type="radio"]');
            if (radios.length > 0) {
                // Check if any radio is already selected
                const hasSelection = Array.from(radios).some(radio => radio.checked);

                if (!hasSelection) {
                    // Get the question context for this fieldset
                    const questionContext = FormFiller.getRadioGroupContext(radios, modal);
                    const lowerContext = questionContext.toLowerCase();

                    let targetOption = null;

                    // Check if question is about sponsorship or visa
                    if ((lowerContext.includes('sponsorship') || lowerContext.includes('visa')) &&
                        !lowerContext.includes('have') && !lowerContext.includes('possess')) {
                        // Answer "No" for sponsorship/visa questions
                        radios.forEach(radio => {
                            const label = DOMUtils.getElementLabel(radio);
                            if (label.toLowerCase().includes('no')) {
                                targetOption = radio;
                            }
                        });
                    } else {
                        // Answer "Yes" for all other questions
                        radios.forEach(radio => {
                            const label = DOMUtils.getElementLabel(radio);
                            if (label.toLowerCase().includes('yes')) {
                                targetOption = radio;
                            }
                        });
                    }

                    // If target option not found, fall back to first option
                    if (!targetOption) {
                        targetOption = radios[0];
                    }

                    targetOption.checked = true;
                    targetOption.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }
        });
    }

    // Helper function to fill element with a specific value
    static fillWithValue(element, value) {
        element.value = value;
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Helper function to fill element with fallback value
    static fillWithFallback(element, fallbackValue) {
        FormFiller.fillWithValue(element, fallbackValue);
    }

    // Handle resume upload pages
    static async handleResumeUpload(modal) {
        try {
            console.log("in handle resume upload");

            // First, double-check this is actually a resume upload page
            const hasFileInput = modal.querySelector('input[type="file"]');
            if (!hasFileInput) {
                console.log("⚠️ No file input found - treating as regular form page");
                // Fall through to regular form filling instead of throwing error
                await FormFiller.fillRegularForms(modal);
                return;
            }
            const resumeModule = await import(chrome.runtime.getURL("resume_upload.js"));

            // Run the automated resume upload sequence
            await resumeModule.runApplicationSequence();

            console.log("✅ Resume upload sequence completed");

            // Note: Next button clicking will be handled by the main flow
            // No need to call findAndClickNextButton here as the main loop handles it
        } catch (error) {
            console.error("❌ Error during resume upload:", error);

            // Fallback: treat as regular form and fill normally
            console.log("🔄 Falling back to regular form filling");
            try {
                await FormFiller.fillRegularForms(modal);
            } catch (fillError) {
                console.error("❌ Regular form filling also failed:", fillError);
            }
            // Note: Next button clicking will be handled by the main flow
        }
    }

    // Separate function for regular form filling (extracted from autoFillForms)
    static async fillRegularForms(modal) {
        console.log("🔄 Filling regular forms...");

        // Find all form elements
        const formElements = modal.querySelectorAll('input, select, textarea');

        if (formElements.length === 0) {
            console.log("No form elements found to fill");
            document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: 'No Forms to Fill - Page Ready' }
            }));
            return;
        }

        // Analyze what types of fields we're filling to provide better feedback
        const fieldTypes = new Set();
        const fieldLabels = [];

        formElements.forEach(element => {
            const label = DOMUtils.getElementLabel(element).toLowerCase();
            fieldLabels.push(label);

            if (label.includes('email') || label.includes('contact')) fieldTypes.add('Contact Information');
            else if (label.includes('phone') || label.includes('mobile')) fieldTypes.add('Contact Information');
            else if (label.includes('name') || label.includes('first') || label.includes('last')) fieldTypes.add('Personal Information');
            else if (label.includes('experience') || label.includes('years')) fieldTypes.add('Work Experience');
            else if (label.includes('education') || label.includes('degree') || label.includes('university')) fieldTypes.add('Education');
            else if (label.includes('address') || label.includes('location')) fieldTypes.add('Contact Information');
            else fieldTypes.add('Application Fields');
        });

        // Report what we're about to fill
        if (fieldTypes.size > 0) {
            const fieldsToFill = Array.from(fieldTypes).join(', ');
            console.log(`🎯 Filling fields: ${fieldsToFill}`);
            document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: `Filling ${fieldsToFill}` }
            }));
        }

        // Actually fill the forms
        for (const element of formElements) {
            await FormFiller.fillElement(element, modal);
        }

        // Handle fieldsets (radio button groups)
        FormFiller.handleFieldsets(modal);

        // Report completion
        console.log(`✅ Filled ${formElements.length} form elements`);
        document.dispatchEvent(new CustomEvent('jobgen-current-section', {
            detail: { section: `Completed Filling Forms (${formElements.length} fields)` }
        }));
    }

    // Helper function to get user email (you might need to adjust this)
    static async getUserEmail() {
        // Try to get email from background script (if available)
        try {
            return new Promise((resolve) => {
                chrome.runtime.sendMessage({ action: "getUserEmail" }, (response) => {
                    resolve(response?.email);
                });
            });
        } catch {
            return "sam@email.com";
        }
    }

    // Helper function to get job description from the page
    static getJobDescription() {
        // Try to extract job description from LinkedIn job page
        const descriptionSelectors = [
            '.jobs-description-content__text',
            '.jobs-description',
            '.job-view-layout .jobs-description',
            '[data-automation="jobDescription"]' // for other platforms
        ];

        for (const selector of descriptionSelectors) {
            const element = document.querySelector(selector);
            if (element && element.textContent.trim()) {
                return element.textContent.trim();
            }
        }

        // Fallback description
        return "Software development position requiring technical skills and experience.";
    }

    // Helper function to get context/question text for radio button groups
    static getRadioGroupContext(radioElements) {
        // Try multiple methods to find the question text
        const contexts = [];

        // Method 1: Check fieldset legend
        if (radioElements.length > 0) {
            const fieldset = radioElements[0].closest('fieldset');
            if (fieldset) {
                const legend = fieldset.querySelector('legend');
                if (legend && legend.textContent.trim()) {
                    contexts.push(legend.textContent.trim());
                }
            }
        }

        // Method 2: Check for common question containers near the radio group
        for (const radio of radioElements) {
            // Look for parent containers that might contain the question
            const container = radio.closest('.form-group, .question-container, .field-container, [class*="question"], [class*="field"]');
            if (container) {
                // Find text elements that aren't the radio labels themselves
                const textElements = container.querySelectorAll('label:not([for]), .question-text, .field-label, h3, h4, h5');
                textElements.forEach(el => {
                    const text = el.textContent.trim();
                    if (text && text.length > 10 && !text.toLowerCase().includes('yes') && !text.toLowerCase().includes('no')) {
                        contexts.push(text);
                    }
                });
            }

            // Method 3: Check previous siblings for question text
            let sibling = radio.parentElement?.previousElementSibling;
            let siblingChecks = 0;
            while (sibling && siblingChecks < 3) {
                const text = sibling.textContent?.trim();
                if (text && text.length > 10) {
                    contexts.push(text);
                    break;
                }
                sibling = sibling.previousElementSibling;
                siblingChecks++;
            }

            // Only check the first radio element to avoid duplicates
            break;
        }

        // Method 4: If no context found, check the radio labels themselves for clues
        if (contexts.length === 0 && radioElements.length > 0) {
            const firstRadioLabel = DOMUtils.getElementLabel(radioElements[0]);
            if (firstRadioLabel && firstRadioLabel !== 'no-label-found') {
                contexts.push(firstRadioLabel);
            }
        }

        // Return the longest/most descriptive context found
        const bestContext = contexts
            .filter(ctx => ctx && ctx.length > 0)
            .sort((a, b) => b.length - a.length)[0] || '';

        // console.log(`Radio group context found: "${bestContext}"`);
        return bestContext;
    }

    // Helper function to determine if a field label looks like a question
    static isQuestionField(label) {
        const questionIndicators = [
            '?',
            'why',
            'how',
            'what',
            'when',
            'where',
            'describe',
            'explain',
            'tell us',
            'tell me',
            'share',
            'experience',
            'motivation',
            'interest',
            'reason',
            'background',
            'skills',
            'qualification',
            'example',
            'cover letter',
            'additional information',
            'comments',
            'notes',
            'details'
        ];

        const lowerLabel = label.toLowerCase();
        return questionIndicators.some(indicator => lowerLabel.includes(indicator)) ||
            lowerLabel.length > 20; // Assume longer labels are likely questions
    }
}