export class AuthManager {
  static TOKEN_API_URL = "https://www.jobgen.ai/version-test/api/1.1/wf/jobgen_generate_token";

  /* ---------- jwt helpers ---------- */
  static decodeJwtPayload(jwt) {
    try {
      const [, raw] = jwt.split(".");
      const json = atob(raw.replace(/-/g, "+").replace(/_/g, "/")
                           .padEnd(Math.ceil(raw.length / 4) * 4, "="));
      return JSON.parse(json);
    } catch (e) {
      console.warn("⚠️ Cannot decode JWT:", e);
      return {};
    }
  }

  static clearToken() {
    return chrome.storage.local.remove("jwt_token");
  }

  // user email retrieval
  static async getUserEmail() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "getUserEmail" }, (response) => {
        const email = response?.email
        resolve(email);
      });
    });
  }

  // Public method for other modules to get the current user's email
  static async getCurrentUserEmail() {
    return await AuthManager.getUserEmail();
  }

  /* ---------- token lifecycle ---------- */
  static async generateAndStoreToken() {
    const email = await AuthManager.getUserEmail();
    const res = await fetch(AuthManager.TOKEN_API_URL, {
      method : "POST",
      headers: { "Content-Type": "application/json" },
      body   : JSON.stringify({ email: email })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const { response } = await res.json();
    const jwt = response?.jwt_token;
    if (!jwt) throw new Error("No jwt_token in response");

    await chrome.storage.local.set({ jwt_token: jwt });
    return jwt;
  }

  static async getStoredToken() {
    const { jwt_token } = await chrome.storage.local.get("jwt_token");
    return jwt_token || null;
  }

  /**
   * Return a valid JWT, refreshing when:
   *   – none stored
   *   – it belongs to another email
   *   – it expires in < leewaySeconds
   */
  static async refreshTokenIfNeeded(leewaySeconds = 300) {
    let token = await AuthManager.getStoredToken();
    if (!token) {
      console.log("🔑 No stored JWT – creating one …");
      return await AuthManager.generateAndStoreToken();
    }

    const { exp, email: tokenEmail, sub } = AuthManager.decodeJwtPayload(token);
    const owner = tokenEmail || sub;
    const currentEmail = await AuthManager.getUserEmail();
    if (owner !== currentEmail) {
      console.log(`👤 JWT belongs to ${owner} → regenerating for ${currentEmail}`);
      await AuthManager.clearToken();
      return await AuthManager.generateAndStoreToken();
    }

    const now = Date.now() / 1000 | 0;
    if (!exp || exp - now < leewaySeconds) {
      console.log(`🔁 JWT expires in ${exp ? exp - now : "unknown"} s – refreshing`);
      await AuthManager.clearToken();
      return await AuthManager.generateAndStoreToken();
    }

    console.log(`✅ JWT valid – ${Math.round((exp - now) / 60)} min left`);
    return token;
  }

  /* ---------- public entry ---------- */
  static async initialize() {
    return await AuthManager.refreshTokenIfNeeded();
  }

  // optional legacy alias
  static ensureToken() {
    return AuthManager.refreshTokenIfNeeded();
  }
}
