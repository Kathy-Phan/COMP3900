// Main entry point for the LinkedIn Easy Apply automation
import { ModalHandler } from './linkedin-easy-apply/modal-handler.js';
import { GoogleFiller } from './normal-apply/googleFiller.js';
import { AmazonFiller } from './normal-apply/amazonFiller.js';


// Main function to start the Easy Apply flow
export async function startEasyApplyFlow(autoSubmit) {
    clickEasyApplyButton();
    const modal = await ModalHandler.checkForModal();
    if (modal) {
        console.log('Modal opened');
        const modalHandler = new ModalHandler(modal);
        await modalHandler.startAutomation(autoSubmit);
    }
}

// Function to find and click the Easy Apply button
const clickEasyApplyButton = () => {
    const EAregex = /easy\s*apply/i;
    const isHidden = el => el.offsetParent === null;

    for (const btn of document.querySelectorAll('button')) {
        if (isHidden(btn)) continue;

        const label = (btn.innerText || "").trim() || btn.getAttribute('aria-label') || "";
        if (EAregex.test(label)) {
            console.log("Clicking Easy Apply button");
            btn.click();
            return;
        }
    }
}

export async function regApplyTest() {
    if (window.location.href.includes('google.com')) {
        GoogleFiller.startFilling();
    } else if (window.location.href.includes('amazon.jobs')) {
        AmazonFiller.startFilling();
    }
}

