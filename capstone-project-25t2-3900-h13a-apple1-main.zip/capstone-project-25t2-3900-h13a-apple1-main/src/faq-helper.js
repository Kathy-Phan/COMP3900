// FAQ data helper for form filling
export class FAQHelper {

    // Get FAQ data from storage
    static async getFAQData() {
        try {
            const result = await chrome.storage.local.get(['faq_response']);
            return result.faq_response || null;
        } catch (error) {
            console.error("Error getting FAQ data:", error);
            return null;
        }
    }

    // Check if label matches phone number field
    static isPhoneField(label) {
        const phoneKeywords = ['mobile', 'number', 'phone'];
        const lowerLabel = label.toLowerCase();
        return phoneKeywords.some(keyword => lowerLabel.includes(keyword)) &&
            !lowerLabel.includes('country') && !lowerLabel.includes('code');
    }

    // Check if label matches country code field
    static isCountryCodeField(label) {
        const countryKeywords = ['country', 'code'];
        const lowerLabel = label.toLowerCase();
        return countryKeywords.some(keyword => lowerLabel.includes(keyword));
    }

    // Check if label matches salary field
    static isAddressField(label) {
        const salaryKeywords = ['street', 'address'];
        const lowerLabel = label.toLowerCase();
        return salaryKeywords.some(keyword => lowerLabel.includes(keyword));
    }
    static isCityField(label) {
        const salaryKeywords = ['city'];
        const lowerLabel = label.toLowerCase();
        return salaryKeywords.some(keyword => lowerLabel.includes(keyword));
    }
    static isPostcodeField(label) {
        const salaryKeywords = ['postcode', 'zip', 'postal'];
        const lowerLabel = label.toLowerCase();
        return salaryKeywords.some(keyword => lowerLabel.includes(keyword));
    }
    static isStateField(label) {
        const salaryKeywords = ['state', 'province'];
        const lowerLabel = label.toLowerCase();
        return salaryKeywords.some(keyword => lowerLabel.includes(keyword));
    }
    // Check if label matches salary field
    static isSalaryField(label) {
        const salaryKeywords = ['salary', 'compensation'];
        const lowerLabel = label.toLowerCase();
        return salaryKeywords.some(keyword => lowerLabel.includes(keyword));
    }

    // Check if label matches experience field
    static isExperienceField(label) {
        const experienceKeywords = ['experience', 'years'];
        const lowerLabel = label.toLowerCase();
        return experienceKeywords.some(keyword => lowerLabel.includes(keyword));
    }

    // Check if radio question matches work authorization
    static isWorkAuthQuestion(questionText) {
        const workAuthKeywords = ['legally', 'authorized', 'work', 'eligible', 'authorise'];
        const lowerText = questionText.toLowerCase();
        return workAuthKeywords.some(keyword => lowerText.includes(keyword));
    }

    // Check if radio question matches residency
    static isResidencyQuestion(questionText) {
        const residencyKeywords = ['residing', 'live in', 'currently in', 'resident'];
        const lowerText = questionText.toLowerCase();
        return residencyKeywords.some(keyword => lowerText.includes(keyword));
    }

    // Check if radio question matches sponsorship
    static isFirstNameQuestion(questionText) {
        const firstNameKeywords = ['first name'];
        const lowerText = questionText.toLowerCase();
        return firstNameKeywords.some(keyword => lowerText.includes(keyword));
    }
    // Check if radio question matches sponsorship
    static isLastNameQuestion(questionText) {
        const lastNameKeywords = ['last name'];
        const lowerText = questionText.toLowerCase();
        return lastNameKeywords.some(keyword => lowerText.includes(keyword));
    }
    static isMiddleNameQuestion(questionText) {
        const lastNameKeywords = ['middle name'];
        const lowerText = questionText.toLowerCase();
        return lastNameKeywords.some(keyword => lowerText.includes(keyword));
    }
    // Check if radio question matches sponsorship
    static isSponsorshipQuestion(questionText) {
        const sponsorshipKeywords = ['sponsorship', 'visa', 'future'];
        const lowerText = questionText.toLowerCase();
        return sponsorshipKeywords.some(keyword => lowerText.includes(keyword));
    }

    static isDateQuestion(questionText) {
        const sponsorshipKeywords = ['date', 'start'];
        const lowerText = questionText.toLowerCase();
        return sponsorshipKeywords.some(keyword => lowerText.includes(keyword));
    }

    // Get FAQ value for text fields
    static async getFAQValueForTextField(label) {
        const faqData = await FAQHelper.getFAQData();
        if (!faqData) return null;

        if (FAQHelper.isPhoneField(label)) {
            return faqData.phone || null;
        }

        if (FAQHelper.isSalaryField(label)) {
            return faqData.salary_expectation || null;
        }

        if (FAQHelper.isExperienceField(label)) {
            return faqData.skill1_years_of_experience || null;
        }
        if (FAQHelper.isFirstNameQuestion(label)) {
            return faqData.first_name || 'not working';
        }
        if (FAQHelper.isLastNameQuestion(label)) {
            return faqData.last_name || 'not working last';
        }
        if (FAQHelper.isMiddleNameQuestion(label)) {
            return '';
        }
        if (FAQHelper.isExperienceField(label)) {
            return faqData.skill1_years_of_experience || null;
        }
        if (FAQHelper.isAddressField(label)) {
            return faqData.user_address || null;
        }
        if (FAQHelper.isCityField(label)) {
            return faqData.user_city || null;
        }
        if (FAQHelper.isPostcodeField(label)) {
            return faqData.user_post_code || null;
        }
        if (FAQHelper.isStateField(label)) {
            return faqData.user_state || null;
        }
        if (FAQHelper.isDateQuestion(label)) {
            return '2025-02-05';
        }

        return null;
    }

    // Get FAQ boolean value for radio buttons
    static async getFAQBooleanForRadio(questionText) {
        const faqData = await FAQHelper.getFAQData();
        if (!faqData) return null;

        if (FAQHelper.isWorkAuthQuestion(questionText)) {
            return faqData.legally_authorise_to_work;
        }

        if (FAQHelper.isResidencyQuestion(questionText)) {
            return faqData.residing_in_country;
        }

        if (FAQHelper.isSponsorshipQuestion(questionText)) {
            // Note: future_sponsorship_required = true means they need sponsorship
            // So we return the opposite for "Do you need sponsorship?" type questions
            return !faqData.future_sponsorship_required;
        }

        return null;
    }

    // Find matching option in dropdown for country code
    static findCountryCodeOption(selectElement, faqData) {
        if (!faqData || !faqData.phone_country_code) return null;

        const options = selectElement.options;

        for (let option of options) {
            const optionText = option.textContent.toLowerCase();
            const optionValue = option.value.toLowerCase();

            // Try to match by country name or code
            if (optionText.includes('australia') ||
                optionText.includes('+61') ||
                optionValue.includes('australia') ||
                optionValue.includes('61')) {
                return option;
            }
        }

        return null;
    }
    static findStateOption(selectElement, faqData) {
        if (!faqData || !faqData.user_state) return null;

        const options = selectElement.options;

        for (let option of options) {
            const optionText = option.textContent.toLowerCase();
            const optionValue = option.value.toLowerCase();

            // Try to match by country name or code
            if (optionText.includes('new') ||
                optionText.includes('south') ||
                optionValue.includes('wales')) {
                return option;
            }
        }

        return null;
    }
}