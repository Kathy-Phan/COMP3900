// Progress Tab and Job Application API Module
export class ProgressTab {
    
    /**
     * Load and display applied jobs in the progress tab
     */
    static async loadAppliedJobs() {
        try {
            const { ProgressManager } = await import(chrome.runtime.getURL('progress-manager.js'));
            const appliedJobs = await ProgressManager.getAppliedJobs();
            const stats = await ProgressManager.getJobStats();

            // Update statistics
            document.getElementById('totalJobs').textContent = stats.total;
            document.getElementById('appliedJobs').textContent = stats.applied;
            document.getElementById('reviewedJobs').textContent = stats.reviewed;

            const appliedJobsList = document.getElementById('appliedJobsList');
            const noJobsMessage = document.getElementById('noJobsMessage');

            if (appliedJobs.length === 0) {
                appliedJobsList.innerHTML = '';
                noJobsMessage.style.display = 'block';
            } else {
                noJobsMessage.style.display = 'none';
                appliedJobsList.innerHTML = appliedJobs.map((job) => `
                    <div class="progress-job-item">
                        <div class="progress-job-header">
                            <img src="${job.companyLogo || chrome.runtime.getURL('icon48.png')}" 
                                 alt="Company Logo" 
                                 class="progress-job-logo" />
                            <div class="progress-job-info">
                                <h5 class="progress-job-title">${job.jobTitle}</h5>
                                <p class="progress-company-name">${job.companyName}</p>
                            </div>
                            <span class="progress-status-badge progress-status-${job.status}">
                                ${job.status === 'applied' ? 'Applied' : 'Reviewed'}
                            </span>
                        </div>
                        <div class="progress-job-details">
                            <p><strong>Location:</strong> ${job.location || 'Not specified'}</p>
                            <p><strong>Applied:</strong> ${new Date(job.appliedDate).toLocaleDateString()}</p>
                            <p><strong>Job ID:</strong> ${job.jobId || 'Pending'}</p>
                            <p><strong>Excitement:</strong> ${'★'.repeat(job.excitement || 3)}${'☆'.repeat(5 - (job.excitement || 3))}</p>
                        </div>
                        ${job.jobUrl ? `
                            <a href="${job.jobUrl}" target="_blank" class="progress-job-link">
                                View Job Posting ↗
                            </a>
                        ` : ''}
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Error loading applied jobs:', error);
        }
    }

    /**
     * Call the job_apply API to initiate a job application
     * @param {Object} jobData - Job information object
     * @returns {string|null} - Job ID if successful, null if failed
     */
    static async callJobApplyAPI(jobData) {
        try {
            const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
            const token = await AuthManager.getStoredToken();

            if (!token) {
                throw new Error('No authentication token available');
            }

            const requestBody = {
                job_url: jobData.jobUrl,
                description: jobData.description || "Applied via JobGen.AI Chrome Extension",
                cover_letter: "no",
                company: jobData.companyName || "Unknown Company",
                job_title: jobData.jobTitle || "Unknown Title",
                job_url_id: ProgressTab.extractJobUrlId(jobData.jobUrl),
                job_portal: ProgressTab.getJobPortal(jobData.jobUrl),
            };

            console.log('🚀 Calling job_apply API with data:', requestBody);

            const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(requestBody)
            });

            console.log('📡 job_apply API response status:', response.status);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ job_apply API error response:', errorText);
            throw new Error(`HTTP error! status: ${response.status}, response: ${errorText}`);
        }

        const responseData = await response.json();
        console.log('✅ job_apply API response data:', responseData);

        if (responseData.status === "success" && responseData.response.job_id) {
            console.log('🎯 Retrieved job_id:', responseData.response.job_id);
            return responseData.response.job_id;
        } else {
            console.error('❌ Invalid response format:', responseData);
            throw new Error('No job_id received from API');
        }
    } catch (error) {
        console.error('Error calling job_apply API:', error);
        return null;
    }
}

/**
 * Call the job_apply_outcome API to report application status
 * @param {string} jobId - The job ID from the initial application
 * @param {string} outcome - "success" or "failure"
 * @returns {Object|null} - API response data or null if failed
 */
static async callJobApplyOutcomeAPI(jobId, outcome) {
        try {
            const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
            const token = await AuthManager.getStoredToken();

            if (!token) {
                throw new Error('No authentication token available');
            }

            const email = await AuthManager.getCurrentUserEmail();
            const requestBody = {
                email: email,
                application_status: outcome === "success" ? "Applied" : "Failed",
                job_id: jobId,
                error_code: outcome === "success" ? "" : "Application_Error",
                platform: "Chrome Extension",
                jwt_token: token
            };

            console.log('🚀 Calling job_apply_outcome API with data:', requestBody);

            const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_outcome", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(requestBody)
            });

            console.log('📡 job_apply_outcome API response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ job_apply_outcome API error response:', errorText);
                throw new Error(`HTTP error! status: ${response.status}, response: ${errorText}`);
            }

            const responseData = await response.json();
            console.log('✅ job_apply_outcome API response data:', responseData);
            return responseData;
        } catch (error) {
            console.error('Error calling job_apply_outcome API:', error);
            return null;
        }
    }

    /**
     * Add a job to the applied jobs tracking
     * @param {Object} jobData - Job information object
     * @param {boolean} isApply - Whether this is an actual apply operation (true) or review (false)
     * @returns {string|null} - Job ID if successful, null if failed
     */
    static async addAppliedJob(jobData, isApply = true) {
        try {
            let jobId = null;

        // Only call the job_apply API if this is an actual apply operation
        if (isApply) {
            jobId = await ProgressTab.callJobApplyAPI(jobData);
        }            jobData.jobId = jobId;
            jobData.excitement = window.selectedStarRating || 3;

        // If progress tab is currently active, refresh the display
        const progressContent = document.getElementById('progressContent');
        if (progressContent && progressContent.style.display === 'block') {
            // Trigger a custom event to refresh the progress display
            const refreshEvent = new CustomEvent('jobgen-refresh-progress');
            document.dispatchEvent(refreshEvent);
        }

        return jobId;
    } catch (error) {
        console.error('Error adding applied job:', error);
        return null;
    }
}

/**
 * Extract job URL ID from different job portal URLs
 * @param {string} url - The job posting URL
 * @returns {string} - Extracted job ID or 'unknown'
 */
static extractJobUrlId(url) {
        try {
            if (url.includes('linkedin.com/jobs/view/')) {
                const match = url.match(/\/jobs\/view\/(\d+)/);
                return match ? match[1] : 'unknown';
            } else if (url.includes('seek.com/job/')) {
                const match = url.match(/\/job\/(\w+)/);
                return match ? match[1] : 'unknown';
            } else {
                // Extract last part of URL path as fallback
                const urlParts = url.split('/');
                return urlParts[urlParts.length - 1] || 'unknown';
            }
        } catch (error) {
            console.warn('Error extracting job_url_id:', error);
            return 'unknown';
        }
    }

    /**
     * Determine job portal from URL
     * @param {string} url - The job posting URL
     * @returns {string} - Portal name
     */
    static getJobPortal(url) {
        if (url.includes('linkedin.com')) return 'LinkedIn';
        if (url.includes('seek.com')) return 'Seek';
        if (url.includes('indeed.com')) return 'Indeed';
        if (url.includes('glassdoor.com')) return 'Glassdoor';
        return 'Other';
    }

    /**
     * Create a test job for demonstration purposes
     * @returns {Promise<void>}
     */
    static async addTestJob() {
        const testJob = {
            jobTitle: "Software Engineer Test",
            companyName: "Test Company",
            companyLogo: chrome.runtime.getURL('icon48.png'),
            location: "Remote",
            jobUrl: window.location.href,
            description: "Test job application"
        };
        await ProgressTab.addAppliedJob(testJob, true);
        console.log('Test job added to progress');
    }

    /**
     * Demo function to show the process view in action
     * @returns {Promise<void>}
     */
    static async demoProcessView() {
        const demoJob = {
            jobTitle: "Demo Software Engineer",
            companyName: "Demo Company",
            companyLogo: chrome.runtime.getURL('icon48.png'),
            location: "Remote"
        };

        // Show process view for apply mode
        ProgressTab.showProcessView('apply', demoJob);

        // Simulate realistic timing based on actual process
        await new Promise(resolve => setTimeout(resolve, 500));
        ProgressTab.updateProcessProgress(1, 'Opening application form...');
        
        await new Promise(resolve => setTimeout(resolve, 1200));
        ProgressTab.updateProcessProgress(2, 'Application modal opened, scanning form...');
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        ProgressTab.updateProcessProgress(3, 'Filling form step 1...');
        
        await new Promise(resolve => setTimeout(resolve, 1500));
        ProgressTab.updateProcessProgress(3, 'Moving to next form section...');
        
        await new Promise(resolve => setTimeout(resolve, 1800));
        ProgressTab.updateProcessProgress(3, 'Filling form step 2...');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        ProgressTab.updateProcessProgress(4, 'Submitting application...');
        
        await new Promise(resolve => setTimeout(resolve, 800));
        ProgressTab.completeProcess(true, 'Demo application submitted successfully!');
    }

    /**
     * Show the process view with progress tracking
     * @param {string} processType - 'review' or 'apply'
     * @param {Object} jobData - Job information
     */
    static showProcessView(processType, jobData) {
        // Switch to progress tab if not already active
        const progressTab = document.getElementById('progressTab');
        if (progressTab && !progressTab.classList.contains('active')) {
            progressTab.click();
        }

        // Hide main view and show process view
        const mainView = document.getElementById('progressMainView');
        const processView = document.getElementById('progressProcessView');
        
        if (mainView) mainView.style.display = 'none';
        if (processView) processView.style.display = 'block';

        // Update process title and subtitle
        const processTitle = document.getElementById('processTitle');
        const processSubtitle = document.getElementById('processSubtitle');
        
        if (processType === 'review') {
            if (processTitle) processTitle.textContent = 'Reviewing Application Form...';
            if (processSubtitle) processSubtitle.textContent = `Analyzing ${jobData.jobTitle} at ${jobData.companyName}`;
            
            // Update step text for review mode
            const step4Text = document.getElementById('step4Text');
            const step5Text = document.getElementById('step5Text');
            if (step4Text) step4Text.textContent = 'Review completed - ready for manual submission';
            if (step5Text) step5Text.textContent = 'Review complete!';
        } else {
            if (processTitle) processTitle.textContent = 'Processing Application...';
            if (processSubtitle) processSubtitle.textContent = `Applying to ${jobData.jobTitle} at ${jobData.companyName}`;
            
            // Update step text for apply mode
            const step4Text = document.getElementById('step4Text');
            const step5Text = document.getElementById('step5Text');
            if (step4Text) step4Text.textContent = 'Submitting application...';
            if (step5Text) step5Text.textContent = 'Application submitted!';
        }

        // Store process type for later reference
        ProgressTab._currentProcessType = processType;

        // Reset progress bar and steps
        ProgressTab.resetProcessProgress();

        // Start listening for process events
        ProgressTab._setupEventListeners();
    }

    /**
     * Update process progress
     * @param {number} step - Current step (1-5)
     * @param {string} statusText - Status description
     */
    static updateProcessProgress(step, statusText) {
        // Update progress bar
        const progressBar = document.getElementById('processProgressBar');
        if (progressBar) {
            const progressPercentage = (step / 5) * 100;
            progressBar.style.width = `${progressPercentage}%`;
        }

        // Update status
        const processStatus = document.getElementById('processStatus');
        if (processStatus) {
            processStatus.textContent = statusText;
        }

        // Update step indicators
        const steps = document.querySelectorAll('.process-step');
        steps.forEach((stepElement, index) => {
            const stepNumber = index + 1;
            const indicator = stepElement.querySelector('.step-indicator');
            
            if (stepNumber <= step) {
                // Completed or current step
                stepElement.style.opacity = '1';
                if (indicator) {
                    indicator.style.backgroundColor = '#28a745';
                    indicator.textContent = stepNumber === step ? '⋯' : '✓';
                }
            } else {
                // Future step
                stepElement.style.opacity = '0.5';
                if (indicator) {
                    indicator.style.backgroundColor = '#ddd';
                    indicator.textContent = '';
                }
            }
        });
    }

    /**
     * Reset process progress to initial state
     */
    static resetProcessProgress() {
        const progressBar = document.getElementById('processProgressBar');
        if (progressBar) {
            progressBar.style.width = '0%';
        }

        const processStatus = document.getElementById('processStatus');
        if (processStatus) {
            processStatus.textContent = 'Starting process...';
        }

        // Reset all step indicators
        const steps = document.querySelectorAll('.process-step');
        steps.forEach((stepElement) => {
            stepElement.style.opacity = '0.5';
            const indicator = stepElement.querySelector('.step-indicator');
            if (indicator) {
                indicator.style.backgroundColor = '#ddd';
                indicator.textContent = '';
            }
        });
    }

    /**
     * Hide the process view and return to main progress view
     */
    static hideProcessView() {
        const mainView = document.getElementById('progressMainView');
        const processView = document.getElementById('progressProcessView');
        
        if (mainView) mainView.style.display = 'block';
        if (processView) processView.style.display = 'none';

        // Clean up event listeners
        ProgressTab._cleanupEventListeners();

        // Reset process type
        ProgressTab._currentProcessType = null;

        // Refresh the applied jobs list
        ProgressTab.loadAppliedJobs();
    }

    /**
     * Complete the process and return to main view
     * @param {boolean} success - Whether the process completed successfully
     * @param {string} message - Completion message
     */
    static completeProcess(success, message = null) {
        // Show completion status
        if (success) {
            const completionMessage = ProgressTab._currentProcessType === 'review' 
                ? (message || 'Review completed successfully!') 
                : (message || 'Application submitted successfully!');
            ProgressTab.updateProcessProgress(5, completionMessage);
        } else {
            const processStatus = document.getElementById('processStatus');
            if (processStatus) {
                processStatus.textContent = message || 'Process failed. Please try again.';
                processStatus.style.color = '#dc3545';
            }
        }

        // Wait 2 seconds then return to main view
        setTimeout(() => {
            ProgressTab.hideProcessView();
            ProgressTab._cleanupEventListeners();
        }, 2000);
    }

    /**
     * Setup event listeners for real-time progress tracking
     */
    static _setupEventListeners() {
        // Remove existing listeners to prevent duplicates
        ProgressTab._cleanupEventListeners();

        // Listen for custom events
        document.addEventListener('jobgen-process-step', ProgressTab._handleProcessStep);
        document.addEventListener('jobgen-modal-opened', ProgressTab._handleModalOpened);
        document.addEventListener('jobgen-form-filled', ProgressTab._handleFormFilled);
        document.addEventListener('jobgen-next-clicked', ProgressTab._handleNextClicked);
        document.addEventListener('jobgen-process-complete', ProgressTab._handleProcessComplete);
        
        // New section-based progress events
        document.addEventListener('jobgen-current-section', ProgressTab._handleCurrentSection);
        document.addEventListener('jobgen-form-complete', ProgressTab._handleFormComplete);
        document.addEventListener('jobgen-submit-clicked', ProgressTab._handleSubmitClicked);
    }

    /**
     * Cleanup event listeners
     */
    static _cleanupEventListeners() {
        document.removeEventListener('jobgen-process-step', ProgressTab._handleProcessStep);
        document.removeEventListener('jobgen-modal-opened', ProgressTab._handleModalOpened);
        document.removeEventListener('jobgen-form-filled', ProgressTab._handleFormFilled);
        document.removeEventListener('jobgen-next-clicked', ProgressTab._handleNextClicked);
        document.removeEventListener('jobgen-process-complete', ProgressTab._handleProcessComplete);
        
        // Remove section-based event listeners
        document.removeEventListener('jobgen-current-section', ProgressTab._handleCurrentSection);
        document.removeEventListener('jobgen-form-complete', ProgressTab._handleFormComplete);
        document.removeEventListener('jobgen-submit-clicked', ProgressTab._handleSubmitClicked);
    }

    /**
     * Handle console messages to track progress
     */
    static _handleConsoleMessage(message) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('=== starting auto-form filling ===')) {
            ProgressTab.updateProcessProgress(2, 'Starting form analysis...');
        } else if (lowerMessage.includes('clicking easy apply button')) {
            ProgressTab.updateProcessProgress(1, 'Opening application form...');
        } else if (lowerMessage.includes('modal found') || lowerMessage.includes('modal opened')) {
            ProgressTab.updateProcessProgress(2, 'Application form opened, analyzing fields...');
        } else if (lowerMessage.includes('processing form step')) {
            const stepMatch = message.match(/step (\d+)/i);
            if (stepMatch) {
                ProgressTab.updateProcessProgress(3, `Filling form step ${stepMatch[1]}...`);
            } else {
                ProgressTab.updateProcessProgress(3, 'Filling out application forms...');
            }
        } else if (lowerMessage.includes('resume upload')) {
            ProgressTab.updateProcessProgress(3, 'Uploading resume...');
        } else if (lowerMessage.includes('moving to next step')) {
            ProgressTab.updateProcessProgress(3, 'Moving to next section...');
        } else if (lowerMessage.includes('no more') && lowerMessage.includes('next')) {
            if (ProgressTab._currentProcessType === 'review') {
                ProgressTab.updateProcessProgress(4, 'Review complete - ready for manual submission');
            } else {
                ProgressTab.updateProcessProgress(4, 'Submitting application...');
            }
        } else if (lowerMessage.includes('=== end auto-form filling ===')) {
            if (ProgressTab._currentProcessType === 'review') {
                ProgressTab.completeProcess(true, 'Review completed - you can now manually submit');
            } else {
                ProgressTab.updateProcessProgress(4, 'Finalizing submission...');
            }
        }
    }

    /**
     * Handle custom process step events
     */
    static _handleProcessStep(event) {
        const { step, message } = event.detail;
        ProgressTab.updateProcessProgress(step, message);
    }

    static _handleModalOpened() {
        ProgressTab.updateProcessProgress(2, 'Application modal opened, scanning form...');
    }

    static _handleFormFilled() {
        ProgressTab.updateProcessProgress(3, 'Form fields filled, proceeding...');
    }

    static _handleNextClicked() {
        ProgressTab.updateProcessProgress(3, 'Moving to next form section...');
    }

    static _handleProcessComplete(event) {
        const { success, message } = event.detail;
        ProgressTab.completeProcess(success, message);
    }

    /**
     * Handle specific step progress events from dom-utils
     */
    static _handleStepProgress(event) {
        const { step, message } = event.detail;
        ProgressTab.updateProcessProgress(step, message);
    }

    /**
     * Handle current section events - this is the main progress indicator
     */
    static _handleCurrentSection(event) {
        const { section } = event.detail;
        // Show the current section as the main progress message
        ProgressTab.updateSingleProgress(section);
    }

    /**
     * Handle form completion events
     */
    static _handleFormComplete() {
        if (ProgressTab._currentProcessType === 'review') {
            // For review mode, just show that forms are filled but don't complete the process
            // The user still needs to manually click submit
            ProgressTab.updateSingleProgress('Forms Filled - Ready for Manual Review and Submission');
        } else {
            // For apply mode, this means the process is complete
            ProgressTab.completeProcess(true, 'Application submitted successfully');
        }
    }

    /**
     * Handle submit button click events
     */
    static _handleSubmitClicked(event) {
        const { success } = event.detail;
        if (success) {
            ProgressTab.updateSingleProgress('Application Submitted Successfully!');
            setTimeout(() => {
                ProgressTab.completeProcess(true, 'Application submitted successfully!');
            }, 1500);
        } else {
            ProgressTab.completeProcess(false, 'Failed to submit application');
        }
    }

    /**
     * Update progress with a single meaningful message (simplified UI)
     */
    static updateSingleProgress(message) {
        const processView = document.getElementById('progressProcessView');
        if (!processView || processView.style.display === 'none') {
            return; // Process view not active
        }

        // Update the current step text
        const currentStepElement = processView.querySelector('.current-step-text');
        if (currentStepElement) {
            currentStepElement.textContent = message;
        }

        // Update the progress indicator to show activity
        const progressIndicator = processView.querySelector('.progress-indicator');
        if (progressIndicator) {
            progressIndicator.className = 'progress-indicator active';
        }

        console.log(`📋 Progress: ${message}`);
    }

}