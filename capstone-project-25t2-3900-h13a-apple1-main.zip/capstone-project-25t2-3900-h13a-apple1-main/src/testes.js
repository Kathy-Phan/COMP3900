// Test file for debugging FAQ Helper and other functions
export class Testes {
    static async runTests() {
        console.log("🧪 === STARTING TESTS ===");
        try {
            // Import FAQ Helper
            const { FAQHelper } = await import(chrome.runtime.getURL('faq-helper.js'));

            console.log("✅ FAQ Helper imported successfully");

            // // Test field detection functions
            const testLabels = [
                "Mobile Number",
                "Phone Number",
                "Cell Phone",
                "Country Code",
                "Salary Expectation",
                "Compensation",
                "Years of Experience",
                "Experience Level",
                "Tell us why you want this job"
            ];

            // // Test FAQ value retrieval
            console.log("\n📝 Testing FAQ Value Retrieval:");
            for (const label of testLabels) {
                const value = await FAQHelper.getFAQValueForTextField(label);
                if (value) {
                    console.log(`✅ FAQ Value for "${label}": ${value}`);
                } else {
                    console.log(`❌ No FAQ value for "${label}"`);
                }
            }
        } catch (error) {
            console.error("❌ Error during testing:", error);
        }
    }
}