// Main handler of the extension on the seek site

import { SEEK_SELECTORS, SEEK_CONFIG } from './seek-config.js';

export function getSeekCompanyLogo() {
  const logoElement = document.querySelector(SEEK_SELECTORS.logo);
  if (logoElement && logoElement.complete && logoElement.src) {
    return logoElement.src;
  }
  return null;
}

export function clickSeekQuickApplyButton() {
  console.log(' Looking for Seek Quick Apply button...');
  
  for (const selector of SEEK_SELECTORS.applyButtons) {
    const button = document.querySelector(selector);
    if (button && button.offsetParent !== null) {
      console.log(' Found Seek Apply button:', selector);
      setTimeout(() => {
        button.click();
        console.log(' Seek Apply button clicked');
      }, SEEK_CONFIG.applyButtonDelay);
      return true;
    }
  }

  console.error(' No Seek Apply button found!');
  alert('Could not find the Apply button on this page. Please make sure you are on a job listing page.');
  return false;
}

export function scrapeSeekJobData() {
  const jobTitle = 
    document.querySelector(SEEK_SELECTORS.jobTitle[0])?.innerText?.trim() ||
    document.querySelector(SEEK_SELECTORS.jobTitle[1])?.innerText?.trim() ||
    document.querySelector(SEEK_SELECTORS.jobTitle[2])?.innerText?.trim() ||
    'Job Title Not Found';

  const companyName = 
    document.querySelector(SEEK_SELECTORS.companyName)?.innerText?.trim() ||
    'Company Not Found';

  const jobLocation = 
    document.querySelector(SEEK_SELECTORS.location[0])?.innerText?.trim() ||
    document.querySelector(SEEK_SELECTORS.location[1])?.innerText?.trim() ||
    'Location Not Found';

  return { jobTitle, companyName, jobLocation };
}

// Function to scrape only job description
function scrapeJobDescription() {
  console.log(' Scraping job description...');
  
  const descriptionSelectors = [
    '[data-automation="jobAdDetails"]',
    '[data-automation*="jobAd"]',
    '[data-automation*="job"]',
    'article',
    '.jobDescriptionText',
    '.jobs-description__container',
    '.job-description',
    '[class*="description"]'
  ];
  
  for (const selector of descriptionSelectors) {
    const element = document.querySelector(selector);
    if (element && element.innerText && element.innerText.trim().length > 100) {
      const description = element.innerText.trim().slice(0, 2000);
      console.log(` Found job description using selector: ${selector} (length: ${description.length})`);
      return description;
    }
  }
  
  console.log(' Using fallback body text for description');
  return document.body.innerText.trim().slice(0, 2000);
}

async function loadTemplate() {
  try {
    const response = await fetch(chrome.runtime.getURL('job-container-template.html'));
    const template = await response.text();
    return template;
  } catch (error) {
    console.error('Error loading template:', error);
    return '';
  }
}

async function loadStyles() {
  // Check if styles are already loaded
  if (document.getElementById('job-container-styles')) {
    return;
  }

  try {
    // Load CSS content and replace font URLs
    const response = await fetch(chrome.runtime.getURL('job-container.css'));
    const cssContent = await response.text();

    const processedCSS = cssContent
      .replace('{{FONT_INTER_URL}}', chrome.runtime.getURL('fonts/Inter-Light.woff2'))
      .replace('{{FONT_INTER_BOLD_URL}}', chrome.runtime.getURL('fonts/Inter-Bold.woff2'));

    const style = document.createElement('style');
    style.id = 'job-container-styles';
    style.textContent = processedCSS;
    document.head.appendChild(style);
  } catch (error) {
    console.error('Error loading styles:', error);
  }
}

// Call API
  async function callJobApplyAPI(currentJobData, requestCoverLetter = false) {
  try {
    const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
    const token = await AuthManager.getStoredToken();

    if (!token) {
      throw new Error('No authentication token available');
    }

    const extractJobUrlId = (url) => {
      try {
        const seekPattern = /[?&]jobId=(\d+)(?:&|$)/i;
        const linkedInPattern = /\/jobs\/view\/(\d+)\//;
        const genericPattern = /\/job\/(\d+)/;
        
        let match = url.match(seekPattern);
        if (match) return match[1];
        
        match = url.match(linkedInPattern);
        if (match) return match[1];
        
        match = url.match(genericPattern);
        if (match) return match[1];
        
        return 'unknown';
      } catch (error) {
        console.warn('Error extracting job_url_id:', error);
        return 'unknown';
      }
    };

    const jobDescription = scrapeJobDescription();

    console.log(' Using current job data for API call:', currentJobData);
    console.log(' Scraped job description length:', jobDescription.length);

    const requestBody = {
      job_url: window.location.href,
      description: jobDescription,
      cover_letter: requestCoverLetter ? "yes" : "no",
      company: currentJobData.companyName,
      job_title: currentJobData.jobTitle,
      job_url_id: extractJobUrlId(window.location.href),
      job_portal: "Seek"
    };

    console.log(' Calling job_apply API with current data:', requestBody);

    const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(' job_apply API error response:', errorText);
      throw new Error(`HTTP error! status: ${response.status}, response: ${errorText}`);
    }

    const responseData = await response.json();
    console.log(' job_apply API response data:', responseData);
    
    if (responseData.response && responseData.response.resume) {
      console.log(' Retrieved job_id:', responseData.response.job_id);
      return {
        jobId: responseData.response.job_id,
        resumeUrl: responseData.response.resume,
        coverLetterUrl: responseData.response.cover_letter
      };
    } else {
      console.error(' Invalid response format:', responseData);
      throw new Error('No resume URL received from API');
    }
  } catch (error) {
    console.error('Error calling job_apply API:', error);
    throw error;
  }
}

async function callJobApplyOutcomeAPI(jobId, outcome) {
  try {
    const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
    const token = await AuthManager.getStoredToken();

    if (!token) {
      throw new Error('No authentication token available');
    }

    const email = await AuthManager.getCurrentUserEmail();
    const requestBody = {
      email: email,
      application_status: outcome === "success" ? "Applied" : "Failed",
      job_id: jobId,
      error_code: outcome === "success" ? "" : "Application_Error",
      platform: "Chrome Extension - Seek",
      jwt_token: token
    };

    console.log(' Calling job_apply_outcome API with data:', requestBody);

    const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_outcome", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(' job_apply_outcome API error response:', errorText);
      throw new Error(`HTTP error! status: ${response.status}, response: ${errorText}`);
    }

    const responseData = await response.json();
    console.log(' job_apply_outcome API response data:', responseData);
    return responseData;
  } catch (error) {
    console.error('Error calling job_apply_outcome API:', error);
    return null;
  }
}

// Main function to display the extension window
export async function displayJobInfoSeek() {
  console.log('🎯 displayJobInfoSeek() called');
  
  try {
    await loadStyles();

    const button = document.createElement('button');
    button.id = 'jobButton';
    Object.assign(button.style, {
      position: 'fixed',
      top: '50%',
      right: '10px',
      transform: 'translateY(-50%)',
      backgroundColor: '#FFFFFF',
      border: 'none',
      padding: '0',
      borderRadius: '10px',
      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
      zIndex: '99999',
      width: '60px',
      height: '60px'
    });
    button.innerHTML = `<img src="chrome-extension://${chrome.runtime.id}/icon48.png" alt="Logo" style="width: 100%; height: 100%;" />`;


    let isDragging = false;
    button.addEventListener('mousedown', (e) => {
      isDragging = true;
      const offsetY = e.clientY - button.getBoundingClientRect().top;

      const onMouseMove = (e) => {
        if (isDragging) {
          button.style.top = `${e.clientY - offsetY}px`;
          button.style.right = '0';
        }
      };

      const onMouseUp = () => {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });

    // Main button click handler 
    button.addEventListener('click', async () => {
      console.log(' Seek button clicked');
      button.style.display = 'none';

      const { jobTitle, companyName, jobLocation } = scrapeSeekJobData();
      const companyLogoUrl = getSeekCompanyLogo() || chrome.runtime.getURL('icon48.png');

      console.log(' Scraped data:', { jobTitle, companyName, jobLocation });

      const container = document.createElement('div');
      container.id = 'jobContainer';
      Object.assign(container.style, {
        position: 'fixed',
        top: '0',
        right: '0',
        height: '100%',
        backgroundColor: '#FFFFFF',
        padding: '0',
        borderRadius: '0px',
        boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
        zIndex: '99999',
        maxWidth: '400px',
        width: '400px',
        overflowY: 'auto'
      });

      const template = await loadTemplate();
      container.innerHTML = template
        .replace(/{{EXTENSION_ID}}/g, chrome.runtime.id)
        .replace(/{{COMPANY_LOGO_URL}}/g, companyLogoUrl)
        .replace(/{{JOB_TITLE}}/g, jobTitle)
        .replace(/{{COMPANY_NAME}}/g, companyName)
        .replace(/{{JOB_LOCATION}}/g, jobLocation);

      document.body.appendChild(container);

      initializeStarRating();
      wireSeekButtons(jobTitle, companyName, companyLogoUrl, jobLocation);
      setupUIHandlers(button, container);
      setupTabs();
      setupSeekURLObserver(jobTitle, companyName, jobLocation);

      window.addAppliedJob = addAppliedJob;
      window.callJobApplyOutcomeAPI = callJobApplyOutcomeAPI;
      window.loadAppliedJobs = loadAppliedJobs;
    });

    document.body.appendChild(button);
    console.log(' Seek floating button added to page');

  } catch (error) {
    console.error(' Error in displayJobInfoSeek():', error);
  }

  // Helper functions //
  function initializeStarRating() {
    const stars = document.querySelectorAll('#starRating .star');
    let rating = 3;
    window.selectedStarRating = rating;

    stars.forEach(s => {
      if (parseInt(s.getAttribute('data-value')) <= rating) {
        s.textContent = '★';
      } else {
        s.textContent = '☆';
      }
    });

    stars.forEach(star => {
      star.addEventListener('click', () => {
        rating = parseInt(star.getAttribute('data-value'));
        stars.forEach(s => {
          if (parseInt(s.getAttribute('data-value')) <= rating) {
            s.textContent = '★';
          } else {
            s.textContent = '☆';
          }
        });
        window.selectedStarRating = rating;
        console.log('User selected rating:', rating);
      });
    });
  }

  // eslint-disable-next-line no-unused-vars
  function wireSeekButtons(_currentJobTitle, _currentCompanyName, _currentCompanyLogo, _currentJobLocation) {
    async function wireButton(buttonElement, buttonName, isAutoSubmit) {
      if (buttonElement && !buttonElement.dataset.wiredScanning) {
        buttonElement.dataset.wiredScanning = '1';
        buttonElement.addEventListener('click', async e => {
          e.preventDefault();
          
          try {
            console.log(` ${buttonName} button clicked`);
            const currentJobData = getCurrentJobDataFromUI();
            
            const jobData = {
              jobTitle: currentJobData.jobTitle,
              companyName: currentJobData.companyName,
              companyLogo: currentJobData.companyLogo,
              location: currentJobData.location,
              jobUrl: window.location.href,
              description: `Applied via JobGen.AI - ${buttonName}`
            };

            
            console.log(' Starting API call in background...');
            let apiPromise = null;
            
            try {
              apiPromise = callJobApplyAPI(currentJobData, true);
            } catch (apiError) {
              console.error(' Failed to start API call:', apiError);
            }

            
            if (clickSeekQuickApplyButton()) {
              console.log(` ${buttonName} process initiated - navigating to application page`);
            } else {
              console.error(` Could not find Seek Apply button for ${buttonName}`);
              return; 
            }

            
            if (apiPromise) {
              
              apiPromise.then(async (apiResponse) => {
                try {
                  const jobId = apiResponse.jobId;
                  const resumeUrl = apiResponse.resumeUrl;
                  const coverLetterUrl = apiResponse.coverLetterUrl;
                  
                  console.log(' Background API call completed:', { jobId, resumeUrl, coverLetterUrl });
                  
                  // Store the URLs in chrome storage for the apply stage to use
                  await chrome.storage.local.set({
                    'jobgen_api_response': {
                      jobId: jobId,
                      resumeUrl: resumeUrl,
                      coverLetterUrl: coverLetterUrl,
                      timestamp: Date.now(),
                      jobUrl: window.location.href
                    }
                  });
                  
                  console.log(' Stored API response in chrome storage');
                  
                  const flowResult = await chrome.storage.local.get(['seekApplicationFlow']);
                  if (flowResult.seekApplicationFlow) {
                    flowResult.seekApplicationFlow.jobId = jobId;
                    await chrome.storage.local.set({ seekApplicationFlow: flowResult.seekApplicationFlow });
                  }
                  
                } catch (error) {
                  console.error(' Background API processing failed:', error);
                }
              }).catch(error => {
                console.error(' Background API call failed:', error);
              });
            }

            if (isAutoSubmit) {
              addAppliedJob(jobData, true).catch(error => {
                console.error(` Background tracking error for ${buttonName}:`, error);
              });
            }
            
            // Set up the application flow state (without jobId initially)
            await chrome.storage.local.set({
              'seekApplicationFlow': {
                inProgress: true,
                isFullApply: isAutoSubmit,
                jobData: jobData,
                jobId: null, // Will be updated when API completes
                startTime: Date.now()
              }
            });
            
          } catch (error) {
            console.error(` Error during ${buttonName} process:`, error);
          }
        });
        console.log(` Wired ${buttonName} button for Seek`);
      }
    }

    const reviewBtn = document.getElementById('reviewButton');
    const applyBtn = document.getElementById('applyButton');

    wireButton(reviewBtn, 'Review Process', false);
    wireButton(applyBtn, 'Apply Process', true);
  }

  // Function to get current job data from UI elements
  function getCurrentJobDataFromUI() {
    const jobTitleElement = document.getElementById('jobTitle');
    const companyNameElement = document.getElementById('companyName');
    const locationElement = document.getElementById('location');
    const logoElement = document.getElementById('companyLogo');
    
    return {
      jobTitle: jobTitleElement?.textContent?.trim() || 'Unknown Job Title',
      companyName: companyNameElement?.textContent?.trim() || 'Unknown Company',
      location: locationElement?.textContent?.trim() || 'Unknown Location',
      companyLogo: logoElement?.src || chrome.runtime.getURL('icon48.png')
    };
  }

  function setupUIHandlers(button, container) {
    // Close button
    document.getElementById('closeButton').addEventListener('click', () => {
      document.body.removeChild(container);
      button.style.display = 'block';
    });

    // Button hover effects
    const reviewApplyButtons = document.querySelectorAll('#reviewButton, #applyButton');
    reviewApplyButtons.forEach(btn => {
      btn.addEventListener('mouseover', () => {
        btn.style.backgroundColor = '#30A1FB';
      });
      btn.addEventListener('mouseout', () => {
        btn.style.backgroundColor = '#3f6afd';
      });
    });
  }

  function setupTabs() {
    const tabs = document.querySelectorAll('#highLevelTab, #linkedinTab, #progressTab');
    const warningMessage = document.getElementById('warningMessage');

    function showContent(tabId) {
      document.getElementById('highLevelContent').style.display = tabId === 'highLevelTab' ? 'block' : 'none';
      document.getElementById('progressContent').style.display = tabId === 'progressTab' ? 'block' : 'none';
      warningMessage.style.display = 'none';
      warningMessage.innerText = "";
    }

    function showWarning(message) {
      warningMessage.innerText = message;
      warningMessage.style.display = 'block';
      document.getElementById('highLevelContent').style.display = 'none';
      document.getElementById('progressContent').style.display = 'none';
    }

    tabs.forEach(tab => {
      tab.addEventListener('mouseover', () => {
        tab.style.backgroundColor = tab.classList.contains('active') ? '#3f6afd' : '#e0e0e0';
      });

      tab.addEventListener('mouseout', () => {
        tab.style.backgroundColor = tab.classList.contains('active') ? '#3f6afd' : '#f4f4f4';
      });

      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        tabs.forEach(t => {
          t.style.backgroundColor = t.classList.contains('active') ? '#3f6afd' : '#f4f4f4';
          t.style.color = t.classList.contains('active') ? 'white' : 'black';
        });

        if (tab.id === 'progressTab') {
          showContent(tab.id);
          loadAppliedJobs();
        } else if (tab.id === 'linkedinTab') {
          showWarning("This feature is optimized for LinkedIn profiles. Limited functionality on Seek.");
        } else {
          showContent(tab.id);
        }
      });
    });

    document.getElementById('highLevelTab').click();
  }

  // eslint-disable-next-line no-unused-vars  
  function setupSeekURLObserver(_initialJobTitle, _initialCompanyName, _initialJobLocation) {
    let currentUrl = window.location.href;
    let isUpdating = false;

    const urlCheckInterval = setInterval(() => {
      const newUrl = window.location.href;
      
      if (newUrl !== currentUrl && !isUpdating) {
        console.log(' URL changed on Seek - clearing stored API response');
        currentUrl = newUrl;
        
        chrome.storage.local.remove(['jobgen_api_response']);
        
        const container = document.getElementById('jobContainer');
        if (!container) return;
        
        isUpdating = true;
        
        setTimeout(() => {
          updateJobDisplay();
          isUpdating = false;
        }, 200);
      }
    }, 100); 

    const handlePopState = () => {
      if (!isUpdating) {
        console.log('🎯 Browser navigation detected - clearing stored API response');
        
        chrome.storage.local.remove(['jobgen_api_response']);
        
        const container = document.getElementById('jobContainer');
        if (!container) return;
        
        isUpdating = true;
        setTimeout(() => {
          updateJobDisplay();
          isUpdating = false;
        }, 200);
      }
    };

    window.addEventListener('popstate', handlePopState);

    function updateJobDisplay() {
      try {
        let retries = 0;
        const maxRetries = 5;
        
        const attemptUpdate = () => {
          const { jobTitle: newJobTitle, companyName: newCompanyName, jobLocation: newJobLocation } = scrapeSeekJobData();
          
          if ((newJobTitle === 'Job Title Not Found' || newCompanyName === 'Company Not Found') && retries < maxRetries) {
            retries++;
            console.log(` Retrying job data scrape (${retries}/${maxRetries})`);
            setTimeout(attemptUpdate, 100);
            return;
          }
          
          const newCompanyLogo = getSeekCompanyLogo() || chrome.runtime.getURL('icon48.png');

          console.log(' Updating with new data:', { newJobTitle, newCompanyName, newJobLocation });

          const jobTitleElement = document.getElementById('jobTitle');
          const companyNameElement = document.getElementById('companyName');
          const locationElement = document.getElementById('location');

          if (jobTitleElement) jobTitleElement.textContent = newJobTitle;
          if (companyNameElement) companyNameElement.textContent = newCompanyName;
          if (locationElement) locationElement.textContent = newJobLocation || 'Location not specified';
          const companyLogoElement = document.getElementById('companyLogo');
          if (companyLogoElement) {
            const logoUrl = getSeekCompanyLogo();
            if (logoUrl) {
              companyLogoElement.src = logoUrl;
              companyLogoElement.style.display = 'block';
            } else {
              setTimeout(() => {
                const delayedLogoUrl = getSeekCompanyLogo();
                if (delayedLogoUrl) {
                  companyLogoElement.src = delayedLogoUrl;
                  companyLogoElement.style.display = 'block';
                }
              }, 200);
            }
          }

          window.selectedStarRating = 3;
          const stars = document.querySelectorAll('#starRating .star');
          stars.forEach(s => {
            if (parseInt(s.getAttribute('data-value')) <= 3) {
              s.textContent = '★';
            } else {
              s.textContent = '☆';
            }
          });

          wireSeekButtons(newJobTitle, newCompanyName, newCompanyLogo, newJobLocation);

          console.log(' Updated Seek job display');
        };
        
        attemptUpdate();
        
      } catch (error) {
        console.error(' Error updating job display:', error);
      }
    }

    return () => {
      clearInterval(urlCheckInterval);
      window.removeEventListener('popstate', handlePopState);
    };
  }

  // Progress management functions
  async function loadAppliedJobs() {
    try {
      const { ProgressManager } = await import(chrome.runtime.getURL('progress-manager.js'));
      const appliedJobs = await ProgressManager.getAppliedJobs();
      const stats = await ProgressManager.getJobStats();
      
      document.getElementById('totalJobs').textContent = stats.total;
      document.getElementById('appliedJobs').textContent = stats.applied;
      document.getElementById('reviewedJobs').textContent = stats.reviewed;
      
      const appliedJobsList = document.getElementById('appliedJobsList');
      const noJobsMessage = document.getElementById('noJobsMessage');
      
      if (appliedJobs.length === 0) {
        appliedJobsList.innerHTML = '';
        noJobsMessage.style.display = 'block';
      } else {
        noJobsMessage.style.display = 'none';
        appliedJobsList.innerHTML = appliedJobs.map((job) => `
          <div class="progress-job-item">
            <div class="progress-job-header">
              <img src="${job.companyLogo || chrome.runtime.getURL('icon48.png')}" 
                   alt="Company Logo" 
                   class="progress-job-logo" />
              <div class="progress-job-info">
                <h5 class="progress-job-title">${job.jobTitle}</h5>
                <p class="progress-company-name">${job.companyName}</p>
              </div>
              <span class="progress-status-badge progress-status-${job.status}">
                ${job.status === 'applied' ? 'Applied' : 'Reviewed'}
              </span>
            </div>
            <div class="progress-job-details">
              <p><strong>Location:</strong> ${job.location || 'Not specified'}</p>
              <p><strong>Applied:</strong> ${new Date(job.appliedDate).toLocaleDateString()}</p>
              <p><strong>Job ID:</strong> ${job.jobId || 'Pending'}</p>
              <p><strong>Excitement:</strong> ${'★'.repeat(job.excitement || 3)}${'☆'.repeat(5 - (job.excitement || 3))}</p>
            </div>
            ${job.jobUrl ? `
              <a href="${job.jobUrl}" target="_blank" class="progress-job-link">
                View Job Posting ↗
              </a>
            ` : ''}
          </div>
        `).join('');
      }
    } catch (error) {
      console.error('Error loading applied jobs:', error);
    }
  }

  async function addAppliedJob(jobData, isApply = true) {
    try {
      jobData.excitement = window.selectedStarRating || 3;

      const { ProgressManager } = await import(chrome.runtime.getURL('progress-manager.js'));
      const appliedJob = await ProgressManager.addAppliedJob(jobData, isApply);
      console.log('Added job:', appliedJob);

      const progressContent = document.getElementById('progressContent');
      if (progressContent && progressContent.style.display === 'block') {
        loadAppliedJobs();
      }

      return jobData.jobId;
    } catch (error) {
      console.error('Error adding applied job:', error);
      return null;
    }
  }
}

// Handle Seek application page
export async function handleSeekApplicationPage() {
  console.log(' Detected Seek application page');
  
  const result = await chrome.storage.local.get(['seekApplicationFlow']);
  const flowState = result.seekApplicationFlow;
  
  const { getSeekApplicationStage } = await import(chrome.runtime.getURL('seek/seek-utils.js'));
  const currentStage = getSeekApplicationStage(window.location.href);
  
  console.log(' Current stage:', currentStage);
  
  if (!flowState || !flowState.inProgress) {
    console.log('ℹ No active Seek automation flow detected');
    return;
  }

  console.log(' Continuing Seek automation flow:', flowState);  
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  console.log(' Successfully navigated to Seek application page');
  console.log(' Job Data:', flowState.jobData);
  console.log(' Apply Type:', flowState.isFullApply ? 'Full Apply' : 'Review Only');
  
  try {
    switch (currentStage) {
  case 'apply': {
    console.log(' Running Apply Stage automation (resume/cover letter)');
    const { automateSeekApplyStage } = await import(chrome.runtime.getURL('seek/seek-apply-stage.js'));
    await automateSeekApplyStage();
    break;
  }

  case 'role-requirements': {
    console.log(' Running Role Requirements automation');
    const { automateSeekRoleRequirements } = await import(chrome.runtime.getURL('seek/seek-role-stage.js'));
    await automateSeekRoleRequirements();
    break;
  }

  case 'profile': {
    console.log(' Running Profile Stage automation');
    const { automateSeekProfileStage } = await import(chrome.runtime.getURL('seek/seek-profile-stage.js'));
    await automateSeekProfileStage();
    break;
  }

  case 'review': {
    console.log(' Reached Review stage - automation complete');

    const { automateSeekReviewStage } = await import(chrome.runtime.getURL('seek/seek-review-stage.js'));
    await automateSeekReviewStage(flowState.isFullApply);

    if (flowState.isFullApply && flowState.jobId) {
      try {
        console.log(' Job application completed successfully - calling outcome API');
        await callJobApplyOutcomeAPI(flowState.jobId, 'success');
      } catch (error) {
        console.error('Error calling outcome API:', error);
      }
    }

    await chrome.storage.local.remove(['seekApplicationFlow']);
    console.log('🎉 Seek automation flow completed!');
    break;
  }

  case 'success':
    console.log(' Automation Complete - Seek application submitted successfully!');
    break;

  case 'unknown-apply-stage':
    console.log(' Unknown Seek application stage - URL contains /apply/ but stage not recognized');
    console.log(' Current URL:', window.location.href);
    break;

  default:
    console.log(' Unrecognized Seek application stage:', currentStage);
    console.log(' Current URL:', window.location.href);
}

    
  } catch (error) {
    console.error(' Seek automation failed:', error);
    
    if (flowState.isFullApply && flowState.jobId) {
      try {
        console.log(' Calling outcome API with failure status');
        await callJobApplyOutcomeAPI(flowState.jobId, 'failure');
      } catch (outcomeError) {
        console.error('Error calling failure outcome API:', outcomeError);
      }
    }
    
    await chrome.storage.local.remove(['seekApplicationFlow']);
  }
}