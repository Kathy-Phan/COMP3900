// Handle the final review stage - submit if it's a full apply, stop if it's just review

export class SeekReviewStageAutomation {
  constructor() {
    this.submitButtonSelector = 'button[data-testid="review-submit-application"]';
  }

  // Main automation function
  async automateReviewStage(isFullApply = false) {
    console.log('🚀 Starting Review Stage automation');
    console.log(`🎯 Mode: ${isFullApply ? 'Full Apply - Will Submit' : 'Review Only - Will Stop'}`);
    
    try {
      await this.waitForPageLoad();
      
      if (isFullApply) {
        await this.submitApplication();
        console.log('✅ Application submitted successfully');
      } else {
        console.log('✅ Review completed - stopping as requested');
      }
      
      console.log('✅ Review stage automation completed successfully');
      return true;
      
    } catch (error) {
      console.error('❌ Review stage automation failed:', error);
      throw error;
    }
  }

  // Submit the application
  async submitApplication() {
    console.log('🔘 Looking for Submit Application button...');
    
    const submitButton = document.querySelector(this.submitButtonSelector);
    
    if (submitButton && submitButton.offsetParent !== null && !submitButton.disabled) {
      console.log('✅ Found Submit Application button');
      
      await this.clickElement(submitButton);      
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      console.log('✅ Submit button clicked successfully');
      return;
    }
    
    throw new Error('Could not find Submit Application button');
  }

  // Utility functions
  async waitForPageLoad() {
    console.log('⏳ Waiting for page to load...');
    
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        setTimeout(resolve, 500);
      } else {
        window.addEventListener('load', () => {
          setTimeout(resolve, 500);
        });
      }
    });
  }

  async clickElement(element) {
    return new Promise((resolve) => {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      setTimeout(() => {
        element.focus();
        
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        
        element.dispatchEvent(clickEvent);
        
        resolve();
      }, 500);
    });
  }
}

// Integration function
export async function automateSeekReviewStage(isFullApply = false) {
  console.log('🎯 Initializing Seek Review Stage automation');
  
  const url = window.location.href.toLowerCase();
  if (!url.includes('review')) {
    console.log('ℹ️ Not on review stage, skipping automation');
    return false;
  }
  
  const automation = new SeekReviewStageAutomation();
  
  try {
    const success = await automation.automateReviewStage(isFullApply);
    return success;
  } catch (error) {
    console.error('❌ Review stage automation failed:', error);
    throw error;
  }
}