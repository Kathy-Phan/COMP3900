// Database of frequently asked Seek questions with FAQ mappings

export class SeekQuestionsDatabase {
  
  // Main database of questions and their mappings
  static getQuestionsDatabase() {
    return {
      
      // ========================================
      // WORK AUTHORIZATION QUESTIONS
      // ========================================
      
      "work_authorization_australia": {
        question_patterns: [
          "which of the following statements best describes your right to work in australia",
          "right to work in australia",
          "work authorization australia",
          "work rights australia",
          "australian work authorization",
          "work eligibility australia"
        ],
        faq_key: "work_authorisation_status",
        field_type: "dropdown",
        mappings: {
          "Citizen": "I'm an Australian citizen",
          "Permanent Resident": "I'm a permanent resident and/or NZ citizen", 
          "Student Visa": "I have a temporary visa with restrictions on work hours (e.g. student visa, retirement visa)",
          "Work Visa": "I have a temporary visa with no restrictions (e.g doctoral student)",
          "Bridging Visa": "I have a temporary visa with no restrictions (e.g doctoral student)",
          "Other": "I require sponsorship to work for a new employer (e.g. 482, 457)"
        },
        fallback_option: "I require sponsorship to work for a new employer (e.g. 482, 457)"
      },

      // ========================================
      // SPONSORSHIP QUESTIONS  
      // ========================================

      "future_sponsorship": {
        question_patterns: [
          "will you require sponsorship",
          "do you require sponsorship", 
          "future sponsorship required",
          "need sponsorship",
          "require visa sponsorship",
          "sponsorship for future employment"
        ],
        faq_key: "future_sponsorship_required",
        field_type: "radio",
        mappings: {
          true: "Yes",
          false: "No"
        },
        fallback_option: "No"
      },

      "current_sponsorship": {
        question_patterns: [
          "do you currently require sponsorship",
          "currently need sponsorship",
          "existing sponsorship requirements"
        ],
        faq_key: "future_sponsorship_required", 
        field_type: "radio",
        mappings: {
          true: "Yes",
          false: "No"
        },
        fallback_option: "No"
      },

      // ========================================
      // LOCATION & RESIDENCY QUESTIONS
      // ========================================

      "residing_in_australia": {
        question_patterns: [
          "are you currently residing in australia",
          "do you live in australia",
          "currently living in australia",
          "resident of australia",
          "based in australia"
        ],
        faq_key: "residing_in_country",
        field_type: "radio", 
        mappings: {
          true: "Yes",
          false: "No"
        },
        fallback_option: "Yes"
      },

      "can_relocate": {
        question_patterns: [
          "are you willing to relocate",
          "can you relocate",
          "open to relocation",
          "willing to move",
          "relocate for this position"
        ],
        faq_key: "can_you_relocate",
        field_type: "radio",
        mappings: {
          "yes": "Yes",
          "no": "No"
        },
        fallback_option: "Yes"
      },

      "when_relocate": {
        question_patterns: [
          "when can you relocate",
          "how soon can you relocate",
          "relocation timeframe",
          "available to relocate"
        ],
        faq_key: "when_you_can_relocate", 
        field_type: "dropdown",
        mappings: {
          "Immediate": "Immediately",
          "1 week": "Within 1 week",
          "2 weeks": "Within 2 weeks", 
          "1 month": "Within 1 month",
          "2 months": "Within 2 months",
          "3 months": "Within 3 months"
        },
        fallback_option: "Immediately"
      },

      // ========================================
      // AVAILABILITY & START DATE QUESTIONS
      // ========================================

      "availability_start": {
        question_patterns: [
          "when are you available to start",
          "when can you start",
          "availability to commence",
          "start date availability",
          "earliest start date"
        ],
        faq_key: "when_available_to_start",
        field_type: "dropdown",
        mappings: {
          "Immediately": "Immediately",
          "1 week": "1 week",
          "2 weeks": "2 weeks",
          "1 month": "1 month"
        },
        fallback_option: "Immediately"
      },

      "notice_period": {
        question_patterns: [
          "what is your current notice period",
          "notice period required",
          "how much notice do you need to give",
          "resignation notice period",
          "how much notice are you required to give to your current employer",
          "how much notice are you required to give your current employer",
          "notice required to give current employer",
          "current employer notice period"
        ],
        faq_key: "current_notice_period",
        field_type: "dropdown",
        mappings: {
          "Immediate": "None, I'm ready to go now",
          "1 week": "1 week",
          "2 week": "2 weeks",
          "4 week": "4 weeks",
          "Other": "6 or more weeks"
        },
        fallback_option: "1 week"
      },

      // ========================================
      // SALARY & COMPENSATION QUESTIONS
      // ========================================

      "salary_expectation": {
        question_patterns: [
          "salary expectation",
          "expected salary",
          "salary requirements",
          "compensation expectation",
          "what salary are you looking for",
          "what's your expected annual base salary",
          "expected annual base salary",
          "annual base salary expectation"
        ],
        faq_key: "salary_expectation",
        field_type: "dropdown",
        mappings: {
          "30000": "$30k",
          "35000": "$35k", 
          "40000": "$40k",
          "45000": "$45k",
          "50000": "$50k",
          "55000": "$55k",
          "60000": "$60k",
          "65000": "$65k",
          "70000": "$70k",
          "75000": "$75k",
          "80000": "$80k",
          "85000": "$85k",
          "90000": "$90k",
          "95000": "$95k",
          "100000": "$100k",
          "105000": "$105k",
          "110000": "$110k",
          "115000": "$115k",
          "120000": "$120k",
          "125000": "$125k",
          "130000": "$130k",
          "135000": "$135k",
          "140000": "$140k",
          "145000": "$145k",
          "150000": "$150k",
          "155000": "$155k",
          "160000": "$160k",
          "165000": "$165k",
          "170000": "$170k",
          "175000": "$175k",
          "180000": "$180k",
          "185000": "$185k",
          "190000": "$190k",
          "195000": "$195k",
          "200000": "$200k",
          "205000": "$205k",
          "210000": "$210k",
          "215000": "$215k",
          "220000": "$220k",
          "225000": "$225k",
          "230000": "$230k",
          "235000": "$235k",
          "240000": "$240k",
          "245000": "$245k",
          "250000": "$250k",
          "255000": "$255k",
          "260000": "$260k",
          "265000": "$265k",
          "270000": "$270k",
          "275000": "$275k",
          "280000": "$280k",
          "285000": "$285k",
          "290000": "$290k",
          "295000": "$295k",
          "300000": "$300k",
          "305000": "$305k",
          "310000": "$310k",
          "315000": "$315k",
          "320000": "$320k",
          "325000": "$325k",
          "330000": "$330k",
          "335000": "$335k",
          "340000": "$340k",
          "345000": "$345k",
          "350000": "$350k+"
        },
        fallback_option: "$100k",
        use_nearest_match: true
      },

      "salary_expectation_text": {
        question_patterns: [
          "salary expectation",
          "expected salary", 
          "salary requirements",
          "compensation expectation",
          "what salary are you looking for"
        ],
        faq_key: "salary_expectation",
        field_type: "text",
        direct_mapping: true,
        fallback_value: "100000"
      },

      "salary_currency": {
        question_patterns: [
          "salary currency",
          "currency preference",
          "what currency"
        ],
        faq_key: "salary_currency_code", 
        field_type: "dropdown",
        mappings: {
          "AUD": "Australian Dollar (AUD)",
          "USD": "US Dollar (USD)",
          "NZD": "New Zealand Dollar (NZD)",
          "GBP": "British Pound (GBP)"
        },
        fallback_option: "Australian Dollar (AUD)"
      },

      // ========================================
      // PERSONAL INFORMATION QUESTIONS
      // ========================================

      "first_name": {
        question_patterns: [
          "first name",
          "given name",
          "forename"
        ],
        faq_key: "first_name",
        field_type: "text",
        direct_mapping: true,
        fallback_value: "John"
      },

      "last_name": {
        question_patterns: [
          "last name", 
          "surname",
          "family name"
        ],
        faq_key: "last_name",
        field_type: "text", 
        direct_mapping: true,
        fallback_value: "Smith"
      },

      "email_address": {
        question_patterns: [
          "email address",
          "email",
          "e-mail"
        ],
        faq_key: "email",
        field_type: "text",
        direct_mapping: true,
        fallback_value: "example@email.com"
      },

      "phone_number": {
        question_patterns: [
          "phone number",
          "mobile number",
          "contact number",
          "telephone"
        ],
        faq_key: "phone", 
        field_type: "text",
        direct_mapping: true,
        fallback_value: "0400000000"
      },

      // ========================================
      // WORKING PREFERENCES QUESTIONS
      // ========================================

      "working_arrangement": {
        question_patterns: [
          "preferred working arrangement",
          "working model preference", 
          "remote work preference",
          "hybrid work",
          "work from home"
        ],
        faq_key: "prefered_working_model",
        field_type: "dropdown",
        mappings: {
          "Hybrid": "Hybrid",
          "Remote": "Remote", 
          "On-site": "On-site",
          "Office": "On-site",
          "Flexible": "Hybrid"
        },
        fallback_option: "Hybrid"
      },

      "employment_type": {
        question_patterns: [
          "employment type",
          "working type preference",
          "full time or part time",
          "employment arrangement"
        ],
        faq_key: "preferred_working_type",
        field_type: "dropdown", 
        mappings: {
          "Full-time": "Full-time",
          "Part-time": "Part-time",
          "Contract": "Contract",
          "Casual": "Casual",
          "Temporary": "Contract"
        },
        fallback_option: "Full-time"
      },

      "willing_to_travel": {
        question_patterns: [
          "are you willing to travel",
          "travel requirements",
          "travel for work",
          "business travel"
        ],
        faq_key: "willing_to_travel",
        field_type: "radio",
        mappings: {
          true: "Yes", 
          false: "No"
        },
        fallback_option: "Yes"
      },

      // ========================================
      // EXPERIENCE & SKILLS QUESTIONS  
      // ========================================

      "years_experience": {
        question_patterns: [
          "years of experience",
          "how many years experience",
          "experience in years",
          "total experience",
          "how many years of",
          "how many years'"
        ],
        faq_key: "skill1_years_of_experience",
        field_type: "dropdown",
        mappings: {
          "0": "No experience",
          "0.5": "Less than 1 year",
          "1": "1 year",
          "2": "2 years",
          "3": "3 years",
          "4": "4 years",
          "5": "5 years",
          "6": "More than 5 years",
          "7": "More than 5 years",
          "8": "More than 5 years",
          "9": "More than 5 years",
          "10": "More than 5 years"
        },
        fallback_option: "More than 5 years",
        use_years_experience_logic: true
      },

      "programming_experience": {
        question_patterns: [
          "programming experience",
          "coding experience", 
          "software development experience",
          "years programming",
          "how many years of programming",
          "how many years of coding",
          "how many years of software development",
          "how many years' programming",
          "how many years' coding",
          "how many years' software development"
        ],
        faq_key: "skill1_years_of_experience",
        field_type: "dropdown",
        mappings: {
          "0": "No experience",
          "0.5": "Less than 1 year",
          "1": "1 year",
          "2": "2 years",
          "3": "3 years",
          "4": "4 years",
          "5": "5 years",
          "6": "More than 5 years",
          "7": "More than 5 years",
          "8": "More than 5 years",
          "9": "More than 5 years",
          "10": "More than 5 years"
        },
        fallback_option: "More than 5 years",
        use_years_experience_logic: true
      },

      // ========================================
      // INDUSTRY & ROLE QUESTIONS
      // ========================================

      "current_job_title": {
        question_patterns: [
          "current job title",
          "current role",
          "current position",
          "what is your current role"
        ],
        faq_key: "job_title",
        field_type: "text",
        direct_mapping: true,
        fallback_value: "Software Engineer"
      },

      "industry_preference": {
        question_patterns: [
          "industry preference",
          "preferred industry",
          "industry experience",
          "which industry"
        ],
        faq_key: "industry", 
        field_type: "dropdown",
        mappings: {
          "Information Technology": "Information Technology",
          "IT": "Information Technology", 
          "Tech": "Information Technology",
          "Software": "Information Technology",
          "Finance": "Finance",
          "Healthcare": "Healthcare",
          "Education": "Education"
        },
        fallback_option: "Information Technology"
      },

      // ========================================
      // CITIZENSHIP & VISA QUESTIONS
      // ========================================

      "citizenship_status": {
        question_patterns: [
          "citizenship status",
          "what is your citizenship",
          "nationality",
          "citizen of which country"
        ],
        faq_key: "citizenship",
        field_type: "dropdown",
        mappings: {
          "Malaysia": "Malaysia",
          "Australia": "Australia", 
          "New Zealand": "New Zealand",
          "United Kingdom": "United Kingdom",
          "United States": "United States"
        },
        fallback_option: "Malaysia"
      },

      "legally_authorized": {
        question_patterns: [
          "are you legally authorized to work",
          "legally entitled to work",
          "legal right to work", 
          "authorized to work"
        ],
        faq_key: "legally_authorise_to_work",
        field_type: "radio",
        mappings: {
          true: "Yes",
          false: "No"
        },
        fallback_option: "Yes"
      }
    };
  }

  // ========================================
  // HELPER METHODS
  // ========================================

  /**
   * Find matching question in database based on field label/text
   */
  static findQuestionMatch(fieldLabel) {
    const database = this.getQuestionsDatabase();
    const normalizedLabel = fieldLabel.toLowerCase().trim();
    
    console.log(`🔍 Searching for question match: "${normalizedLabel}"`);
    
    for (const [questionId, questionData] of Object.entries(database)) {
      for (const pattern of questionData.question_patterns) {
        if (normalizedLabel.includes(pattern.toLowerCase())) {
          console.log(`✅ Found match: ${questionId} (pattern: "${pattern}")`);
          return {
            id: questionId,
            ...questionData
          };
        }
      }
    }
    
    console.log(`❌ No question match found for: "${normalizedLabel}"`);
    return null;
  }

  /**
   * Get the appropriate answer for a question based on FAQ data
   */
  static getAnswerForQuestion(questionMatch, faqData) {
    if (!questionMatch || !faqData) {
      return null;
    }

    const faqValue = faqData[questionMatch.faq_key];
    console.log(`📋 FAQ value for ${questionMatch.faq_key}: ${faqValue}`);
    
    if (faqValue === undefined || faqValue === null) {
      console.log(`⚠️ No FAQ value found, using fallback`);
      return questionMatch.fallback_option || questionMatch.fallback_value || null;
    }

    if (questionMatch.direct_mapping) {
      return String(faqValue);
    }

    if (questionMatch.use_nearest_match && questionMatch.id === 'salary_expectation') {
      return this.findNearestSalaryMatch(faqValue, questionMatch.mappings);
    }

    if (questionMatch.use_years_experience_logic) {
      return this.mapYearsExperience(faqValue, questionMatch.mappings);
    }

    if (questionMatch.use_notice_period_logic) {
      return this.mapNoticePeriod(faqValue, questionMatch.mappings);
    }

    if (questionMatch.mappings) {
      const mappedValue = questionMatch.mappings[faqValue];
      if (mappedValue) {
        console.log(`✅ Mapped ${faqValue} → ${mappedValue}`);
        return mappedValue;
      }
    }

    console.log(`⚠️ No mapping found for value: ${faqValue}, using fallback`);
    return questionMatch.fallback_option || questionMatch.fallback_value || String(faqValue);
  }

  /**
   * Find the nearest salary match for dropdown selection
   */
  static findNearestSalaryMatch(faqSalary, salaryMappings) {
    const targetSalary = parseInt(faqSalary);
    console.log(`💰 Finding nearest salary match for: ${targetSalary}`);
    
    if (isNaN(targetSalary)) {
      console.log(`⚠️ Invalid salary value, using fallback`);
      return "$100k";
    }

    const salaryKeys = Object.keys(salaryMappings).map(key => parseInt(key)).filter(num => !isNaN(num));
    
    let closestSalary = salaryKeys[0];
    let smallestDiff = Math.abs(targetSalary - closestSalary);
    
    for (const salary of salaryKeys) {
      const diff = Math.abs(targetSalary - salary);
      if (diff < smallestDiff) {
        smallestDiff = diff;
        closestSalary = salary;
      }
    }
    
    const result = salaryMappings[closestSalary.toString()];
    console.log(`✅ Nearest salary match: ${targetSalary} → ${closestSalary} → ${result}`);
    return result;
  }

  /**
   * Map years of experience to Seek dropdown options
   */
  static mapYearsExperience(faqYears, experienceMappings) {
    const years = parseFloat(faqYears);
    console.log(`📅 Mapping years of experience: ${years}`);
    
    if (isNaN(years)) {
      console.log(`⚠️ Invalid years value, using fallback`);
      return "More than 5 years";
    }

    let result;
    
    if (years === 0) {
      result = "No experience";
    } else if (years < 1) {
      result = "Less than 1 year";
    } else if (years >= 1 && years <= 5) {
      const yearKey = Math.floor(years).toString();
      result = experienceMappings[yearKey] || `${Math.floor(years)} year${Math.floor(years) > 1 ? 's' : ''}`;
    } else {
      result = "More than 5 years";
    }
    
    console.log(`✅ Years experience mapped: ${years} → ${result}`);
    return result;
  }

  /**
   * Map notice period to Seek dropdown options
   */
  static mapNoticePeriod(faqNoticePeriod, noticeMappings) {
    const noticeStr = String(faqNoticePeriod).toLowerCase().trim();
    console.log(`📋 Mapping notice period: ${noticeStr}`);
    
    if (noticeMappings[faqNoticePeriod]) {
      const result = noticeMappings[faqNoticePeriod];
      console.log(`✅ Direct notice mapping: ${faqNoticePeriod} → ${result}`);
      return result;
    }
    
    let result;
    
    if (noticeStr.includes('immediately') || noticeStr.includes('none') || noticeStr === '0') {
      result = "None, I'm ready to go now";
    }
    else if (noticeStr.includes('week')) {
      const weekMatch = noticeStr.match(/(\d+)\s*week/);
      if (weekMatch) {
        const weeks = parseInt(weekMatch[1]);
        if (weeks === 1) result = "1 week";
        else if (weeks === 2) result = "2 weeks";
        else if (weeks === 3) result = "3 weeks";
        else if (weeks === 4) result = "4 weeks";
        else if (weeks === 5) result = "5 weeks";
        else if (weeks >= 6) result = "6 or more weeks";
        else result = "1 week";
      } else {
        result = "1 week";
      }
    }
    else if (noticeStr.includes('month')) {
      const monthMatch = noticeStr.match(/(\d+)\s*month/);
      if (monthMatch) {
        const months = parseInt(monthMatch[1]);
        if (months === 1) result = "4 weeks";
        else if (months >= 2) result = "6 or more weeks";
        else result = "1 week";
      } else {
        result = "4 weeks";
      }
    }
    else {
      result = "1 week";
    }
    
    console.log(`✅ Notice period mapped: ${noticeStr} → ${result}`);
    return result;
  }

  /**
   * Find dropdown option that matches the answer
   */
  static findDropdownOption(selectElement, targetAnswer) {
    if (!selectElement || !targetAnswer) {
      return null;
    }

    const options = Array.from(selectElement.options);
    const normalizedTarget = targetAnswer.toLowerCase();
    
    console.log(`🎯 Looking for dropdown option: "${targetAnswer}"`);
    
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      if (option.text.toLowerCase() === normalizedTarget) {
        console.log(`✅ Found exact match: "${option.text}"`);
        return { index: i, option: option };
      }
    }
    
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      if (option.text.toLowerCase().includes(normalizedTarget) || 
          normalizedTarget.includes(option.text.toLowerCase())) {
        console.log(`✅ Found partial match: "${option.text}"`);
        return { index: i, option: option };
      }
    }
    
    console.log(`❌ No dropdown option found for: "${targetAnswer}"`);
    return null;
  }

  /**
   * Find radio button that matches the answer
   */
  static findRadioOption(radioElements, targetAnswer) {
    if (!radioElements || !targetAnswer) {
      return null;
    }

    const normalizedTarget = targetAnswer.toLowerCase();
    console.log(`📻 Looking for radio option: "${targetAnswer}"`);
    
    for (const radio of radioElements) {
      const label = this.getRadioLabel(radio).toLowerCase();
      
      if (label === normalizedTarget || 
          label.includes(normalizedTarget) || 
          normalizedTarget.includes(label)) {
        console.log(`✅ Found radio match: "${label}"`);
        return radio;
      }
    }
    
    console.log(`❌ No radio option found for: "${targetAnswer}"`);
    return null;
  }

  /**
   * Get label text for radio button
   */
  static getRadioLabel(radioElement) {
    if (radioElement.id) {
      const label = document.querySelector(`label[for="${radioElement.id}"]`);
      if (label) return label.textContent.trim();
    }
    
    const parentLabel = radioElement.closest('label');
    if (parentLabel) return parentLabel.textContent.trim();
    
    if (radioElement.nextElementSibling) {
      return radioElement.nextElementSibling.textContent.trim();
    }
    
    return '';
  }
}

export default SeekQuestionsDatabase;