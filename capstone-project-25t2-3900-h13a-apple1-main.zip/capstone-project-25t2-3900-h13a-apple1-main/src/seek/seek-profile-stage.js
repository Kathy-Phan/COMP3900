// Simple automation for the profile stage - just click continue

export class SeekProfileStageAutomation {
  constructor() {
    this.continueButtonSelector = 'button[data-testid="continue-button"]';
  }

  // Main automation function
  async automateProfileStage() {
    console.log('🚀 Starting Profile Stage automation');
    
    try {
      await this.waitForPageLoad();      
      await this.clickContinue();
      
      console.log('✅ Profile stage automation completed successfully');
      return true;
      
    } catch (error) {
      console.error('❌ Profile stage automation failed:', error);
      throw error;
    }
  }

  async clickContinue() {
    console.log('🔘 Looking for Continue button...');
    
    const continueButton = document.querySelector(this.continueButtonSelector);
    
    if (continueButton && continueButton.offsetParent !== null && !continueButton.disabled) {
      console.log('✅ Found Continue button');
      
      await this.clickElement(continueButton);      
      await this.waitForNavigation();
      
      console.log('✅ Continue button clicked successfully');
      return;
    }
    
    throw new Error('Could not find Continue button');
  }

  // Utility functions
  async waitForPageLoad() {
    console.log('⏳ Waiting for page to load...');
    
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        setTimeout(resolve, 500);
      } else {
        window.addEventListener('load', () => {
          setTimeout(resolve, 500);
        });
      }
    });
  }

  async clickElement(element) {
    return new Promise((resolve) => {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      setTimeout(() => {
        element.focus();
        
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        
        element.dispatchEvent(clickEvent);
        
        resolve();
      }, 500);
    });
  }

  async waitForNavigation() {
    console.log('🔄 Waiting for navigation to review stage...');
    
    const currentUrl = window.location.href;
    let attempts = 0;
    const maxAttempts = 30;
    
    return new Promise((resolve, reject) => {
      const checkNavigation = () => {
        attempts++;
        
        const newUrl = window.location.href;
        if (newUrl !== currentUrl) {
          console.log(`✅ Navigation detected to: ${newUrl}`);
          
          if (newUrl.toLowerCase().includes('review')) {
            console.log('🎉 Successfully navigated to review stage!');
          }
          
          resolve();
        } else if (attempts >= maxAttempts) {
          reject(new Error('Navigation timeout - page did not change'));
        } else {
          setTimeout(checkNavigation, 1000);
        }
      };
      
      setTimeout(checkNavigation, 1000);
    });
  }
}

// Integration function
export async function automateSeekProfileStage() {
  console.log('🎯 Initializing Seek Profile Stage automation');
  
  const url = window.location.href.toLowerCase();
  if (!url.includes('profile')) {
    console.log('ℹ️ Not on profile stage, skipping automation');
    return false;
  }
  
  const automation = new SeekProfileStageAutomation();
  
  try {
    const success = await automation.automateProfileStage();
    return success;
  } catch (error) {
    console.error('❌ Profile stage automation failed:', error);
    throw error;
  }
}