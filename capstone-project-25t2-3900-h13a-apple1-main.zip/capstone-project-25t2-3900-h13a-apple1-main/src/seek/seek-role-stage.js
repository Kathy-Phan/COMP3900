// Answers employer questions using FAQ local storage integration, Questions Database, and API fallback

import SeekQuestionsDatabase from './seek-questions-database.js';

export class SeekRoleRequirementsAutomation {
  constructor() {
    this.defaultText = 'I cannot answer at the moment';
    this.defaultLongText = 'I cannot answer at the moment';
    this.faqData = null;
    this.questionsDB = SeekQuestionsDatabase;
  }

  // Main automation function
  async automateRoleRequirements() {
    console.log('🚀 Starting Seek Role Requirements automation with FAQ integration and API fallback');
    
    try {
      // Load FAQ data from Chrome local storage
      await this.loadFAQData();      
      await this.waitForPageLoad();   
      await this.fillAllFormElements();      
      await this.clickContinueButton();
      
      console.log('✅ Role requirements automation completed successfully');
      return true;
      
    } catch (error) {
      console.error('❌ Role Requirements automation failed:', error);
      throw error;
    }
  }

  async clickContinueButton() {
    console.log('🔘 Looking for Continue button with data-testid=continue-button...');
    
    const continueButton = document.querySelector('button[data-testid="continue-button"]');
    
    if (continueButton && continueButton.offsetParent !== null && !continueButton.disabled) {
      console.log('✅ Found Continue button');
      
      await this.clickElement(continueButton);
      
      console.log('✅ Continue button clicked successfully');
      return;
    }
    
    throw new Error('Could not find Continue button with data-testid="continue-button"');
  }

  // Load FAQ data from Chrome local storage
  async loadFAQData() {
    try {
      const result = await chrome.storage.local.get(['faq_response']);
      this.faqData = result.faq_response;
      
      if (this.faqData) {
        console.log('✅ FAQ data loaded successfully from local storage');
        console.log('📋 Available FAQ data:', Object.keys(this.faqData));
      } else {
        console.warn('⚠️ No FAQ data found in local storage');
      }
    } catch (error) {
      console.error('❌ Error loading FAQ data:', error);
      this.faqData = null;
    }
  }

  // Find and fill form elements on the page
  async fillAllFormElements() {
    console.log('🎯 Finding all form elements...');
    
    const allInputs = document.querySelectorAll('input, select, textarea');
    console.log(`📋 Found ${allInputs.length} total form elements`);
    
    let filledCount = 0;
    
    for (let i = 0; i < allInputs.length; i++) {
      const element = allInputs[i];
      
      if (element.type === 'hidden' || 
          element.disabled || 
          element.readOnly ||
          element.style.display === 'none' ||
          element.offsetParent === null) {
        continue;
      }
      
      console.log(`📝 Processing element ${i + 1}: ${element.tagName} type="${element.type}"`);
      
      try {
        await this.fillElement(element);
        filledCount++;
        
        await new Promise(resolve => setTimeout(resolve, 300));
        
      } catch (error) {
        console.warn(`⚠️ Failed to fill element ${i + 1}:`, error.message);
      }
    }
    
    console.log(`✅ Successfully processed ${filledCount} form elements`);
  }

  // Fill a single form element based on its type
  async fillElement(element) {
    const tagName = element.tagName.toLowerCase();
    const inputType = element.type ? element.type.toLowerCase() : '';
    
    console.log(`🎯 Filling ${tagName} with type "${inputType}"`);
    
    switch (tagName) {
      case 'input':
        await this.fillInput(element, inputType);
        break;
        
      case 'select':
        await this.fillSelect(element);
        break;
        
      case 'textarea':
        await this.fillTextarea(element);
        break;
        
      default:
        console.log(`❓ Unknown element type: ${tagName}`);
    }
  }

  // Fill input elements with FAQ data, Questions Database, and API fallback
  async fillInput(element, inputType) {
    switch (inputType) {
      case 'text':
      case 'email':
      case 'tel':
      case 'url':
      case 'number':{
        const smartValue = await this.getSmartFAQValueWithAPI(element);
        const textValue = smartValue || this.defaultText;
        
        element.focus();
        element.value = textValue;
        this.triggerEvents(element);
        console.log(`✅ Filled text input with: "${textValue}" ${smartValue ? '(from smart lookup)' : '(default)'}`);
        break;
      }
      case 'radio':
        await this.fillRadioUsingDatabaseAndAPI(element);
        break;
        
      case 'checkbox':
        await this.fillCheckboxUsingAPI(element);
        break;
        
      default:
        console.log(`❓ Unknown input type: ${inputType}`);
    }
  }

  async fillSelect(element) {
    const options = Array.from(element.options);    
    const smartValue = await this.getSmartFAQValueWithAPI(element);
    
    if (smartValue) {
      // Use Questions Database to find matching option
      const matchingOption = this.questionsDB.findDropdownOption(element, smartValue);
      
      if (matchingOption) {
        element.focus();
        element.selectedIndex = matchingOption.index;
        this.triggerEvents(element);
        console.log(`✅ Selected Questions DB option: "${matchingOption.option.text}" (value: "${matchingOption.option.value}")`);
        return;
      }
      
      const apiMatchingOption = this.findBestOptionMatch(options, smartValue);
      
      if (apiMatchingOption) {
        element.focus();
        element.value = apiMatchingOption.value;
        this.triggerEvents(element);
        console.log(`✅ Selected API-matched option: "${apiMatchingOption.text}" (value: "${apiMatchingOption.value}")`);
        return;
      }
    }
    
    // Default selection if things go wrong
    const validOption = options.find(option => 
      option.value && 
      option.value !== '' && 
      option.value !== 'select' &&
      !option.disabled &&
      option.text.trim() !== ''
    );
    
    if (validOption) {
      element.focus();
      element.value = validOption.value;
      this.triggerEvents(element);
      console.log(`✅ Selected first option: "${validOption.text}" (value: "${validOption.value}")`);
    } else {
      console.warn(`⚠️ No valid options found in select dropdown`);
    }
  }

  async fillTextarea(element) {
    const smartValue = await this.getSmartFAQValueWithAPI(element);
    const textValue = smartValue || this.defaultLongText;
    
    element.focus();
    element.value = textValue;
    this.triggerEvents(element);
    console.log(`✅ Filled textarea with: "${textValue}" ${smartValue ? '(from smart lookup)' : '(default)'}`);
  }

  // Attempt to use cached information and try map the question to a field in cache
  async getSmartFAQValueWithAPI(element) {
    const label = this.getElementLabel(element);
    console.log(`🔍 Getting smart FAQ value with API fallback for: "${label}"`);
    
    // Checks question database for questions that are always expected
    const questionMatch = this.questionsDB.findQuestionMatch(label);
    
    if (questionMatch) {
      console.log(`✅ Found question match in database: ${questionMatch.id}`);
      const answer = this.questionsDB.getAnswerForQuestion(questionMatch, this.faqData);
      
      if (answer) {
        console.log(`✅ Questions DB answer: "${answer}"`);
        return answer;
      } else {
        console.log(`⚠️ Question in database but no FAQ data available, will try API fallback`);
      }
    } else {
      console.log(`📋 Question not in database, trying legacy mapping...`);
      
      // Try to map a filed in cache as an answer
      const legacyAnswer = this.getFAQValue(element);
      if (legacyAnswer) {
        console.log(`✅ Legacy FAQ answer: "${legacyAnswer}"`);
        return legacyAnswer;
      }
    }
    
    // If all fails, use GPT via API call
    console.log(`🤖 No cached answer available, trying API fallback...`);
    try {
      const apiAnswer = await this.getAPIAnswer(element, label);
      if (apiAnswer) {
        console.log(`✅ API answer: "${apiAnswer}"`);
        return apiAnswer;
      }
    } catch (error) {
      console.warn(`⚠️ API call failed:`, error.message);
    }
    
    console.log(`❌ No answer found for label: "${label}"`);
    return null;
  }

  async getAPIAnswer(element, label) {
    const tagName = element.tagName.toLowerCase();
    const inputType = element.type ? element.type.toLowerCase() : '';
    
    if (tagName === 'select' || 
        tagName === 'textarea' ||
        (tagName === 'input' && ['radio', 'checkbox'].includes(inputType))) {
      return await this.callJobApplyGPTAccess(element, label);
    } else if (tagName === 'input' && ['text', 'email', 'tel', 'url'].includes(inputType)) {
      return await this.callJobApplyQuestion(label);
    }
    
    return null;
  }

  async callJobApplyQuestion(question) {
    try {
      console.log(`📞 Calling job_apply_question API for: "${question}"`);
      
      const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
      const token = await AuthManager.getStoredToken();

      if (!token) {
        throw new Error('No authentication token available');
      }

      const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_question", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ question: question })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const responseData = await response.json();
      console.log(`✅ job_apply_question response:`, responseData);
      
      return responseData.answer || null;
      
    } catch (error) {
      console.error('❌ job_apply_question API failed:', error);
      return null;
    }
  }

  async callJobApplyGPTAccess(element, question) {
    try {
      console.log(`📞 Calling job_apply_gpt_access API for: "${question}"`);
      console.log(`🔍 API DEBUG: question parameter = "${question}"`);
      console.log(`🔍 API DEBUG: question typeof = ${typeof question}`);
      console.log(`🔍 API DEBUG: question === undefined? ${question === undefined}`);
      console.log(`🔍 API DEBUG: question === null? ${question === null}`);
      
      const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
      const token = await AuthManager.getStoredToken();

      if (!token) {
        throw new Error('No authentication token available');
      }

      // Build context-aware prompt based on element type
      console.log(`🔍 API DEBUG: About to call buildContextualPrompt with question = "${question}"`);
      const contextualPrompt = this.buildContextualPrompt(element, question);
      console.log(`🎯 Contextual prompt: "${contextualPrompt}"`);

      const requestBody = { question: contextualPrompt };
      console.log(`🔍 API DEBUG: Request body =`, requestBody);

      const response = await fetch("https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_gpt_access", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const responseData = await response.json();
      console.log(`✅ job_apply_gpt_access response:`, responseData);
      
      if (responseData.status === "success" && responseData.response && responseData.response.answer) {
        let rawAnswer = responseData.response.answer;
        
        const cleanAnswer = this.parseAPIResponse(rawAnswer);
        console.log(`📋 Cleaned API answer: "${cleanAnswer}"`);
        
        return cleanAnswer;
      }
      
      return null;
      
    } catch (error) {
      console.error('❌ job_apply_gpt_access API failed:', error);
      return null;
    }
  }

  parseAPIResponse(rawAnswer) {
    if (!rawAnswer) return null;
    
    if (typeof rawAnswer === 'string' && !rawAnswer.trim().startsWith('{')) {
      return rawAnswer.trim();
    }
    
    try {
      let parsed;
      if (typeof rawAnswer === 'string') {
        const cleanJson = rawAnswer.trim().replace(/^"|"$/g, '');
        parsed = JSON.parse(cleanJson);
      } else {
        parsed = rawAnswer;
      }
      
      if (parsed && parsed.answer) {
        return parsed.answer.trim();
      }
      
      return JSON.stringify(parsed).replace(/[{},"]/g, '').replace(/answer:/g, '').trim();
      
    } catch (error) {
      console.warn('⚠️ Could not parse API response as JSON, using raw value:', error.message);
      return rawAnswer.toString()
        .replace(/^\s*{\s*"?answer"?\s*:\s*"?/i, '')
        .replace(/"?\s*}\s*$/i, '')
        .trim();
    }
  }

  // Build contextual prompt with available answer options
  buildContextualPrompt(element, question) {
    const tagName = element.tagName.toLowerCase();
    const inputType = element.type ? element.type.toLowerCase() : '';
    
    if (!question || typeof question !== 'string' || question.trim() === '') {
      console.warn('⚠️ Invalid question provided to buildContextualPrompt:', question);
      question = 'Please provide an appropriate answer for this form field';
    }
    
    let prompt = `Give me an answer for this job application question: "${question}"\n\n`;
    
    if (tagName === 'select') {
      const options = Array.from(element.options)
        .filter(option => option.value && option.value !== '' && !option.disabled)
        .map(option => `"${option.text.trim()}"`)
        .join(', ');
      
      if (options) {
        prompt += `Available options: ${options}\n\n`;
        prompt += `Please respond with exactly one of the available options listed above.`;
      }
      
    } else if (tagName === 'textarea') {
      prompt += `Please provide a detailed, professional response appropriate for a job application.`;
      
    } else if (tagName === 'input' && inputType === 'radio') {
      const radioGroup = document.querySelectorAll(`input[name="${element.name}"]`);
      const radioOptions = Array.from(radioGroup)
        .map(radio => {
          const label = this.getRadioButtonLabel(radio);
          return label ? `"${label.trim()}"` : null;
        })
        .filter(label => label && label !== '""' && label !== '"no-label-found"')
        .join(', ');
      
      if (radioOptions) {
        prompt += `Available options: ${radioOptions}\n\n`;
        prompt += `Please respond with exactly one of the available options listed above.`;
      } else {
        prompt += `Please respond with either "Yes" or "No" as appropriate.`;
      }
      
    } else if (tagName === 'input' && inputType === 'checkbox') {
      const checkboxLabel = this.getCheckboxLabel(element);
      const questionContext = this.getCheckboxQuestionContext(element);
      
      // Use the actual question context, otherwise use the provided question
      const actualQuestion = questionContext && questionContext !== 'Checkbox selection' ? questionContext : question;
      
      prompt = `Give me an answer for this job application question: "${actualQuestion}"\n\n`;
      prompt += `Specific checkbox option: "${checkboxLabel}"\n\n`;
      prompt += `Should this checkbox be selected? Respond with "Yes" to select or "No" to leave unchecked.\n`;
      prompt += `IMPORTANT: Never select checkboxes labeled "None of these", "No", "None", "Not applicable", or similar negative options.`;
    }
    
    return prompt;
  }

  getCheckboxLabel(checkboxElement) {
    if (checkboxElement.id) {
      const label = document.querySelector(`label[for="${checkboxElement.id}"]`);
      if (label && label.textContent.trim()) {
        return label.textContent.trim();
      }
    }
    
    const parentLabel = checkboxElement.closest('label');
    if (parentLabel && parentLabel.textContent.trim()) {
      return parentLabel.textContent.trim();
    }
    
    if (checkboxElement.nextSibling && checkboxElement.nextSibling.textContent) {
      return checkboxElement.nextSibling.textContent.trim();
    }
    
    if (checkboxElement.parentElement) {
      const parentText = checkboxElement.parentElement.textContent.trim();
      const checkboxText = checkboxElement.textContent || '';
      return parentText.replace(checkboxText, '').trim();
    }
    
    return 'Unknown checkbox';
  }

  getCheckboxQuestionContext(checkboxElement) {
    // Strategy 1: Look for the main question heading in parent containers
    let currentElement = checkboxElement;
    let searchDepth = 0;
    const maxDepth = 10;
    
    while (currentElement && searchDepth < maxDepth) {
      const questionElements = currentElement.querySelectorAll ? 
        currentElement.querySelectorAll('h1, h2, h3, h4, h5, h6, legend, .question-text, .field-label, strong') : [];
      
      for (const questionEl of questionElements) {
        const text = questionEl.textContent?.trim();
        if (text && text.length > 20 && 
            text.includes('?') && 
            !text.toLowerCase().includes('checkbox') &&
            questionEl !== checkboxElement) {
          console.log(`✅ Found checkbox question context: "${text}"`);
          return text;
        }
      }
      
      currentElement = currentElement.parentElement;
      searchDepth++;
    }
    
    // Strategy 2: Look for strong/bold text in the container
    const container = checkboxElement.closest('.gfpdza0, .form-group, fieldset, [class*="question"]');
    if (container) {
      const strongElements = container.querySelectorAll('strong, b, .question-text');
      for (const strongEl of strongElements) {
        const text = strongEl.textContent?.trim();
        if (text && text.length > 20 && text.includes('?')) {
          console.log(`✅ Found checkbox question in strong element: "${text}"`);
          return text;
        }
      }
      
      // Strategy 3: Look for any text with question mark in container
      const containerText = container.textContent || '';
      const sentences = containerText.split(/[.!?]/);
      for (const sentence of sentences) {
        const trimmed = sentence.trim();
        if (trimmed.length > 20 && trimmed.includes('which') || trimmed.includes('do you') || trimmed.includes('have you')) {
          return trimmed + '?';
        }
      }
    }
    
    // Strategy 4: Look for preceding elements with question text
    let prevElement = checkboxElement.parentElement?.previousElementSibling;
    let attempts = 0;
    
    while (prevElement && attempts < 3) {
      const text = prevElement.textContent?.trim();
      if (text && text.length > 20 && text.includes('?')) {
        console.log(`✅ Found checkbox question in previous element: "${text}"`);
        return text;
      }
      prevElement = prevElement.previousElementSibling;
      attempts++;
    }
    
    console.log('⚠️ Could not find specific checkbox question context, using default');
    return 'Please select applicable options from the following list';
  }

  async fillCheckboxUsingAPI(element) {
    console.log('📋 Processing checkbox with API intelligence...');
    
    const checkboxLabel = this.getCheckboxLabel(element);
    const questionContext = this.getCheckboxQuestionContext(element);
    
    console.log(`📋 Checkbox label: "${checkboxLabel}"`);
    console.log(`📋 Question context: "${questionContext}"`);
    
    if (this.isNegativeCheckboxOption(checkboxLabel)) {
      console.log(`❌ Detected negative checkbox option: "${checkboxLabel}" - skipping`);
      return;
    }
    
    if (element.checked) {
      console.log(`✅ Checkbox already checked: "${checkboxLabel}"`);
      return;
    }
    
    // Call API to determine if checkbox should be selected
    try {
      const apiAnswer = await this.callJobApplyGPTAccess(element, questionContext);
      
      if (apiAnswer) {
        const shouldCheck = this.shouldCheckBoxBasedOnAPIResponse(apiAnswer);
        
        if (shouldCheck) {
          await this.clickElement(element);
          console.log(`✅ Checked checkbox based on API: "${checkboxLabel}"`);
        } else {
          console.log(`⏭️ Skipped checkbox based on API: "${checkboxLabel}"`);
        }
        return;
      }
    } catch (error) {
      console.warn(`⚠️ API checkbox decision failed:`, error.message);
    }
    
    const shouldCheckByDefault = this.shouldCheckBoxByDefault(checkboxLabel, questionContext);
    
    if (shouldCheckByDefault) {
      await this.clickElement(element);
      console.log(`✅ Checked checkbox by default logic: "${checkboxLabel}"`);
    } else {
      console.log(`⏭️ Skipped checkbox by default logic: "${checkboxLabel}"`);
    }
  }

  // Function to check if checkbox option is negative
  isNegativeCheckboxOption(label) {
    const normalizedLabel = label.toLowerCase().trim();
    
    const negativePatterns = [
      'none of these',
      'none of the above',
      'not applicable',
      'n/a',
      'no',
      'none',
      'never',
      'not interested',
      'decline',
      'refuse',
      'skip',
      'prefer not to',
      'prefer not to say',
      'prefer not to answer',
      'other (please specify)',
      'i don\'t have',
      'i do not have',
      'not available',
      'not required'
    ];
    
    return negativePatterns.some(pattern => 
      normalizedLabel.includes(pattern) || 
      normalizedLabel === pattern
    );
  }

  // Compare API response to question (for checkbox forms)
  shouldCheckBoxBasedOnAPIResponse(apiResponse) {
    const normalizedResponse = apiResponse.toLowerCase().trim();
    
    const positivePatterns = [
      'yes',
      'select',
      'check',
      'choose',
      'pick',
      'true',
      '✓',
      'applicable',
      'relevant',
      'appropriate'
    ];
    
    const negativePatterns = [
      'no',
      'don\'t',
      'do not',
      'skip',
      'uncheck',
      'leave unchecked',
      'false',
      '✗',
      'not applicable',
      'not relevant',
      'not appropriate'
    ];
    
    if (negativePatterns.some(pattern => normalizedResponse.includes(pattern))) {
      return false;
    }
    
    if (positivePatterns.some(pattern => normalizedResponse.includes(pattern))) {
      return true;
    }
    
    return false;
  }

  shouldCheckBoxByDefault(label, questionContext) {
    const normalizedLabel = label.toLowerCase().trim();
    const normalizedContext = questionContext.toLowerCase().trim();
    
    if (this.isNegativeCheckboxOption(label)) {
      return false;
    }
    
    const positivePatterns = [
      'experience',
      'skill',
      'knowledge',
      'familiar',
      'proficient',
      'certified',
      'qualification',
      'education',
      'degree',
      'training',
      'ability',
      'willing',
      'available',
      'interested',
      'comfortable',
      'capable'
    ];
    
    const hasPositivePattern = positivePatterns.some(pattern => 
      normalizedLabel.includes(pattern) || 
      normalizedContext.includes(pattern)
    );
    
    return hasPositivePattern;
  }

  findBestOptionMatch(options, apiResponse) {
    if (!apiResponse || !options || options.length === 0) {
      return null;
    }
    
    const normalizedResponse = apiResponse.toLowerCase().trim();
    console.log(`🔍 Finding EXACT option match for API response: "${normalizedResponse}"`);
    
    // Strategy 1: Try exact matches (text and value)
    for (const option of options) {
      if (option.value && option.text) {
        const optionText = option.text.toLowerCase().trim();
        const optionValue = option.value.toLowerCase().trim();
        
        if (optionText === normalizedResponse || optionValue === normalizedResponse) {
          console.log(`✅ Found exact match: "${option.text}"`);
          return option;
        }
      }
    }
    
    // Strategy 2: Handle special case where API response might have extra formatting
    const cleanedResponse = normalizedResponse
      .replace(/[{}",]/g, '')
      .replace(/^answer:\s*/i, '')
      .trim();
    
    if (cleanedResponse !== normalizedResponse) {
      console.log(`🔍 Trying cleaned response: "${cleanedResponse}"`);
      
      for (const option of options) {
        if (option.value && option.text) {
          const optionText = option.text.toLowerCase().trim();
          const optionValue = option.value.toLowerCase().trim();
          
          if (optionText === cleanedResponse || optionValue === cleanedResponse) {
            console.log(`✅ Found exact match with cleaned response: "${option.text}"`);
            return option;
          }
        }
      }
    }
    
    // Strategy 3: Special handling for common yes/no responses
    if (normalizedResponse.includes('yes') || normalizedResponse.includes('no')) {
      for (const option of options) {
        if (option.text) {
          const optionText = option.text.toLowerCase().trim();
          if ((normalizedResponse.includes('yes') && optionText === 'yes') ||
              (normalizedResponse.includes('no') && optionText === 'no')) {
            console.log(`✅ Found yes/no exact match: "${option.text}"`);
            return option;
          }
        }
      }
    }
    
    console.log(`❌ No EXACT option match found for: "${normalizedResponse}"`);
    console.log(`Available options were:`, options.map(o => o.text).join(', '));
    return null;
  }

  // Fill radio buttons using Questions Database and API fallback
    async fillRadioUsingDatabaseAndAPI(element) {
    const radioName = element.name;
    if (!radioName) {
        if (!element.checked) {
        await this.clickElement(element);
        console.log(`✅ Selected radio button (no name)`);
        }
        return;
    }

    const radioGroup = document.querySelectorAll(`input[name="${radioName}"]`);
    const parentElement = element.closest('fieldset, form, .form-group, .question-container') || document;
    
    const questionLabel = this.getRadioGroupLabel(radioGroup, parentElement);
    console.log(`📻 Radio group question: "${questionLabel}"`);
    
    const questionMatch = this.questionsDB.findQuestionMatch(questionLabel);
    
    if (questionMatch) {
        console.log(`✅ Found radio question match: ${questionMatch.id}`);
        const answer = this.questionsDB.getAnswerForQuestion(questionMatch, this.faqData);
        
        if (answer) {
        console.log(`🎯 Looking for radio option: "${answer}"`);
        const targetRadio = this.questionsDB.findRadioOption(radioGroup, answer);
        
        if (targetRadio && !targetRadio.checked) {
            await this.clickElement(targetRadio);
            console.log(`✅ Selected Questions DB radio: "${answer}"`);
            return;
        }
        }
    }
    
    console.log(`📋 Trying legacy radio handling...`);
    const legacySuccess = await this.fillRadioLegacy(radioGroup, questionLabel);
    if (legacySuccess) {
        return;
    }
    
    console.log(`🤖 Trying API fallback for radio group...`);
    try {
        const apiAnswer = await this.callJobApplyGPTAccess(element, questionLabel);
        if (apiAnswer) {
        console.log(`🎯 API suggested: "${apiAnswer}"`);
        const apiTargetRadio = this.findBestRadioMatch(radioGroup, apiAnswer);
        
        if (apiTargetRadio && !apiTargetRadio.checked) {
            await this.clickElement(apiTargetRadio);
            console.log(`✅ Selected API-matched radio: "${apiAnswer}"`);
            return;
        }
        }
    } catch (error) {
        console.warn(`⚠️ API radio selection failed:`, error.message);
    }
    
    if (radioGroup.length > 0 && !radioGroup[0].checked) {
        await this.clickElement(radioGroup[0]);
        console.log(`✅ Selected first radio option as final fallback`);
    }
    }

  // Find best matching radio button from API response
  findBestRadioMatch(radioGroup, apiResponse) {
    if (!apiResponse || !radioGroup || radioGroup.length === 0) {
      return null;
    }
    
    const normalizedResponse = apiResponse.toLowerCase().trim();
    console.log(`🔍 Finding best radio match for API response: "${normalizedResponse}"`);
    
    let bestMatch = null;
    let bestScore = 0;
    
    for (const radio of radioGroup) {
      const label = this.getRadioButtonLabel(radio).toLowerCase().trim();
      
      if (label) {
        let score = 0;
        
        if (label === normalizedResponse) {
          score = 100;
        } else if (label.includes(normalizedResponse) || normalizedResponse.includes(label)) {
          score = 50;
        } else if (normalizedResponse.includes('yes') && label.includes('yes')) {
          score = 80;
        } else if (normalizedResponse.includes('no') && label.includes('no')) {
          score = 80;
        } else {
          const responseWords = normalizedResponse.split(/\s+/);
          const labelWords = label.split(/\s+/);
          
          for (const word of responseWords) {
            if (word.length > 2 && labelWords.some(lw => lw.includes(word))) {
              score += word.length;
            }
          }
        }
        
        if (score > bestScore) {
          bestScore = score;
          bestMatch = radio;
        }
      }
    }
    
    if (bestMatch && bestScore > 0) {
      const matchLabel = this.getRadioButtonLabel(bestMatch);
      console.log(`✅ Found radio match: "${matchLabel}" (score: ${bestScore})`);
      return bestMatch;
    }
    
    console.log(`❌ No good radio match found for: "${normalizedResponse}"`);
    return null;
  }

  async fillRadioLegacy(radioGroup, questionContext) {
    const lowerContext = questionContext.toLowerCase();
    let targetOption = null;

    // Check if question is about sponsorship or visa
    if ((lowerContext.includes('sponsorship') || lowerContext.includes('visa')) &&
        !lowerContext.includes('have') && !lowerContext.includes('possess')) {
      radioGroup.forEach(radio => {
        const label = this.getRadioButtonLabel(radio);
        if (label.toLowerCase().includes('no')) {
          targetOption = radio;
        }
      });
      console.log(`🎯 Legacy: Detected sponsorship/visa question - selecting "No"`);
    } else {
      radioGroup.forEach(radio => {
        const label = this.getRadioButtonLabel(radio);
        if (label.toLowerCase().includes('yes')) {
          targetOption = radio;
        }
      });
      console.log(`🎯 Legacy: Standard question - selecting "Yes"`);
    }

    if (!targetOption && radioGroup.length > 0) {
      targetOption = radioGroup[0];
      console.log(`🎯 Legacy: No target found, selecting first option`);
    }

    if (targetOption && !targetOption.checked) {
      await this.clickElement(targetOption);
      console.log(`✅ Selected legacy radio option`);
      return true;
    }
    
    return false;
  }

  getRadioGroupLabel(radioGroup) {
    if (radioGroup.length === 0) return '';
    
    // Strategy 1: find fieldset legend
    const fieldset = radioGroup[0].closest('fieldset');
    if (fieldset) {
      const legend = fieldset.querySelector('legend');
      if (legend) {
        const strongElement = legend.querySelector('strong');
        if (strongElement && strongElement.textContent.trim()) {
          const questionText = strongElement.textContent.trim();
          console.log(`✅ Found radio question in legend > strong: "${questionText}"`);
          return questionText;
        }
        
        const legendText = legend.textContent.trim();
        if (legendText && legendText.length > 10) {
          console.log(`✅ Found radio question in legend: "${legendText}"`);
          return legendText;
        }
      }
    }
    
    // Strategy 2: find question container
    const questionContainer = radioGroup[0].closest('[id*="question-"], .question, .form-group, [class*="question"]');
    if (questionContainer) {
      const strongElements = questionContainer.querySelectorAll('strong');
      for (const strongEl of strongElements) {
        const text = strongEl.textContent.trim();
        if (text && text.length > 10 && text.includes('?')) {
          console.log(`✅ Found radio question in strong element: "${text}"`);
          return text;
        }
      }
      
      const questionElements = questionContainer.querySelectorAll('h1, h2, h3, h4, h5, h6, .question-text, .field-label');
      for (const questionEl of questionElements) {
        const text = questionEl.textContent.trim();
        if (text && text.length > 10 && !text.toLowerCase().includes('radio')) {
          console.log(`✅ Found radio question in question element: "${text}"`);
          return text;
        }
      }
    }
    
    // Strategy 3: Look for span with question text near the radio group
    let currentElement = radioGroup[0].parentElement;
    let searchDepth = 0;
    
    while (currentElement && searchDepth < 5) {
      const spans = currentElement.querySelectorAll('span strong, span');
      for (const span of spans) {
        const text = span.textContent.trim();
        if (text && text.length > 15 && text.includes('?') && 
            !text.toLowerCase().includes('yes') && 
            !text.toLowerCase().includes('no')) {
          console.log(`✅ Found radio question in span: "${text}"`);
          return text;
        }
      }
      currentElement = currentElement.parentElement;
      searchDepth++;
    }
    
    // Strategy 4: Try previous sibling elements
    let sibling = radioGroup[0].parentElement?.previousElementSibling;
    let siblingChecks = 0;
    while (sibling && siblingChecks < 3) {
      const text = sibling.textContent?.trim();
      if (text && text.length > 10 && text.includes('?')) {
        console.log(`✅ Found radio question in previous sibling: "${text}"`);
        return text;
      }
      sibling = sibling.previousElementSibling;
      siblingChecks++;
    }
    
    // Strategy 5: Fallback
    const firstRadioLabel = this.getRadioButtonLabel(radioGroup[0]);
    if (firstRadioLabel && firstRadioLabel !== 'no-label-found') {
      const contextualQuestion = `Question related to: ${firstRadioLabel}`;
      console.log(`⚠️ Using contextual question: "${contextualQuestion}"`);
      return contextualQuestion;
    }
    
    console.log(`❌ Could not find radio group question`);
    return 'Please select the most appropriate option';
  }

  getRadioButtonLabel(radioElement) {
    return this.questionsDB.getRadioLabel(radioElement);
  }

  getFAQValue(element) {
    if (!this.faqData) {
      return null;
    }
    
    const label = this.getElementLabel(element).toLowerCase();
    console.log(`🔍 Looking for legacy FAQ value for label: "${label}"`);
    
    // Map common field labels to FAQ data keys
    const fieldMappings = {
      // Personal Information
      'first name': 'first_name',
      'given name': 'first_name',
      'last name': 'last_name',
      'surname': 'last_name',
      'family name': 'last_name',
      'email': 'email',
      'phone': 'phone',
      'telephone': 'phone',
      'mobile': 'phone',
      'phone number': 'phone',
      
      // Location
      'city': 'search_city',
      'location': 'search_city',
      'country': 'search_country',
      'state': 'search_city',
      
      // Work Details
      'job title': 'job_title',
      'current role': 'job_title',
      'position': 'job_title',
      'company': 'company',
      'employer': 'company',
      'organisation': 'company',
      'organization': 'company',
      
      // Years of experience
      'years': 'years_of_experience',
      'experience': 'years_of_experience',
      'year experience': 'years_of_experience',
      'years experience': 'years_of_experience',
      'years of experience': 'years_of_experience',
      
      // Salary
      'salary': 'target_salary',
      'expected salary': 'target_salary',
      'desired salary': 'target_salary',
      'current salary': 'current_salary'
    };
    
    // Try exact matches first
    for (const [key, faqKey] of Object.entries(fieldMappings)) {
      if (label.includes(key) && this.faqData[faqKey]) {
        const value = this.faqData[faqKey];
        console.log(`✅ Found legacy FAQ mapping: ${key} -> ${faqKey} = ${value}`);
        
        if (element.type === 'radio' || element.type === 'checkbox') {
          if (typeof value === 'boolean') {
            return value ? 'yes' : 'no';
          }
          
          return String(value);
        }
      }
    }
    
    if (label.includes('country code') || label.includes('phone country')) {
      const countryCode = this.faqData['phone_country_code'];
      if (countryCode) {
        console.log(`✅ Found phone country code: ${countryCode}`);
        return countryCode;
      }
    }
    
    console.log(`❌ No legacy FAQ value found for label: "${label}"`);
    return null;
  }

  getElementLabel(element) {
    // Strategy 1: Check for associated label
    if (element.id) {
      const label = document.querySelector(`label[for="${element.id}"]`);
      if (label && label.textContent.trim()) {
        return label.textContent.trim();
      }
    }
    
    // Strategy 2: Check for parent label
    const parentLabel = element.closest('label');
    if (parentLabel && parentLabel.textContent.trim()) {
      return parentLabel.textContent.trim();
    }
    
    // Strategy 3: Check for placeholder
    if (element.placeholder && element.placeholder.trim()) {
      return element.placeholder.trim();
    }
    
    // Strategy 4: Check for name attribute
    if (element.name && element.name.trim()) {
      return element.name.trim();
    }
    
    // Strategy 5: Check siblings for text content
    if (element.parentElement) {
      const siblings = Array.from(element.parentElement.children);
      const textSibling = siblings.find(sibling => 
        sibling !== element && 
        sibling.textContent && 
        sibling.textContent.trim().length > 0 &&
        !sibling.tagName.match(/^(INPUT|SELECT|TEXTAREA|BUTTON)$/)
      );
      
      if (textSibling) {
        return textSibling.textContent.trim();
      }
    }
    
    return 'no-label-found';
  }

  triggerEvents(element) {
    element.dispatchEvent(new Event('input', { bubbles: true }));    
    element.dispatchEvent(new Event('change', { bubbles: true }));    
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Utility functions
  async waitForPageLoad() {
    console.log('⏳ Waiting for page to load...');
    
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        setTimeout(resolve, 500);
      } else {
        window.addEventListener('load', () => {
          setTimeout(resolve, 500);
        });
      }
    });
  }

  async clickElement(element) {
    return new Promise((resolve) => {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      setTimeout(() => {
        element.focus();
        
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        
        element.dispatchEvent(clickEvent);
        
        if (element.type === 'radio' || element.type === 'checkbox') {
          const changeEvent = new Event('change', { bubbles: true });
          element.dispatchEvent(changeEvent);
        }
        
        resolve();
      }, 500);
    });
  }
}

// Integration function
export async function automateSeekRoleRequirements() {
  console.log('🎯 Initializing Seek Role Requirements automation with FAQ integration and API fallback');
  
  const url = window.location.href.toLowerCase();
  if (!url.includes('role-requirements')) {
    console.log('ℹ️ Not on role-requirements stage, skipping automation');
    return false;
  }
  
  const automation = new SeekRoleRequirementsAutomation();
  
  try {
    const success = await automation.automateRoleRequirements();
    return success;
  } catch (error) {
    console.error('❌ Role Requirements automation failed:', error);
    throw error;
  }
}