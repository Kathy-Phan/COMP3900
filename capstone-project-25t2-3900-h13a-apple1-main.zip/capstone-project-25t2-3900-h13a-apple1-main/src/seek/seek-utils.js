import { SEEK_URLS } from './seek-config.js';

// Check if we're on any Seek application page
export function isSeekApplicationPage(url) {
  return url.includes(SEEK_URLS.domain) && 
		SEEK_URLS.applicationPaths.some(path => url.includes(path));
}

// Determine which specific stage of the application we're on
export function getSeekApplicationStage(url) {
  if (!isSeekApplicationPage(url)) {
    return null;
  }
  
  const lowerUrl = url.toLowerCase();
  
	if (lowerUrl.includes('/apply/success')) {
    return 'success';
  } else if (lowerUrl.includes('/apply/review')) {
    return 'review';
  } else if (lowerUrl.includes('/apply/profile')) {
    return 'profile';  
  } else if (lowerUrl.includes('/apply/role-requirements')) {
    return 'role-requirements';
  } else if (lowerUrl.includes('/apply') && !lowerUrl.includes('/apply/')) {
    return 'apply';
  } else if (lowerUrl.includes('/apply/')) {
    return 'unknown-apply-stage';
  }
  
  return 'unknown';
}
