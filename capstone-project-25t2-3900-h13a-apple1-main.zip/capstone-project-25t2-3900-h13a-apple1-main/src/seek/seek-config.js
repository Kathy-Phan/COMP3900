// Seek file to load styles for extension window 

export const SEEK_SELECTORS = {
  logo: '[data-testid="bx-logo-image"] img',
  
  jobTitle: [
    '[data-automation="job-detail-title"] a',
    'h1[data-automation="job-detail-title"]',
    'h1'
  ],
  
  companyName: '[data-automation="advertiser-name"]',
  
  location: [
    '[data-automation="job-detail-location"] a',
    '[data-automation="job-detail-location"]'
  ],
  
  applyButtons: [
    'a[data-automation="job-detail-apply"]',
    'button[data-automation="job-detail-apply"]',
    'a[href*="/apply"]',
    'button[aria-label*="Apply"]',
    '.apply-button',
    'a.apply-link',
    '[data-testid="apply-button"]'
  ]
};

export const SEEK_CONFIG = {
  logoTimeout: 200,
  maxContentAttempts: 10,
  contentCheckInterval: 100,
  applyButtonDelay: 100
};

export const SEEK_URLS = {
  domain: 'seek.com.au',
  applicationPaths: [
    '/apply',
    '/apply/role-requirements', 
    '/apply/profile',
    '/apply/review'
  ]
};