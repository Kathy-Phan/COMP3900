// This file will handle automation of the first page of the application which handles resume and cover letter upload.

export class SeekApplyStageAutomation {
  constructor() {
    this.maxRetries = 3;
    this.retryCount = 0;
    
    this.formConfig = {
      resume: {
        selection: 'upload',
        reason: 'api-integration'
      },
      coverLetter: {
        selection: 'upload',
        reason: 'api-integration'
      }
    };
  }

  // Main function to automate the apply stage
  async automateApplyStage(externalConfig = null) {
    console.log('🚀 Starting Apply Stage automation with automated resume deletion (no user prompts)');
    
    if (externalConfig) {
      this.updateConfiguration(externalConfig);
    }
    
    try {
      await this.waitForPageLoad();
      
      // Handle resume selection and upload
      await this.selectRadioOption('resume', this.formConfig.resume.selection);
      
      if (this.formConfig.resume.selection === 'upload') {
        await this.handleResumeUpload();
      }
      
      // Handle cover letter selection and upload
      await this.selectRadioOption('coverLetter', this.formConfig.coverLetter.selection);
      
      if (this.formConfig.coverLetter.selection === 'upload') {
        await this.handleCoverLetterUpload();
      }
      
      await this.clickContinue();
      
      // After navigation, trigger the next stage
      console.log('🔄 Apply stage completed, triggering next stage detection...');
      setTimeout(async () => {
        try {
          const { handleSeekApplicationPage } = await import(chrome.runtime.getURL('seek/seek-handler.js'));
          await handleSeekApplicationPage();
        } catch (error) {
          console.error('❌ Failed to trigger next stage:', error);
        }
      }, 2000);
      
      console.log('✅ Apply stage automation completed successfully');
      return true;
      
    } catch (error) {
      console.error('❌ Apply stage automation failed:', error);
      throw error;
    }
  }

  async handleResumeUpload() {
    console.log('📄 Starting resume upload process');
    
    try {
      // Retrieves resume from local storage (cached API response)
      const storedResponse = await this.getStoredAPIResponse();
      const resumeUrl = storedResponse?.resumeUrl;
      
      if (!resumeUrl) {
        throw new Error('No resume URL found in stored API response');
      }
      
      console.log('✅ Resume URL retrieved from storage:', resumeUrl);
      
      await this.triggerResumeLimitCheckOnly();
      
      const hasLimitModal = await this.checkForResumeLimitModal();
      
      if (hasLimitModal) {
        console.log('⚠️ Resume limit reached - automatically deleting oldest resume');
        await this.handleResumeLimitAutomatically();
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const stillHasModal = await this.checkForResumeLimitModal();
        if (stillHasModal) {
          throw new Error('Resume limit modal still present after deletion attempt');
        }
      }
      
      await this.uploadFileDirectly(resumeUrl, 'resume');
      
      await this.verifyResumeUploadSuccess();
      
      console.log('✅ Resume upload completed successfully');
      
    } catch (error) {
      console.error('❌ Resume upload failed:', error);
      throw error;
    }
  }

  async triggerResumeLimitCheckOnly() {
    console.log('🔍 Triggering resume limit check...');
    
    try {
      const uploadButton = document.querySelector('button[data-testid="upload-button"][aria-describedby="resume-file-file-type"]');
      
      if (!uploadButton) {
        console.log('ℹ️ No upload button found - proceeding with direct upload');
        return;
      }
      
      // Temporarily override file input click to prevent OS dialog
      const fileInput = document.querySelector('input[type="file"][id*="resume"]');
      let originalClick = null;
      
      if (fileInput) {
        originalClick = fileInput.click;
        fileInput.click = () => {
          console.log('🚫 File input click suppressed to avoid OS dialog');
        };
      }
      
      await this.clickElement(uploadButton);
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      if (fileInput && originalClick) {
        fileInput.click = originalClick;
      }
      
      console.log('✅ Resume limit check completed');
      
    } catch (error) {
      console.warn('⚠️ Error during resume limit check:', error);
    }
  }

  async checkForResumeLimitModal() {
    console.log('🔍 Checking for resume limit modal...');
    
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const limitModal = document.querySelector('[data-testid="10-resume-limit-text"]');
    const limitDropdown = document.querySelector('#docLimitExceededDropdown');
    const deleteButton = document.querySelector('button[data-automation="10-resume-delete"]');
    
    const hasModal = !!(limitModal && limitDropdown && deleteButton);
    
    console.log(`${hasModal ? '⚠️' : '✅'} Resume limit modal ${hasModal ? 'detected' : 'not present'}`);
    
    return hasModal;
  }

  async handleResumeLimitAutomatically() {
    console.log('🤖 Automatically handling resume limit modal...');
    
    try {
      this.showAutomatedDeletionNotification();
      
      await this.selectLastResumeOption();      
      await this.clickDeleteButton();      
      await this.waitForDeletionComplete();
      
      console.log('✅ Automated resume deletion completed');
      
    } catch (error) {
      console.error('❌ Failed to handle resume limit automatically:', error);
      throw error;
    }
  }

  showAutomatedDeletionNotification() {
    console.log('📢 Showing automated deletion notification...');
    
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 20px;
      border-radius: 12px;
      z-index: 99999;
      max-width: 380px;
      box-shadow: 0 8px 32px rgba(102, 126, 234, 0.4);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      border: 1px solid rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      animation: slideIn 0.3s ease-out;
    `;
    
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);
    
    notification.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 12px;">
        <div style="font-size: 24px; margin-right: 12px; animation: pulse 2s infinite;">🤖</div>
        <div style="font-weight: 600; font-size: 16px;">Auto-Processing Resume</div>
      </div>
      <div style="margin-bottom: 12px; line-height: 1.5; font-size: 14px; opacity: 0.95;">
        Resume limit reached. Deleting oldest resume and uploading new AI-generated version...
      </div>
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div style="font-size: 12px; opacity: 0.8;">
          ⚡ Fully automated - no action needed
        </div>
        <div style="font-size: 12px; opacity: 0.7;">
          Auto-closing in 5s
        </div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentElement) {
        notification.style.animation = 'slideOut 0.3s ease-in forwards';
        notification.style.animationName = 'slideOut';
        
        style.textContent += `
          @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
          }
          @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
          }
        `;
        
        setTimeout(() => {
          if (notification.parentElement) {
            notification.remove();
            style.remove();
          }
        }, 300);
      }
    }, 5000);
  }

  async selectLastResumeOption() {
    console.log('📋 Automatically selecting oldest resume for deletion...');
    
    const dropdown = document.querySelector('#docLimitExceededDropdown');
    
    if (!dropdown) {
      throw new Error('Resume limit dropdown not found');
    }
    
    const options = dropdown.querySelectorAll('option:not([disabled])');
    
    if (options.length === 0) {
      throw new Error('No resume options found in dropdown');
    }
    
    const lastOption = options[options.length - 1];
    dropdown.value = lastOption.value;
    
    dropdown.dispatchEvent(new Event('change', { bubbles: true }));
    dropdown.dispatchEvent(new Event('input', { bubbles: true }));
    
    console.log(`✅ Automatically selected resume for deletion: ${lastOption.textContent.trim()}`);
    
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  async clickDeleteButton() {
    console.log('🗑️ Automatically clicking delete button...');
    
    const deleteButton = document.querySelector('button[data-automation="10-resume-delete"]');
    
    if (!deleteButton) {
      throw new Error('Delete button not found');
    }
    
    if (deleteButton.disabled) {
      throw new Error('Delete button is disabled');
    }
    
    await this.clickElement(deleteButton);
    
    console.log('✅ Delete button clicked automatically');
  }

  async verifyResumeUploadSuccess() {
    console.log('🔍 Verifying resume upload success...');
    let uploadVerified = false;
    
    const fileInput = document.querySelector('input[type="file"][id*="resume"]');
    if (fileInput && fileInput.files && fileInput.files.length > 0) {
      console.log('✅ Resume file detected in input');
      uploadVerified = true;
    }
    
    const statusElements = document.querySelectorAll('span[role="status"]');
    for (const element of statusElements) {
      if (element.textContent && element.textContent.toLowerCase().includes('resumé attached')) {
        console.log('✅ Resume attached status message found');
        uploadVerified = true;
        break;
      }
    }
    
    const resumeDropdown = document.querySelector('select[data-testid="select-input"]');
    if (resumeDropdown && resumeDropdown.value && resumeDropdown.value !== '') {
      console.log('✅ Resume selected in dropdown');
      uploadVerified = true;
    }
    
    if (!uploadVerified) {
      console.warn('⚠️ Could not verify resume upload success - continuing anyway');
    } else {
      console.log('✅ Resume upload verification successful');
    }
  }

  async handleCoverLetterUpload() {
    console.log('📄 Starting cover letter upload process (direct upload)...');
    
    try {
      const storedResponse = await this.getStoredAPIResponse();
      const coverLetterUrl = storedResponse?.coverLetterUrl;
      
      if (!coverLetterUrl || coverLetterUrl === 'none') {
        console.log('ℹ️ No cover letter URL provided, skipping upload');
        return;
      }
      
      console.log('✅ Cover letter URL retrieved from storage:', coverLetterUrl);
      
      await this.uploadFileDirectly(coverLetterUrl, 'coverLetter');
      
      this.showCoverLetterSuccessNotification(coverLetterUrl);
      
      console.log('✅ Cover letter upload completed successfully');
      
    } catch (error) {
      console.error('❌ Cover letter upload failed:', error);
      throw error;
    }
  }

  // Universal direct file upload method
  async uploadFileDirectly(url, fileType) {
    console.log(`📤 Uploading ${fileType} from URL directly to input (no OS popup)...`);
    
    try {
      console.log(`🔄 Downloading ${fileType} from: ${url}`);
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to download ${fileType}: ${response.status} ${response.statusText}`);
      }
      
      const blob = await response.blob();
      const fileName = fileType === 'resume' ? 'resume.pdf' : 'cover_letter.pdf';
      const file = new File([blob], fileName, { type: "application/pdf" });
      
      console.log(`✅ File downloaded successfully:`, {
        name: fileName,
        size: `${Math.round(blob.size / 1024)}KB`,
        type: file.type
      });
      
      const fileInputSelector = fileType === 'resume' 
        ? 'input[type="file"][id*="resume"]'
        : 'input[type="file"][id*="coverLetter"]';
        
      const fileInput = document.querySelector(fileInputSelector);
      if (!fileInput) {
        throw new Error(`${fileType} file input not found with selector: ${fileInputSelector}`);
      }
      
      console.log(`✅ Found ${fileType} file input:`, fileInput.id || fileInput.name || 'unnamed');
      
      // Create DataTransfer and assign file
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);      
      fileInput.files = dataTransfer.files;
      
      console.log(`📎 File assigned to input (${fileInput.files.length} files)`);
      
      const events = [
        new Event('change', { bubbles: true, cancelable: true }),
        new Event('input', { bubbles: true, cancelable: true }),
        new Event('blur', { bubbles: true, cancelable: true }),
        new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertReplacementText' })
      ];
      
      for (const event of events) {
        fileInput.dispatchEvent(event);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      console.log(`✅ All events triggered for ${fileType} input`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      if (fileInput.files.length > 0) {
        console.log(`✅ ${fileType} upload completed successfully - ${fileInput.files.length} file(s) in input`);        
        await this.waitForUploadProcessing(fileType);
        
      } else {
        console.warn(`⚠️ ${fileType} input appears empty after upload attempt`);
        throw new Error(`${fileType} upload verification failed - no files in input`);
      }
      
    } catch (error) {
      console.error(`❌ Direct ${fileType} upload failed:`, error);
      
      this.showManualUploadFallback(url, fileType);
      throw error;
    }
  }

  async getStoredAPIResponse() {
    try {
      const result = await chrome.storage.local.get(['jobgen_api_response']);
      const storedResponse = result.jobgen_api_response;
      
      if (!storedResponse) {
        console.warn('⚠️ No stored API response found');
        return null;
      }
      
      const currentTime = Date.now();
      const responseAge = currentTime - storedResponse.timestamp;
      const maxAge = 10 * 60 * 1000; // 10 minutes
      
      if (responseAge > maxAge) {
        console.warn('⚠️ Stored API response is too old, clearing it');
        await chrome.storage.local.remove(['jobgen_api_response']);
        return null;
      }
      
      const currentUrl = window.location.href;
      const storedJobUrl = storedResponse.jobUrl;
      
      const extractJobId = (url) => {
        const match = url.match(/jobId=(\d+)|\/job\/(\d+)/);
        return match ? (match[1] || match[2]) : null;
      };
      
      const currentJobId = extractJobId(currentUrl);
      const storedJobId = extractJobId(storedJobUrl);
      
      if (currentJobId && storedJobId && currentJobId !== storedJobId) {
        console.warn('⚠️ Stored API response is for a different job, clearing it');
        await chrome.storage.local.remove(['jobgen_api_response']);
        return null;
      }
      
      console.log('✅ Found valid stored API response:', {
        jobId: storedResponse.jobId,
        hasResume: !!storedResponse.resumeUrl,
        hasCoverLetter: !!storedResponse.coverLetterUrl,
        age: Math.round(responseAge / 1000) + 's'
      });
      
      return storedResponse;
      
    } catch (error) {
      console.error('❌ Error retrieving stored API response:', error);
      return null;
    }
  }

  // Show success notification for cover letter upload
  showCoverLetterSuccessNotification(coverLetterUrl) {
    console.log('🎉 Showing cover letter success notification...');
    
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #27ae60;
      color: white;
      padding: 20px;
      border-radius: 8px;
      z-index: 99999;
      max-width: 380px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      font-family: Arial, sans-serif;
      border-left: 4px solid #2ecc71;
    `;
    
    notification.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 12px;">
        <div style="font-size: 24px; margin-right: 10px;">✅</div>
        <div style="font-weight: bold; font-size: 16px;">Cover Letter Uploaded Successfully!</div>
      </div>
      <div style="margin-bottom: 15px; line-height: 1.4; font-size: 14px;">
        Your AI-generated cover letter has been uploaded and attached to this application.
      </div>
      <div style="margin-bottom: 15px;">
        <a href="${coverLetterUrl}" target="_blank" style="
          color: white;
          text-decoration: none;
          font-weight: bold;
          display: inline-block;
          padding: 8px 16px;
          background: rgba(255,255,255,0.2);
          border-radius: 4px;
          margin: 5px 5px 5px 0;
          font-size: 13px;
          border: 1px solid rgba(255,255,255,0.3);
          transition: all 0.2s ease;
        " onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">
          📄 View Cover Letter
        </a>
        <a href="${coverLetterUrl}" target="_blank" download="cover_letter.pdf" style="
          color: white;
          text-decoration: none;
          font-weight: bold;
          display: inline-block;
          padding: 8px 16px;
          background: rgba(255,255,255,0.2);
          border-radius: 4px;
          margin: 5px 5px 5px 0;
          font-size: 13px;
          border: 1px solid rgba(255,255,255,0.3);
          transition: all 0.2s ease;
        " onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">
          💾 Download Copy
        </a>
      </div>
      <div style="font-size: 12px; opacity: 0.9; margin-bottom: 15px; color: #ecf0f1;">
        The cover letter is now part of your application and will be submitted automatically.
      </div>
      <button onclick="this.parentElement.remove()" style="
        float: right;
        background: rgba(255,255,255,0.2);
        border: 1px solid rgba(255,255,255,0.3);
        color: white;
        cursor: pointer;
        padding: 6px 10px;
        border-radius: 3px;
        font-size: 12px;
        transition: all 0.2s ease;
      " onmouseover="this.style.background='rgba(255,255,255,0.3)'" onmouseout="this.style.background='rgba(255,255,255,0.2)'">✕ Close</button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentElement) {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        notification.style.transition = 'all 0.3s ease';
        setTimeout(() => {
          if (notification.parentElement) {
            notification.remove();
          }
        }, 300);
      }
    }, 20000);
  }

  // Fallback manual upload instructions for both resume and cover letter
  showManualUploadFallback(fileUrl, fileType) {
    console.log(`📋 Showing manual ${fileType} upload fallback...`);
    
    const fileLabel = fileType === 'resume' ? 'Resume' : 'Cover Letter';
    const fileName = fileType === 'resume' ? 'resume.pdf' : 'cover_letter.pdf';
    
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #e67e22;
      color: white;
      padding: 20px;
      border-radius: 8px;
      z-index: 99999;
      max-width: 350px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      font-family: Arial, sans-serif;
    `;
    
    notification.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 12px; font-size: 16px;">⚠️ Manual ${fileLabel} Upload</div>
      <div style="margin-bottom: 15px; line-height: 1.4;">Automatic upload failed. Please upload manually:</div>
      <div style="margin-bottom: 15px;">
        <a href="${fileUrl}" target="_blank" download="${fileName}" style="
          color: white;
          text-decoration: underline;
          font-weight: bold;
          display: inline-block;
          padding: 8px 12px;
          background: rgba(255,255,255,0.2);
          border-radius: 4px;
          margin: 5px 0;
        ">📥 Download ${fileLabel}</a>
      </div>
      <div style="font-size: 13px; opacity: 0.9; margin-bottom: 15px;">
        Download and upload using the file selector.
      </div>
      <button onclick="this.parentElement.remove()" style="
        float: right;
        background: rgba(255,255,255,0.3);
        border: none;
        color: white;
        cursor: pointer;
        padding: 5px 8px;
        border-radius: 3px;
        font-size: 12px;
      ">✕ Close</button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentElement) {
        notification.remove();
      }
    }, 30000);
  }

  async selectRadioOption(fieldType, selectedValue) {
    console.log(`🎯 Selecting ${fieldType} option: ${selectedValue}`);
    
    const fieldConfigs = {
      resume: {
        groupName: 'resume-method',
        options: {
          upload: { testId: 'resume-method-upload', value: 'upload', label: 'Upload a resumé' },
          change: { testId: 'resume-method-change', value: 'change', label: 'Select a resumé' },
          none: { testId: 'resume-method-none', value: 'none', label: 'Don\'t include a resumé' }
        }
      },
      coverLetter: {
        groupName: 'coverLetter-method',
        options: {
          upload: { testId: 'coverLetter-method-upload', value: 'upload', label: 'Upload a cover letter' },
          change: { testId: 'coverLetter-method-change', value: 'change', label: 'Write a cover letter' },
          none: { testId: 'coverLetter-method-none', value: 'none', label: 'Don\'t include a cover letter' }
        }
      }
    };

    const fieldConfig = fieldConfigs[fieldType];
    const optionConfig = fieldConfig.options[selectedValue];
    
    if (!fieldConfig || !optionConfig) {
      throw new Error(`Invalid field type "${fieldType}" or option "${selectedValue}"`);
    }

    const selectors = [
      `input[data-testid="${optionConfig.testId}"]`,
      `input[name="${fieldConfig.groupName}"][value="${optionConfig.value}"]`
    ];

    for (const selector of selectors) {
      const radioButton = document.querySelector(selector);
      if (radioButton) {
        console.log(`✅ Found ${fieldType} radio button`);
        
        if (radioButton.checked || radioButton.getAttribute('aria-checked') === 'true') {
          console.log(`✅ "${optionConfig.label}" already selected`);
          return;
        }
        
        await this.clickElement(radioButton);
        await new Promise(resolve => setTimeout(resolve, 500));
        
        console.log(`✅ "${optionConfig.label}" selected`);
        return;
      }
    }
    
    throw new Error(`Could not find ${fieldType} option "${selectedValue}"`);
  }

  async clickContinue() {
    console.log('🔘 Looking for Continue button...');
    
    const continueButton = document.querySelector('button[data-testid="continue-button"]');
    
    if (continueButton && continueButton.offsetParent !== null && !continueButton.disabled) {
      console.log('✅ Found Continue button');
      await this.clickElement(continueButton);
      await this.waitForNavigation();
      console.log('✅ Continue button clicked successfully');
    } else {
      throw new Error('Could not find Continue button');
    }
  }

  async clickElement(element) {
    return new Promise((resolve) => {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      setTimeout(() => {
        element.focus();
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        element.dispatchEvent(clickEvent);
        
        if (element.type === 'radio') {
          const changeEvent = new Event('change', { bubbles: true });
          element.dispatchEvent(changeEvent);
        }
        
        resolve();
      }, 500);
    });
  }

  async waitForPageLoad() {
    console.log('⏳ Waiting for page to load...');
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        setTimeout(resolve, 1500);
      } else {
        window.addEventListener('load', () => {
          setTimeout(resolve, 1500);
        });
      }
    });
  }

  async waitForNavigation() {
    console.log('🔄 Waiting for navigation...');
    const currentUrl = window.location.href;
    let attempts = 0;
    const maxAttempts = 30;
    
    return new Promise((resolve, reject) => {
      const checkNavigation = () => {
        attempts++;
        if (window.location.href !== currentUrl) {
          console.log(`✅ Navigation detected to: ${window.location.href}`);
          resolve();
        } else if (attempts >= maxAttempts) {
          reject(new Error('Navigation timeout'));
        } else {
          setTimeout(checkNavigation, 1000);
        }
      };
      setTimeout(checkNavigation, 1000);
    });
  }

  async waitForDeletionComplete() {
    console.log('⏳ Waiting for deletion to complete...');
    
    let attempts = 0;
    const maxAttempts = 10;
    
    while (attempts < maxAttempts) {
      const limitModal = document.querySelector('[data-testid="10-resume-limit-text"]');
      
      if (!limitModal || limitModal.offsetParent === null) {
        console.log('✅ Resume limit modal disappeared - deletion complete');
        return;
      }
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      attempts++;
    }
    
    console.warn('⚠️ Deletion timeout - continuing anyway');
  }

  async waitForUploadProcessing(fileType) {
    console.log(`⏳ Waiting for ${fileType} upload processing...`);
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  updateConfiguration(apiConfig) {
    console.log('🔧 Updating configuration:', apiConfig);
    if (apiConfig.resume) {
      this.formConfig.resume = { ...this.formConfig.resume, ...apiConfig.resume };
    }
    if (apiConfig.coverLetter) {
      this.formConfig.coverLetter = { ...this.formConfig.coverLetter, ...apiConfig.coverLetter };
    }
  }
}

// Integrate the entire extension functionality with other stages
export async function automateSeekApplyStage(configFromAPI = null) {
  console.log('🎯 Initializing Seek Apply Stage automation with automated resume deletion');
  
  const url = window.location.href.toLowerCase();
  if (!url.includes('apply')) {
    console.log('ℹ️ Not on apply stage, skipping automation');
    return false;
  }
  
  const automation = new SeekApplyStageAutomation();
  
  try {
    const defaultConfig = {
      resume: {
        selection: 'upload',
        reason: 'api-integration'
      },
      coverLetter: {
        selection: 'upload',
        reason: 'api-integration'
      }
    };
    
    const config = configFromAPI || defaultConfig;
    const success = await automation.automateApplyStage(config);
    return success;
  } catch (error) {
    console.error('❌ Apply stage automation failed:', error);
    throw error;
  }
}