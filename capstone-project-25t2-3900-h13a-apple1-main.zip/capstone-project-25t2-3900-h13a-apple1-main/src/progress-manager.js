// Progress Manager for tracking applied jobs
export class ProgressManager {
    static MAX_JOBS = 5;
    static STORAGE_KEY = 'appliedJobs';

    // Load applied jobs from storage
    static async getAppliedJobs() {
        try {
            const result = await chrome.storage.local.get([ProgressManager.STORAGE_KEY]);
            return result[ProgressManager.STORAGE_KEY] || [];
        } catch (error) {
            console.error('Error loading applied jobs:', error);
            return [];
        }
    }

    // Save applied jobs to storage
    static async saveAppliedJobs(jobs) {
        try {
            await chrome.storage.local.set({ [ProgressManager.STORAGE_KEY]: jobs });
            return true;
        } catch (error) {
            console.error('Error saving applied jobs:', error);
            return false;
        }
    }

    // Add a new applied job
    static async addAppliedJob(jobData, isApply = true) {
        try {
            const jobs = await ProgressManager.getAppliedJobs();
            
            const newJob = {
                jobId: jobData.jobId || null,
                jobTitle: jobData.jobTitle || 'Unknown Title',
                companyName: jobData.companyName || 'Unknown Company',
                companyLogo: jobData.companyLogo || null,
                location: jobData.location || 'Not specified',
                jobUrl: jobData.jobUrl || window.location.href,
                status: isApply ? 'applied' : 'reviewed',
                appliedDate: new Date().toISOString(),
                excitement: jobData.excitement || 3
            };

            // Add to beginning of array (most recent first)
            jobs.unshift(newJob);
            
            // Keep only the last MAX_JOBS jobs
            if (jobs.length > ProgressManager.MAX_JOBS) {
                jobs.splice(ProgressManager.MAX_JOBS);
            }
            
            await ProgressManager.saveAppliedJobs(jobs);
            return newJob;
        } catch (error) {
            console.error('Error adding applied job:', error);
            return null;
        }
    }

    // Update job with job_id from API response
    static async updateJobId(jobIndex, jobId) {
        try {
            const jobs = await ProgressManager.getAppliedJobs();
            if (jobs[jobIndex]) {
                jobs[jobIndex].jobId = jobId;
                await ProgressManager.saveAppliedJobs(jobs);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error updating job ID:', error);
            return false;
        }
    }

    // Update job status
    static async updateJobStatus(jobId, status) {
        try {
            const jobs = await ProgressManager.getAppliedJobs();
            const jobIndex = jobs.findIndex(job => job.jobId === jobId);
            
            if (jobIndex !== -1) {
                jobs[jobIndex].status = status;
                await ProgressManager.saveAppliedJobs(jobs);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error updating job status:', error);
            return false;
        }
    }

    // Clear all applied jobs (for testing/reset)
    static async clearAppliedJobs() {
        try {
            await chrome.storage.local.remove([ProgressManager.STORAGE_KEY]);
            return true;
        } catch (error) {
            console.error('Error clearing applied jobs:', error);
            return false;
        }
    }

    // Get job statistics
    static async getJobStats() {
        try {
            const jobs = await ProgressManager.getAppliedJobs();
            return {
                total: jobs.length,
                applied: jobs.filter(job => job.status === 'applied').length,
                reviewed: jobs.filter(job => job.status === 'reviewed').length,
                pending: jobs.filter(job => !job.jobId).length
            };
        } catch (error) {
            console.error('Error getting job stats:', error);
            return { total: 0, applied: 0, reviewed: 0, pending: 0 };
        }
    }
}
