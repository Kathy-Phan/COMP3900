// ;(async () => {
//   // ————————————————————————————————————————————————————————————————
//   // 1) Load our JSON rules
//   // ————————————————————————————————————————————————————————————————
//   let FORM_RULES;
//   try {
//     const raw = await fetch(chrome.runtime.getURL('form_rules.json'));
//     FORM_RULES = await raw.json();
//     console.log("Form rules loaded successfully.");
//   } catch (err) {
//     console.error("Failed to load form_rules.json", err);
//     return;
//   }

//   // ————————————————————————————————————————————————————————————————
//   // 2) Detect platform
//   // ————————————————————————————————————————————————————————————————
//   const host = window.location.hostname;
//   const platformKey =
//         host.includes("seek.com.au")  ? "seek.com.au"
//       : host.includes("linkedin.com") ? "linkedin.com"
//       : host.includes("indeed.com")   ? "indeed.com"
//       : null;
//   console.log("Detected platformKey =", platformKey);
//   if (!platformKey) return;

//   // ————————————————————————————————————————————————————————————————
//   // 3) Selector helper
//   // ————————————————————————————————————————————————————————————————
//   function selectWithContains(def, root = document) {
//     const findMatch = def.match(/^Find button containing the text\s*['"](.+)['"]/i);
//     if (findMatch) {
//       const txt = findMatch[1].toLowerCase();
//       for (let el of root.querySelectorAll('button, *')) {
//         if ((el.innerText || '').toLowerCase().includes(txt)) {
//           const btn = el.tagName === 'BUTTON' ? el : el.closest('button');
//           if (btn && btn.offsetParent !== null) return btn;
//         }
//       }
//       return null;
//     }
//     const el = root.querySelector(def);
//     if (!el || el.offsetParent === null) return null;
//     if (el.tagName === 'BUTTON' || el.tagName === 'A') return el;
//     const btn = el.closest('button');
//     return (btn && btn.offsetParent !== null) ? btn : null;
//   }

//   // ————————————————————————————————————————————————————————————————
//   // 4) Single-step autofill engine
//   // ————————————————————————————————————————————————————————————————
//   // 1) Updated autofillSequence with manual‐only wiring for STEP ≥1
//   async function autofillSequence({ platform, isFullApply = true, existingState = null }) {
//     const easy = FORM_RULES[platform]?.easyApply;
//     if (!easy) {
//       console.warn(`No easyApply rules for '${platform}'`);
//       return;
//     }

//     // Rehydrate or init state
//     let state = existingState;
//     if (!state) {
//       const { jobApplicationState } = await chrome.storage.local.get("jobApplicationState");
//       state = jobApplicationState || { platform, isFullApply, step: 0 };
//     }
//     console.log("▶️ autofillSequence invoked:", state);

//     // STEP 0: click initial apply and bail for SEEK navigation
//     if (state.step === 0) {
//       const initBtn = selectWithContains(easy.initialButton, document);
//       if (!initBtn) throw new Error(`Initial button not found: ${easy.initialButton}`);
//       initBtn.click();

//       state.step = 1;
//       await chrome.storage.local.set({ jobApplicationState: state });

//       // SEEK goes to a new URL—stop here and let your /apply page resume logic pick up
//       if (platform === 'seek.com.au') {
//         return;
//       }
//       // LinkedIn/Indeed open an in-page modal, so we fall through immediately
//     }

//     // STEPS 1..N: manual wiring only
//     if (state.step > 0 && state.step <= easy.steps.length) {
//       const def = easy.steps[state.step - 1];

//       // — scope into the modal —
//       let root = document;
//       if (platform === 'seek.com.au' && easy.modalContainer) {
//         // on SEEK wait up to 3s for the modal container to appear
//         const start = Date.now();
//         while (Date.now() - start < 3000) {
//           const m = document.querySelector(easy.modalContainer);
//           if (m) { root = m; break; }
//           await new Promise(r => setTimeout(r, 200));
//         }
//       }
//       else if (easy.modalContainer) {
//         // for LinkedIn/Indeed just grab it if present
//         const m = document.querySelector(easy.modalContainer);
//         if (m) root = m;
//       }

//       console.log(`🛠 Filling step ${state.step}: ${def.stepName}`);
//       for (let [kind, sel] of Object.entries(def.fields || {})) {
//         // grab all matches
//         let els = Array.from(root.querySelectorAll(sel));

//         // if this is SEEK and we're looking at the upload-buttons group,
//         // don’t filter out hidden elements; otherwise keep the old logic
//         if (!(platform === 'seek.com.au' && kind === 'fileUploadButtons')) {
//           els = els.filter(el => el.offsetParent !== null);
//         }

//         if (!els.length) continue;
//         console.log(` • ${kind}:`, els);
//       }

//       // — find the Next/Continue button —
//       const navSel = def.nextButton ?? def.submitButton;
//       let navBtn, t0 = Date.now();
//       while (Date.now() - t0 < 3000) {
//         navBtn = selectWithContains(navSel, root);
//         if (navBtn) break;
//         await new Promise(r => setTimeout(r, 200));
//       }

//       if (!navBtn) throw new Error(`Nav button not found: ${navSel}`);
//       console.log("✔ Found nav button:", navBtn);

//       // — wire it once per step (so steps 3 & 4 get wired too) —
//       const wiredAttr = `wiredStep${state.step}`;
//       if (!navBtn.dataset[wiredAttr]) {
//         navBtn.dataset[wiredAttr] = '1';
//         navBtn.addEventListener('click', () => {
//           state.step++;
//           chrome.storage.local
//             .set({ jobApplicationState: state })
//             .then(() => window.resumeAutofillSequence(state));
//         }, { once: true });
//         console.log(`🔗 Wired Continue button for step ${state.step} on ${platform}`);
//       }
//       return;
//     }

//     // all done
//     console.log("✅ Autofill complete:", state);
//     await chrome.storage.local.set({ jobApplicationState: state });
//   }


//     // ————————————————————————————————————————————————————————————————
//     // 5) Expose entry points globally
//     // ————————————————————————————————————————————————————————————————
//     window.startAutofillSequence  = (plat, full) => autofillSequence({ platform: plat, isFullApply: full });
//     window.resumeAutofillSequence = (st)       => autofillSequence({ ...st });

//     // ——————————————————————————————————————————————
//     // SEEK: resume on the freshly-loaded /apply page
//     // ——————————————————————————————————————————————
//     if (platformKey === 'seek.com.au' && window.location.pathname.includes('/apply')) {
//       chrome.storage.local.get('jobApplicationState').then(({ jobApplicationState }) => {
//         if (
//           jobApplicationState?.platform === platformKey &&
//           jobApplicationState.step > 0
//         ) {
//           console.log(`▶️ Resuming seek.com.au at step=${jobApplicationState.step}`);
//           window.resumeAutofillSequence(jobApplicationState);
//         }
//       });
//     }


//   // ————————————————————————————————————————————————————————————————
//   // 6) Wire up apply buttons via MutationObserver
//   // ————————————————————————————————————————————————————————————————
//   const obs = new MutationObserver((_, ob) => {
//     // ——————————————————————————————————————————————————————————
//     // LinkedIn wiring (unchanged)
//     // ——————————————————————————————————————————————————————————
//     if (platformKey === 'linkedin.com') {
//       const review = document.getElementById('reviewButton');
//       const apply  = document.getElementById('applyButton');

//       if (review && !review.dataset.wired) {
//         review.dataset.wired = '1';
//         review.addEventListener('click', e => {
//           e.preventDefault();
//           chrome.storage.local.remove('jobApplicationState')
//             .then(() => window.startAutofillSequence(platformKey, false));
//         });
//         console.log('🔗 Wired LinkedIn #reviewButton');
//       }

//       if (apply && !apply.dataset.wired) {
//         apply.dataset.wired = '1';
//         apply.addEventListener('click', e => {
//           e.preventDefault();
//           chrome.storage.local.remove('jobApplicationState')
//             .then(() => window.startAutofillSequence(platformKey, true));
//         });
//         console.log('🔗 Wired LinkedIn #applyButton');
//       }

//       if (review?.dataset.wired && apply?.dataset.wired) {
//         ob.disconnect();
//       }
//     }

//     // ——————————————————————————————————————————————————————————
//     // SEEK wiring (mirror LinkedIn)
//     // ——————————————————————————————————————————————————————————————
//     if (platformKey === 'seek.com.au') {
//       const quickApply = document.querySelector("a[data-automation='job-detail-apply']");
//       if (quickApply && !quickApply.dataset.wired) {
//         quickApply.dataset.wired = '1';
//         quickApply.addEventListener('click', e => {
//           e.preventDefault();
//           chrome.storage.local.remove('jobApplicationState')
//             .then(() => window.startAutofillSequence(platformKey, true));
//         });
//         console.log('🔗 Wired Seek quick apply');
//       }
//     }
//   });

//   obs.observe(document.body, { childList: true, subtree: true });

// })();
