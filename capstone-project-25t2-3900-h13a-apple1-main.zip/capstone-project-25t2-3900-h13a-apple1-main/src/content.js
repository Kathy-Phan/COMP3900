window.selectedStarRating = 1;

//this stuff prevents seek scroll function from freezing
(() => {
  const origAdd = EventTarget.prototype.addEventListener;

  EventTarget.prototype.addEventListener = function (type, listener, opts) {
    
    if ((type === 'wheel' || type === 'touchmove') &&
        opts && typeof opts === 'object' && opts.passive === false) {

      
      const wrapped = function (e) {
        const origPrevent = e.preventDefault;
        e.preventDefault = () => {};          
        try { return listener.call(this, e); }
        finally { e.preventDefault = origPrevent; }
      };

      return origAdd.call(this, type, wrapped, opts);
    }
    return origAdd.call(this, type, listener, opts);
  };
})();


// Utility function to safely clean up existing UI elements
function cleanupExistingUI() {
  try {
    const existingContainer = document.getElementById('jobContainer');
    if (existingContainer) {
      existingContainer.remove();
      console.log('Cleaned up existing job container');
    }

    const existingButton = document.getElementById('jobButton');
    if (existingButton) {
      existingButton.remove();
      console.log('Cleaned up existing job button');
    }
  } catch (error) {
    console.error('Error cleaning up UI:', error);
  }
}

// Listen for messages from the injected script
window.addEventListener("message", function (event) {
  if (event.source !== window || event.data.type !== "linkedinData") return;
  // console.log("✅ Received LinkedIn Profile Data:", event.data.data);
});


async function loadTemplate() {
  try {
    const response = await fetch(chrome.runtime.getURL('job-container-template.html'));
    const template = await response.text();
    return template;
  } catch (error) {
    console.error('Error loading template:', error);
    return '';
  }
}

async function loadStyles() {
  // Check if styles are already loaded
  if (document.getElementById('job-container-styles')) {
    return;
  }

  try {
    // Load CSS content and replace font URLs
    const response = await fetch(chrome.runtime.getURL('job-container.css'));
    const cssContent = await response.text();

    const processedCSS = cssContent
      .replace('{{FONT_INTER_URL}}', chrome.runtime.getURL('fonts/Inter-Light.woff2'))
      .replace('{{FONT_INTER_BOLD_URL}}', chrome.runtime.getURL('fonts/Inter-Bold.woff2'));

    const style = document.createElement('style');
    style.id = 'job-container-styles';
    style.textContent = processedCSS;
    document.head.appendChild(style);
  } catch (error) {
    console.error('Error loading styles:', error);
  }
}


async function displayJobInfoLinkedin() {
  try {
    // Prevent creating duplicate UI elements
    if (document.getElementById('jobButton') || document.getElementById('jobContainer')) {
      console.log('JobGen UI already exists, skipping creation');
      return;
    }

    // Load external styles
    await loadStyles();


    const button = document.createElement('button');
    button.id = 'jobButton';
    button.style.position = 'fixed';
    button.style.top = '50%';
    button.style.right = '10px';
    button.style.transform = 'translateY(-50%)';
    button.style.backgroundColor = '#FFFFFF';
    button.style.border = 'none';
    button.style.padding = '0';
    button.style.borderRadius = '10px';
    button.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    button.style.zIndex = '99999';
    button.style.width = '60px';
    button.style.height = '60px';
    button.innerHTML = `<img src="chrome-extension://${chrome.runtime.id}/icon48.png" alt="Logo" style="width: 100%; height: 100%;" />`;

    let isDragging = false;

    button.addEventListener('mousedown', (e) => {
      isDragging = true;
      const offsetY = e.clientY - button.getBoundingClientRect().top;

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', () => {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
      });

      function onMouseMove(e) {
        if (isDragging) {
          const topPosition = e.clientY - offsetY;
          button.style.top = `${topPosition}px`; // Adjust vertical position
          button.style.right = '0';  // Keep button fixed on the right edge
        }
      }
    });



    button.addEventListener('click', async () => {
      button.style.display = 'none';

      const container = document.createElement('div');
      container.id = 'jobContainer';
      container.style.position = 'fixed';
      container.style.top = '0';
      container.style.right = '0';
      container.style.height = '100%';
      container.style.backgroundColor = '#FFFFFF';
      container.style.padding = '0';
      container.style.borderRadius = '0px';
      container.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.2)';
      container.style.zIndex = '99999';
      container.style.maxWidth = '400px';
      container.style.width = '400px';
      container.style.overflowY = 'auto';

      const currentlink = window.location.href.toLowerCase();
      const jobTitleElement = document.querySelector("h1");

      let companyElement;
      let companyLogoElement;

      if (currentlink.includes("linkedin.com/job") && currentlink.includes("job")) {
        companyElement = document.querySelector('#main > div > div.scaffold-layout__list-detail-inner.scaffold-layout__list-detail-inner--grow > div.scaffold-layout__detail.overflow-x-hidden.jobs-search__job-details > div > div.jobs-search__job-details--container > div > div > div:nth-child(1) > div > div:nth-child(1) > div > div.relative.job-details-jobs-unified-top-card__container--two-pane > div > div.display-flex.align-items-center > div.display-flex.align-items-center.flex-1 > div > a');
        companyLogoElement = document.querySelector("a[data-test-app-aware-link] img");
      } else {
        companyElement = document.querySelector('#profile-content > div > div.scaffold-layout.scaffold-layout--breakpoint-md.scaffold-layout--main-aside.scaffold-layout--reflow.pv-profile.pvs-loader-wrapper__shimmer--animate > div > div > main > section.artdeco-card.GnQuklSZTYJLESwQmsLZcVBXqMjSlZma > div.ph5 > div.mt2.relative > div:nth-child(1) > div.text-body-medium.break-words');
        companyLogoElement = document.querySelector(".profile-photo-edit__edit-btn img");
      }

      const jobLocationElement = document.querySelector('.t-black--light .tvm__text');

      const jobTitle = jobTitleElement ? jobTitleElement.innerText.trim() : "";
      const companyName = companyElement ? companyElement.innerText.trim() : "";
      const companyLogoUrl = companyLogoElement ? companyLogoElement.src : "chrome-extension://" + chrome.runtime.id + "/icon48.png";
      // console.log("setting company logo")
      const jobLocation = jobLocationElement ? jobLocationElement.innerText.trim() : "";

      // Load and populate the template
      const template = await loadTemplate();
      container.innerHTML = template
        .replace(/{{EXTENSION_ID}}/g, chrome.runtime.id)
        .replace(/{{COMPANY_LOGO_URL}}/g, companyLogoUrl)
        .replace(/{{JOB_TITLE}}/g, jobTitle)
        .replace(/{{COMPANY_NAME}}/g, companyName)
        .replace(/{{JOB_LOCATION}}/g, jobLocation);



      document.body.appendChild(container);


      const stars = document.querySelectorAll('#starRating .star');

      // Default rating
      let rating = 3;
      window.selectedStarRating = rating;

      // Set initial star appearance
      stars.forEach(s => {
        if (parseInt(s.getAttribute('data-value')) <= rating) {
          s.textContent = '★';
        } else {
          s.textContent = '☆';
        }
      });

      // Add click listeners
      stars.forEach(star => {
        star.addEventListener('click', () => {
          rating = parseInt(star.getAttribute('data-value'));

          stars.forEach(s => {
            if (parseInt(s.getAttribute('data-value')) <= rating) {
              s.textContent = '★';
            } else {
              s.textContent = '☆';
            }
          });

          window.selectedStarRating = rating;
          console.log('User selected rating:', rating);
        });
      });

      // Separate review button and apply button logic
      async function wireButton(buttonElement, buttonName, IsAutoSubmit) {
        if (buttonElement && !buttonElement.dataset.wiredScanning) {
          buttonElement.dataset.wiredScanning = '1';
          buttonElement.addEventListener('click', async () => {
            try {
              // Collect job data before starting the process
              const jobData = {
                jobTitle: jobTitle,
                companyName: companyName,
                companyLogo: companyLogoUrl,
                location: jobLocation,
                jobUrl: window.location.href,
                description: `Applied via JobGen.AI - ${buttonName}`
              };

              // Show the process view
              const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
              const processType = IsAutoSubmit ? 'apply' : 'review';
              ProgressTab.showProcessView(processType, jobData);

              // Add to progress tracking and get job_id
              const jobId = await addAppliedJob(jobData, IsAutoSubmit);

              // Dispatch the initial action event
              document.dispatchEvent(new CustomEvent('jobgen-current-section', {
                detail: { section: 'Clicking Easy Apply Button' }
              }));

              // Start the easy apply flow (this will trigger real progress events)
              const { startEasyApplyFlow } = await import(chrome.runtime.getURL("content-script.js"));
              await startEasyApplyFlow(IsAutoSubmit);

              // Call job_apply_outcome API after completion (only for apply operations)
              if (jobId && IsAutoSubmit) {
                // Only call outcome API for actual applications, not reviews
                const outcomeResponse = await callJobApplyOutcomeAPI(jobId, "success");
                console.log('✅ Job apply outcome API (success) response:', outcomeResponse);

                // Dispatch completion event for apply mode
                document.dispatchEvent(new CustomEvent('jobgen-process-complete', {
                  detail: { success: true, message: 'Application submitted successfully!' }
                }));
              } else if (!IsAutoSubmit) {
                // For review mode, just complete without claiming submission
                console.log('📝 Review operation completed - no submission performed');
                document.dispatchEvent(new CustomEvent('jobgen-process-complete', {
                  detail: { success: true, message: 'Review completed - you can now manually submit if desired' }
                }));
              }

              console.log(`Autofill process for ${buttonName} has finished.`);
            } catch (error) {
              console.error(`Error during easy apply flow for ${buttonName} button:`, error);

              // Show error in process view
              document.dispatchEvent(new CustomEvent('jobgen-process-complete', {
                detail: { success: false, message: 'Process failed. Please try again.' }
              }));

              // If we have a jobId, call outcome API with failure (only for actual applications)
              if (IsAutoSubmit) {
                try {
                  const { ProgressManager } = await import(chrome.runtime.getURL('progress-manager.js'));
                  const appliedJobs = await ProgressManager.getAppliedJobs();
                  const lastJob = appliedJobs[0];
                  if (lastJob && lastJob.jobId) {
                    const outcomeResponse = await callJobApplyOutcomeAPI(lastJob.jobId, "failure");
                    console.log('❌ Job apply outcome API (failure) response:', outcomeResponse);
                  }
                } catch (outcomeError) {
                  console.error('Error calling outcome API:', outcomeError);
                }
              }
            }
          });
          console.log(`🔗 Wired ${buttonName} button to scanning.js`);
        }
      }
      const applyBtn = document.getElementById('applyButton');
      wireButton(applyBtn, 'Apply Process', true);

      const reviewBtn = document.getElementById('reviewButton');
      wireButton(reviewBtn, 'Review Process', false);

      document.getElementById('closeButton').addEventListener('click', () => {
        const container = document.getElementById('jobContainer');
        if (container) {
          document.body.removeChild(container);
        }
        const button = document.getElementById('jobButton');
        if (button) {
          button.style.display = 'block';
        }
      });

      document.querySelectorAll('.section-title').forEach(title => {
        title.addEventListener('click', () => {
          const sectionId = title.getAttribute('data-target');
          const section = document.getElementById(sectionId);
          if (section) {
            section.style.display = section.style.display === 'block' ? 'none' : 'block';
            title.classList.toggle('collapsed');
          }
        });
      });

      const tabs = document.querySelectorAll('#highLevelTab, #linkedinTab, #progressTab');
      const warningMessage = document.getElementById('warningMessage');
      const currentURL = window.location.href.toLowerCase(); // Get the full URL in lowercase

      tabs.forEach(tab => {
        tab.addEventListener('mouseover', () => {
          tab.style.backgroundColor = '#e0e0e0';
          if (tab.classList.contains('active')) {
            tab.style.backgroundColor = '#3f6afd';
          }
        }); // <-- Closing parenthesis and curly brace correctly placed


        tab.addEventListener('mouseout', () => {
          if (!tab.classList.contains('active')) {
            tab.style.backgroundColor = '#f4f4f4';
          }
          if (tab.classList.contains('active')) {
            tab.style.backgroundColor = '#3f6afd';
          }
        });

        tab.addEventListener('click', () => {
          tabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');
          tabs.forEach(t => {
            t.style.backgroundColor = t.classList.contains('active') ? '#3f6afd' : '#f4f4f4';
            t.style.color = t.classList.contains('active') ? 'white' : 'black';
          });

          // Progress tab is always accessible
          if (tab.id === 'progressTab') {
            showContent(tab.id);
            loadAppliedJobs(); // Load and display applied jobs
            return;
          }

          // Condition 1: If URL contains 'linkedin' and 'job'
          if (currentURL.includes("linkedin") && currentURL.includes("job")) {
            if (tab.id === 'linkedinTab') {
              showWarning("Try this feature on YOUR linkedin profile for the best results!");
            } else {
              showContent(tab.id);
            }
          }
          // Condition 2: If URL contains 'linkedin' and '/in/'
          else if (currentURL.includes("linkedin") && currentURL.includes("/in/")) {
            if (tab.id === 'linkedinTab') {
              showContent(tab.id);
            } else {
              showWarning("Oops! This content isn’t accessible on LinkedIn profile pages.");
              document.getElementById("linkedinTab").click();
            }
          }
          // Condition 3: If URL contains 'linkedin' but neither job or /in/
          else if (currentURL.includes("linkedin") && !currentURL.includes("/in/") && !currentURL.includes("job")) {
            if (tab.id === 'highLevelTab') {
              showContent(tab.id);
            } else {
              showWarning("Try our feature on job listings or your profile for the best results!");
            }
          }
          // Default: Show content if none of the conditions match
          else {
            showContent(tab.id);
          }
        });
      });

      // Function to show tab content
      function showContent(tabId) {
        document.getElementById('highLevelContent').style.display = tabId === 'highLevelTab' ? 'block' : 'none';
        document.getElementById('progressContent').style.display = tabId === 'progressTab' ? 'block' : 'none';
        // document.getElementById('linkedinContent').style.display = tabId === 'linkedinTab' ? 'block' : 'none';

        // Hide warning message
        warningMessage.style.display = 'none';
        warningMessage.innerText = "";
      }

      // Function to show a warning message
      function showWarning(message) {
        warningMessage.innerText = message;
        warningMessage.style.display = 'block';

        // Hide all tab content
        document.getElementById('highLevelContent').style.display = 'none';
        document.getElementById('linkedinContent').style.display = 'none';
        document.getElementById('progressContent').style.display = 'none';
      }

      document.getElementById('highLevelTab').click();
      let buttons;
      buttons = document.querySelectorAll('#saveButton');
      buttons.forEach(button => {
        button.addEventListener('mouseover', () => {
          button.style.backgroundColor = '#30A1FB'; // Darker shade of blue
        });

        button.addEventListener('mouseout', () => {
          button.style.backgroundColor = '#3f6afd'; // Original color
        });
      });

      const reviewWarning = document.getElementById('reviewWarning');
      buttons = document.querySelectorAll('#reviewButton');
      buttons.forEach(button => {
        button.addEventListener('mouseover', () => {
          reviewWarning.style.display = 'block';
          button.style.backgroundColor = '#30A1FB'; // Darker shade of blue
        });

        button.addEventListener('mouseout', () => {
          reviewWarning.style.display = 'none';
          button.style.backgroundColor = '#3f6afd'; // Original color
        });
      });

      const applyWarning = document.getElementById('applyWarning');
      buttons = document.querySelectorAll('#applyButton');
      buttons.forEach(button => {
        button.addEventListener('mouseover', () => {
          applyWarning.style.display = 'block';
          button.style.backgroundColor = '#30A1FB'; // Darker shade of blue
        });

        button.addEventListener('mouseout', () => {
          applyWarning.style.display = 'none';
          button.style.backgroundColor = '#3f6afd'; // Original color
        });
      });

      // Progress management functions - moved to progress-tab.js
      async function loadAppliedJobs() {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        await ProgressTab.loadAppliedJobs();
      }

      // Listen for custom refresh events from the ProgressTab
      document.addEventListener('jobgen-refresh-progress', loadAppliedJobs);

      async function addAppliedJob(jobData, isApply = true) {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        return await ProgressTab.addAppliedJob(jobData, isApply);
      }

      async function callJobApplyOutcomeAPI(jobId, outcome) {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        return await ProgressTab.callJobApplyOutcomeAPI(jobId, outcome);
      }

      // Make functions globally accessible for the button handlers
      window.addAppliedJob = async (jobData, isApply) => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        return await ProgressTab.addAppliedJob(jobData, isApply);
      };
      window.callJobApplyOutcomeAPI = async (jobId, outcome) => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        return await ProgressTab.callJobApplyOutcomeAPI(jobId, outcome);
      };
      window.loadAppliedJobs = loadAppliedJobs;

      // Process view control functions
      window.showProcessView = async (processType, jobData) => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        ProgressTab.showProcessView(processType, jobData);
      };
      window.updateProcessProgress = async (step, statusText) => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        ProgressTab.updateProcessProgress(step, statusText);
      };
      window.completeProcess = async (success, message) => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        ProgressTab.completeProcess(success, message);
      };
      window.hideProcessView = async () => {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        ProgressTab.hideProcessView();
      };

      // Add a test function for demonstration purposes
      window.addTestJob = async function () {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        await ProgressTab.addTestJob();
      };

      // Add demo function to test the process view
      window.demoProcessView = async function () {
        const { ProgressTab } = await import(chrome.runtime.getURL('progress-tab.js'));
        await ProgressTab.demoProcessView();
      };

    });

    document.body.appendChild(button);
    // apply();

    // Remove the problematic setInterval that was causing freezing
    // URL changes are now handled by the MutationObserver at the bottom of the file
  } catch (error) {
    console.error('[JobGen] Error in displayJobInfoLinkedin:', error);
    cleanupExistingUI();
  }
}

async function displayJobInfoGoogAmazon() {
  await loadStyles()

  // create the floating logo button
  const button = document.createElement('button');
  button.id = 'jobButton';
  Object.assign(button.style, {
    position: 'fixed',
    top: '50%',
    right: '10px',
    transform: 'translateY(-50%)',
    backgroundColor: '#FFFFFF',
    border: 'none',
    padding: '0',
    borderRadius: '10px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
    zIndex: '99999',
    width: '60px',
    height: '60px',
    cursor: 'pointer'
  });
  button.innerHTML = `
    <img src="chrome-extension://${chrome.runtime.id}/icon48.png"
         style="width:100%;height:100%;" />`;

  document.body.appendChild(button);

  button.addEventListener('click', async () => {
    console.log('JobGen button clicked!');
    button.style.display = 'none';

    const container = document.createElement('div');
    container.id = 'jobContainer';
    Object.assign(container.style, {
      position: 'fixed',
      top: '50%',
      right: '10px',
      transform: 'translateY(-50%)',
      width: '280px',
      backgroundColor: '#FFFFFF',
      padding: '20px',
      borderRadius: '12px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
      zIndex: '99999',
      fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif'
    });

    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="chrome-extension://${chrome.runtime.id}/icon48.png" 
             style="width: 48px; height: 48px; margin-bottom: 8px;" />
        <div style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 4px;">
          jobgen.ai
        </div>
        <div style="font-size: 12px; color: #666; line-height: 1.4;">
          Autofill basic information by using jobgen.ai
        </div>
      </div>
      
      <button id="autofillButton" style="
        width: 100%;
        padding: 12px 16px;
        backgroundColor:rgb(0, 0, 0);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        margin-bottom: 12px;
      ">Autofill Page</button>
      
      <button id="closeButton" style="
        width: 100%;
        padding: 8px 16px;
        backgroundColor: #f5f5f5;
        color: #666;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        cursor: pointer;
        transition: background-color 0.2s;
      ">Close</button>
    `;

    document.body.appendChild(container);

    // Add hover effects
    const autofillBtn = document.getElementById('autofillButton');
    const closeBtn = document.getElementById('closeButton');

    autofillBtn.addEventListener('mouseover', () => {
      autofillBtn.style.backgroundColor = '#0f0f0f';
    });
    autofillBtn.addEventListener('mouseout', () => {
      autofillBtn.style.backgroundColor = '#0f0f0f';
    });

    closeBtn.addEventListener('mouseover', () => {
      closeBtn.style.backgroundColor = '#e8e8e8';
    });
    closeBtn.addEventListener('mouseout', () => {
      closeBtn.style.backgroundColor = '#f5f5f5';
    });


    // wire up the close button
    document.getElementById('closeButton').addEventListener('click', () => {
      document.body.removeChild(container);
      button.style.display = 'block';
    });

    // wire up the autofill button
    document.getElementById('autofillButton').addEventListener('click', async () => {
      console.log('Autofill button clicked');
      try {
        const { regApplyTest } = await import(chrome.runtime.getURL("content-script.js"));
        regApplyTest()
      } catch (error) {
        console.error("error loading autofill functionality" + error)
      }
    });
  });
}


window.onload = async () => {
  try {
    const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
    const { FAQCaching } = await import(chrome.runtime.getURL('faq-caching.js'));
    await AuthManager.initialize();
    const token = await AuthManager.getStoredToken();
    
    // Log the current user's email
    const userEmail = await AuthManager.getCurrentUserEmail();
    console.log('🔑 JobGen Extension - Current user email:', userEmail);

    await FAQCaching.initialize(token);
  } catch (error) {
    console.error("Failed to initialize authentication:", error);
  }

  const url = window.location.href.toLowerCase();
  if (url.includes('linkedin.com/jobs/')) {
    await displayJobInfoLinkedin();
  } else if (url.includes('seek.com.au/')) {
        const { displayJobInfoSeek, handleSeekApplicationPage } = 
          await import(chrome.runtime.getURL('seek/seek-handler.js'));
        const { isSeekApplicationPage } = 
          await import(chrome.runtime.getURL('seek/seek-utils.js'));

        if (isSeekApplicationPage(url)) {
          console.log('📄 Seek application page');
          await handleSeekApplicationPage();
        } else {
          console.log('📋 Regular Seek page - showing extension');
          await displayJobInfoSeek();
        }
    } else if (
    url.includes('google.com/about/careers') ||
    url.includes('amazon.jobs')
  ) {
    await displayJobInfoGoogAmazon();        // generic panel for any keyword site
  } /* ─────────── NEW NORMAL-APPLY BRANCH ─────────── */
  else if (
    url.includes('apply')          ||          // generic ATS keywords
    url.includes('candidate')      ||
    /\/careers?\//.test(url)       ||
    /boards\.greenhouse\.io/.test(url) ||
    /myworkdayjobs\.com/.test(url)
  ) {
    try {
      const { AuthManager }     = await import(chrome.runtime.getURL('auth-manager.js'));
      const { runNormalApply }  = await import(
        chrome.runtime.getURL('normal-apply/form-filler3.js')
      );

      const jwt = await AuthManager.getStoredToken();
      await runNormalApply(jwt);
    } catch (err) {
      console.error('[JobGen] Normal-apply bootstrap failed', err);
    }
  }

  window.addEventListener("load", async () => {
    try {
      const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
      const { FAQCaching } = await import(chrome.runtime.getURL('faq-caching.js'));
      await AuthManager.initialize();
      const token = await AuthManager.getStoredToken();
      
      // Log the current user's email
      const userEmail = await AuthManager.getCurrentUserEmail();
      console.log('🔑 JobGen Extension - Page load - Current user email:', userEmail);
      
      await FAQCaching.initialize(token);
    } catch (error) {
      console.error("Failed to initialize authentication:", error);
    }

    await handlePageChange(); // Initial load
  });

  //if the page contains keyword then display jobgen extension. 
  async function handlePageChange() {
    try {
      const url = location.href.toLowerCase();
      console.log('in handle page hcange')

      if (url.includes('linkedin.com/')) {
        await displayJobInfoLinkedin();        // all LinkedIn pages
      } else if (
        url.includes('google.com/about/careers') ||
        url.includes('amazon.jobs')
      ) {
        await displayJobInfoGoogAmazon();        // generic panel for any keyword site

      } else if (url.includes('seek.com.au/')) {
        const { displayJobInfoSeek, handleSeekApplicationPage } = 
          await import(chrome.runtime.getURL('seek/seek-handler.js'));
        const { isSeekApplicationPage } = 
          await import(chrome.runtime.getURL('seek/seek-utils.js'));

        if (isSeekApplicationPage(url)) {
          console.log('📄 Seek application page');
          await handleSeekApplicationPage();
        } else {
          console.log('📋 Regular Seek page - showing extension');
          await displayJobInfoSeek();
        }
        
      } else if (
        url.includes('apply') ||
        url.includes('applied') ||
        url.includes('job') ||
        url.includes('jobs') ||
        url.includes('submit')
      ) {
        await displayJobInfoLinkedin();        // generic panel for any keyword site
      }
    } catch (error) {
      console.error('[JobGen] Error in handlePageChange:', error);
      // Clean up on error to prevent stuck state
      cleanupExistingUI();
    }
  }


  let currentUrl = location.href;
  let urlChangeTimeout;

  //observes if the url changes with debouncing to prevent excessive calls
  new MutationObserver(() => {
    if (location.href !== currentUrl) {
      clearTimeout(urlChangeTimeout);
      urlChangeTimeout = setTimeout(async () => {
        const newUrl = location.href;
        if (newUrl !== currentUrl) {
          currentUrl = newUrl;
          console.log("[JobGen] URL changed → Re-running logic for", currentUrl);

          // Check if UI was open before cleanup (for Seek auto-reopen)
          const wasUIOpen = document.getElementById('jobContainer') !== null;
          const isSeekSite = newUrl.includes('seek.com.au');

          // Clean up existing UI elements before re-initializing
          cleanupExistingUI();
        
          await handlePageChange();

          // Auto-reopen UI for Seek if it was previously open
          if (isSeekSite && wasUIOpen) {
            setTimeout(() => {
              const button = document.getElementById('jobButton');
              if (button) {
                button.click();
              }
            }, 1);
          }
        }
      }, 300); // Debounce for 300ms
    }

  }).observe(document.documentElement, {
    childList: true,
    subtree: false // Only observe direct children of documentElement to reduce overhead
  });
}