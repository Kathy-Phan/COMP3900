// Resume upload logic using the new job_apply API call
export async function runApplicationSequence() {
  try {
    // 1) Scrape the current page for job details
    console.log('in runapp sequence')
    const job_url = location.href;
    const job_title = (
      document.querySelector("h1, .topcardtitle, [data-testid='job-detail-title']")?.innerText ||
      "Unknown Role"
    ).trim();
    const company = (
      document.querySelector(".topcardorg-name-link, .company, [data-testid='advertiser-name']")?.innerText ||
      "Unknown Co"
    ).trim();
    let description = (
      document.querySelector("article, .jobDescriptionText, .jobs-description__container")?.innerText ||
      document.body.innerText
    ).trim().slice(0, 2000);
    // 2) Derive portal + URL-ID for de-dup checks
    const job_portal = location.hostname;
    const job_url_id = (() => {
      const m = location.href.match(/(?:\/job\/|job_id=)(\d+)/);
      return m ? m[1] : location.href;
    })();

    // 3) Get JWT token
    const { AuthManager } = await import(chrome.runtime.getURL('auth-manager.js'));
    const jwt = await AuthManager.getStoredToken();
    if (!jwt) throw new Error('No JWT token found');

    // 4) Build the payload
    const payload = {
      job_url,
      description,
      cover_letter: 'no',
      company,
      job_title,
      job_url_id,
      job_portal
    };

    // 5) Fire the request
    const res = await fetch(
      "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${jwt}`
        },
        body: JSON.stringify(payload)
      }
    );
    const txt = await res.text();
    if (!res.ok) {
      console.error(`❌ API-1 HTTP ${res.status}`, txt);
      return null;
    }
    // 6) Parse & return
    const { response = {} } = JSON.parse(txt);
    const { resume, cover_letter, job_id } = response;
    window._jobgen_job_id = job_id;
    if (!resume) throw new Error('No resume link returned from API');

    // 7) Upload resume to LinkedIn
    await uploadFileFromUrl(resume);
    return { resume, cover_letter, job_id };
  } catch (err) {
    console.error('❌ Error during application flow:', err);
    return null;
  }
}

// Helper to upload a file from a URL to a file input on the page
export async function uploadFileFromUrl(url) {
  const res = await fetch(url);
  const blob = await res.blob();
  const file = new File([blob], "resume.pdf", { type: "application/pdf" });

  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);
  const fileInput = document.querySelector('input[type="file"][id*="upload-resume"]');
  if (!fileInput) throw new Error('No file input found for resume upload');
  fileInput.files = dataTransfer.files;
  // Trigger change event
  fileInput.dispatchEvent(new Event('change', { bubbles: true }));
}