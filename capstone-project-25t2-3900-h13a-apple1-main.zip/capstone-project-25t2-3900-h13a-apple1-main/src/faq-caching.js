// FAQ data caching for JobGen.AI

export class FAQCaching {
    static FAQ_API_URL = "https://www.jobgen.ai/version-test/api/1.1/wf/job_apply_faq";

    // Fetch FAQ data from API and store it
    static async fetchAndStoreFAQ(token) {
        try {
            console.log(" Fetching FAQ data...");

            const response = await fetch(FAQCaching.FAQ_API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const responseData = await response.json();
            console.log("RESPONSE DATA" + responseData.status)

            if (responseData.status === "success" && responseData.response) {
                await chrome.storage.local.set({ faq_response: responseData.response });
                console.log(" FAQ data fetched and stored successfully");
                return responseData.response;
            } else {
                throw new Error(`FAQ fetch failed: ${responseData.status}`);
            }

        } catch (error) {
            console.error(' Error fetching FAQ data:', error);
            throw error;
        }
    }

    // Get stored FAQ data
    static async getStoredFAQ() {
        const result = await chrome.storage.local.get(['faq_response']);
        const faqData = result.faq_response;
        if (!faqData) {
            console.warn(" No FAQ data found in storage");
            return null;
        }
        return faqData;
    }


    // Initialize FAQ data (fetch if not exists)
    static async initialize(token) {
  const [cached, fresh] = await Promise.all([
    FAQCaching.getStoredFAQ(),
    FAQCaching.fetchAndStoreFAQ(token)     // fetch, but don’t store yet
  ]);

  // Overwrite only when sense a value changed 
  if (!cached || JSON.stringify(cached) !== JSON.stringify(fresh)) {
    console.log(' FAQ changed – updating cache');
    await chrome.storage.local.set({ faq_response: fresh });
  } else {
    console.log(' FAQ already up-to-date');
  }

  return fresh;
}
}