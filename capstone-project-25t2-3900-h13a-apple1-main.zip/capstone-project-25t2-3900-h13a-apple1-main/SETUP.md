## Setup
To get started with our project, you'll need to set up the development environment by installing a few key dependencies. The entire process is streamlined to ensure you have all the necessary tools for linting, testing, and building the project. 
1. The quickest way to install everything is to run a single `npm install` command with all the required packages in the <b>root directory</b>.
2.  We use @eslint/js to enforce consistent code quality and style across the codebase. Put `npm install --save-dev @eslint/js` into the <b>root directory</b>, then run `npm run lint`
3. For testing, we have integrated jest as our primary testing framework. You can run it with `npm install jest --save-dev`, then `npm run test` in the <b>root directory</b>.
4. We are using Vite for our build tool however, since the client provided us with a base chrome extension, Vite is primarly used to bundle and optimise our source files for production. This ensures that our multi-page extension is correctly packaged. You can install vite with `npm install vite --save-dev`, then `npm run build`. 


### Known Limitations
- Resume upload for Google cannot be automated as of now
- Account confirmation emails cannot be automated
- SMS confirmations may also not be automated
- 2FA may also not be automated
- URLs with nested fields cannot be reached for autofilling
- Found a bug in the backend where the address field would be empty sometimes and that causes a refresh
- Certain fields are not able to be automated e.g. selecting dates on date selector, typing to find university