// eslint.config.js — ESLint v9 flat config
import js from "@eslint/js";
import globals from "globals";

// If you write tests with Jest:
import jestPlugin from "eslint-plugin-jest";

// If you use React anywhere (popup/options UI), keep this import.
// If you don't use React, remove the import and the "plugins"/"settings" bits below.
import reactPlugin from "eslint-plugin-react";

export default [
  // 1) Ignore build + deps (delete your old .eslintignore to silence the warning)
  { ignores: ["dist/**", "build/**", "node_modules/**"] },

  // 2) Base recommended rules
  js.configs.recommended,

  // 3) Extension source (content scripts, background, popup/options UI)
  {
    files: ["src/**/*.{js,jsx,ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module",
      parserOptions: { ecmaFeatures: { jsx: true } },
      globals: {
        ...globals.browser, // window, document, etc.
        chrome: "readonly", // Chrome Extensions API
      },
    },
    plugins: {
      react: reactPlugin,    // remove if not using React
    },
    settings: {
      // remove this block if not using React
      react: { version: "detect" },
    },
    rules: {
      "no-empty": ["error", { allowEmptyCatch: true }],
      // add/tweak rules as you like
    },
  },

  // 4) Jest tests
  {
    files: ["**/*.test.{js,jsx,ts,tsx}", "**/__tests__/**/*.{js,jsx,ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module",
      globals: {
        ...globals.jest, // describe, test, expect, beforeAll, etc.
        ...globals.node, // sometimes tests touch fs/path, etc.
      },
    },
    plugins: { jest: jestPlugin },
    rules: {
      // Add jest-specific rules here if you want
    },
  },

  // 5) Node-only config files (Vite/Jest/ESLint configs)
  {
    files: ["vite.config.*", "eslint.config.*", "jest.config.*"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module",
      globals: { ...globals.node }, // __dirname, module, process, etc.
    },
  },
];
